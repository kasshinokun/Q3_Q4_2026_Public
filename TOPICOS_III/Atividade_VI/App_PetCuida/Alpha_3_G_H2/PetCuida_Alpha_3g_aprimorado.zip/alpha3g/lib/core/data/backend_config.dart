/// Backend preparado para futura ativação.
///
/// O alfa permanece offline por padrão. Para ativar um adaptador, configure
/// credenciais e registro no composition root (main.dart), nunca dentro das
/// telas.
enum BackendProvider { local, firebaseFirestore, supabase }

final class BackendConfig {
  const BackendConfig({
    this.provider = BackendProvider.local,
    this.projectId,
    this.supabaseUrl,
    this.supabaseAnonKey,
  });

  final BackendProvider provider;
  final String? projectId;
  final String? supabaseUrl;
  final String? supabaseAnonKey;

  bool get isRemote => provider != BackendProvider.local;
}
