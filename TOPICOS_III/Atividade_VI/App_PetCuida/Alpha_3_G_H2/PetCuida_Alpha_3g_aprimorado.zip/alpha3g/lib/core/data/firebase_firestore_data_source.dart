import 'remote_data_source.dart';

/// Ponto de integração para Firebase Cloud Firestore.
///
/// Propositalmente não importa `firebase_core`/`cloud_firestore` no alfa.
/// Depois de adicionar os plugins oficiais e inicializar Firebase no main,
/// substitua os corpos pelos métodos de `FirebaseFirestore.instance`.
final class FirebaseFirestoreDataSource implements RemoteDataSource {
  const FirebaseFirestoreDataSource();

  Never _notConfigured() => throw const BackendNotConfiguredException('Firebase/Firestore');

  @override
  Future<Map<String, dynamic>?> readDocument({required String collection, required String id}) async => _notConfigured();

  @override
  Future<void> writeDocument({required String collection, required String id, required Map<String, dynamic> data}) async => _notConfigured();

  @override
  Future<void> deleteDocument({required String collection, required String id}) async => _notConfigured();

  @override
  Stream<List<Map<String, dynamic>>> watchCollection({required String collection}) => _notConfigured();
}
