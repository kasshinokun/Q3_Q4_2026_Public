import 'remote_data_source.dart';

/// Ponto de integração para Supabase (Postgres, Auth e Storage).
///
/// Propositalmente não importa `supabase_flutter` no alfa. Depois de adicionar
/// o plugin e inicializar o cliente no main, mapeie as operações deste
/// contrato para `Supabase.instance.client`.
final class SupabaseDataSource implements RemoteDataSource {
  const SupabaseDataSource();

  Never _notConfigured() => throw const BackendNotConfiguredException('Supabase');

  @override
  Future<Map<String, dynamic>?> readDocument({required String collection, required String id}) async => _notConfigured();

  @override
  Future<void> writeDocument({required String collection, required String id, required Map<String, dynamic> data}) async => _notConfigured();

  @override
  Future<void> deleteDocument({required String collection, required String id}) async => _notConfigured();

  @override
  Stream<List<Map<String, dynamic>>> watchCollection({required String collection}) => _notConfigured();
}
