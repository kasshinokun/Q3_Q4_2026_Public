# Camada de dados futura

O alfa utiliza `AppDataService` com dados locais e mockados. Os arquivos deste diretório deixam um contrato remoto pronto sem adicionar SDK, credenciais ou chamadas de rede.

## Ativação futura

1. Escolha `BackendProvider.firebaseFirestore` ou `BackendProvider.supabase` em uma configuração de ambiente segura.
2. Adicione somente o SDK oficial escolhido ao `pubspec.yaml`.
3. Inicialize o SDK no `main.dart` antes de `runApp`.
4. Complete o adaptador correspondente em `firebase_firestore_data_source.dart` ou `supabase_data_source.dart`.
5. Injete a implementação por `Provider<RemoteDataSource>` no composition root.
6. Mapeie os documentos para os modelos de domínio e mantenha as telas desacopladas do SDK.

Nenhuma chave deve ser versionada no repositório. Use configuração de ambiente, secrets do CI/CD e regras de segurança no próprio backend.
