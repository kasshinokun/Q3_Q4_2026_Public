import 'package:image_picker/image_picker.dart';

/// Encapsula o acesso ao `image_picker` em um único ponto do app.
///
/// Mantém o plugin de terceiros isolado (em vez de chamado diretamente
/// em cada tela), facilitando trocar a implementação ou adicionar
/// tratamento de erro/permite de forma centralizada.
abstract final class ImagePickerHelper {
  static final _picker = ImagePicker();

  /// Abre a galeria do dispositivo e retorna o caminho local da imagem
  /// escolhida, ou `null` se o usuário cancelar a seleção.
  static Future<String?> escolherDaGaleria({int imageQuality = 80}) async {
    try {
      final XFile? arquivo = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: imageQuality,
        maxWidth: 1024,
      );
      return arquivo?.path;
    } catch (_) {
      // Falhas de permissão/plataforma resultam apenas em "nenhuma foto
      // escolhida" — a UI já trata `null` mostrando o ícone padrão.
      return null;
    }
  }
}
