/// Contrato agnóstico para persistência remota do PetCuida.
///
/// Esta camada fica dormente no alfa: nenhuma implementação é registrada no
/// Provider e nenhum SDK externo é importado. Quando o backend for ativado,
/// a aplicação poderá trocar [LocalDataSource] por um adaptador Firebase ou
/// Supabase sem alterar as telas nem os modelos de domínio.
abstract interface class RemoteDataSource {
  Future<Map<String, dynamic>?> readDocument({required String collection, required String id});

  Future<void> writeDocument({required String collection, required String id, required Map<String, dynamic> data});

  Future<void> deleteDocument({required String collection, required String id});

  Stream<List<Map<String, dynamic>>> watchCollection({required String collection});
}

/// Implementação temporária para desenvolvimento offline.
/// Não persiste nada: serve apenas para manter a aplicação explicitamente
/// desacoplada enquanto o backend ainda não foi ativado.
final class LocalDataSource implements RemoteDataSource {
  const LocalDataSource();

  @override
  Future<Map<String, dynamic>?> readDocument({required String collection, required String id}) async => null;

  @override
  Future<void> writeDocument({required String collection, required String id, required Map<String, dynamic> data}) async {}

  @override
  Future<void> deleteDocument({required String collection, required String id}) async {}

  @override
  Stream<List<Map<String, dynamic>>> watchCollection({required String collection}) => const Stream.empty();
}

/// Erro usado pelos adaptadores dormentes quando alguém tenta ativá-los antes
/// de instalar/configurar o SDK correspondente.
final class BackendNotConfiguredException implements Exception {
  const BackendNotConfiguredException(this.backend);

  final String backend;

  @override
  String toString() => 'Backend "$backend" ainda não está configurado.';
}
