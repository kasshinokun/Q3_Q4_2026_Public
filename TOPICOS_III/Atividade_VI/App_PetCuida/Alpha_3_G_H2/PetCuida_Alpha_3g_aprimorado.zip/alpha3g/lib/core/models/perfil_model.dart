import 'atividade_model.dart';
import 'pet_model.dart';

/// Perfil do tutor autenticado: dados pessoais, foto, pet principal,
/// saldo de créditos solidários e histórico de atividades.
class PerfilModel {
  final String nome;
  final String email;
  final String bairro;
  final double saldoCreditos;
  final PetModel pet;
  final List<AtividadeModel> atividades;

  /// Caminho local da foto de perfil escolhida pelo tutor (galeria).
  /// `null` quando nenhuma foto foi escolhida — nesse caso a UI usa um
  /// ícone/iniciais como avatar padrão.
  final String? fotoPath;

  const PerfilModel({
    required this.nome,
    required this.email,
    required this.bairro,
    required this.saldoCreditos,
    required this.pet,
    this.atividades = const [],
    this.fotoPath,
  });

  PerfilModel copyWith({
    PetModel? pet,
    double? saldoCreditos,
    List<AtividadeModel>? atividades,
    String? fotoPath,
    bool limparFoto = false,
  }) {
    return PerfilModel(
      nome: nome,
      email: email,
      bairro: bairro,
      saldoCreditos: saldoCreditos ?? this.saldoCreditos,
      pet: pet ?? this.pet,
      atividades: atividades ?? this.atividades,
      fotoPath: limparFoto ? null : (fotoPath ?? this.fotoPath),
    );
  }
}
