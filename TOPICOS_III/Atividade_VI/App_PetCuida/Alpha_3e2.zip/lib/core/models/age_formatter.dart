import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// Formatador personalizado para adicionar " anos)"
class IdadeInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {

    // Se o campo for limpo, esvazia o texto
    if (newValue.text.isEmpty) {
      return newValue;
    }

    // Remove qualquer texto anterior de formatação para pegar só os números digitados
    String apenasNumeros = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');

    if (apenasNumeros.isEmpty) {
      return TextEditingValue.empty;
    }

    // Cria a nova string no formato desejado: X anos)
    String novoTexto = '$apenasNumeros anos)';

    // Mantém o cursor sempre logo após o último número digitado (antes do " anos)")
    int posicaoCursor = apenasNumeros.length;

    return TextEditingValue(
      text: novoTexto,
      selection: TextSelection.collapsed(offset: posicaoCursor),
    );
  }
}
