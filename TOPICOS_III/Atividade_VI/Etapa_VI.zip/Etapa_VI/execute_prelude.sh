#!/bin/bash
# ====================================================================================================================
# Script de Instalação e Configuração de Ambientes de Desenvolvimento
# Otimizado para: Distros Linux x64 baseados em Ubuntu/Debian
# ====================================================================================================================

set -e  # Interrompe o script em caso de erro
export DEBIAN_FRONTEND=noninteractive

# Cores para saída (opcional)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # Sem cor

log() {
    echo -e "${GREEN}[$(date +%H:%M:%S)]${NC} $1"
}

error() {
    echo -e "${RED}[ERRO]${NC} $1" >&2
    exit 1
}

warn() {
    echo -e "${YELLOW}[AVISO]${NC} $1"
}


welcome(){

    log "Olá, vou lhe orientar para você recriar a estrutura"
    log "Estou preparado para Ubuntu 24.04 x64"
    log "ou Qualquer distro que use o APT"

}


etapa_0a(){

    log "0A - Atualizando sistema e instalando dependências essenciais..."

    sudo apt-get install wget gnupg -y

    # Em caso de erro descomente este trecho 
    # Se usar distro igual ao Tsurugi Linux

    # wget -qO- https://deb.torproject.org/torproject.org/A3C4F0F979CAA22CDBA8F512EE8CBC9E886DDD89.asc | gpg --dearmor | sudo tee /usr/share/keyrings/deb.torproject.org-keyring.gpg >/dev/null
    # wget -qO- https://deb.torproject.org/torproject.org/A3C4F0F979CAA22CDBA8F512EE8CBC9E886DDD89.asc | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/deb.torproject.org.gpg >/dev/null
    # sudo apt-get clean

    sudo apt-get update -qq
    sudo apt-get upgrade -y -qq

    # Agrupamento de pacotes (evita múltiplas chamadas apt)
    PACKAGES=(
        build-essential
        libssl-dev zlib1g-dev libncurses5-dev libgdbm-dev libncursesw5-dev
        libreadline-dev libsqlite3-dev libffi-dev uuid-dev liblzma-dev tk-dev
        curl git unzip xz-utils zip libglu1-mesa clang cmake ninja-build pkg-config
        libgtk-3-dev libstdc++6 software-properties-common apt-transport-https
        default-jdk openjdk-21-jdk   # Apenas a versão LTS mais recente
    )

    sudo apt-get install -y -qq "${PACKAGES[@]}"

    # Habilita arquitetura i386 (necessário para Android SDK)
    sudo dpkg --add-architecture i386
    sudo apt-get update -qq
    sudo apt-get install -y -qq libc6:i386 libncurses6:i386 libstdc++6:i386 lib32z1 libbz2-1.0:i386

}
etapa_0b(){

    log "0B) Verificar presença do C"

    if command -v gcc &> /dev/null; then
        log "Encontrei o GCC"
        echo gcc --version
    else
        warn "GCC não encontrado."
        sudo apt-get install gcc -y
    fi

}
etapa_0c(){

    log "0C) Verificar presença do C++"

    if command -v gcc &> /dev/null; then
        log "Encontrei o G++"
        echo g++ --version
    else
        warn "G++ não encontrado."
        sudo apt-get install g++ -y
    fi

}
etapa_0d(){

    log "0D) Verificar presença do Java"

    if command -v gcc &> /dev/null; then
        log "Encontrei o Java"
        echo g++ --version
    else
        warn "Java não encontrado."
        sudo apt-get install -y default-jdk openjdk-21-jdk
    fi

}
etapa_0e(){

    log "0E) Checando se você tem o VS Code"

    if command -v code &> /dev/null; then
        log "Encontrei o VS Code"
        echo code --version
    else
        warn "o VS Code não encontrado."
        if command -v snap &> /dev/null; then
            echo "Instalando VS Code via snap"
            sudo snap install code --classic
        else
            wget --show-progress "https://go.microsoft.com/fwlink/?LinkID=760868" -O /tmp/vscode.deb

            sudo apt install /tmp/vscode.deb

            rm -f /tmp/vscode.deb
        fi

    fi

}
etapa_1a(){
    log "Instalando/Atualizando Flutter (stable)..."

    FLUTTER_DIR="$HOME/development/flutter"
    mkdir -p "$(dirname "$FLUTTER_DIR")"

    if [ -d "$FLUTTER_DIR" ]; then
        log "Atualizando Flutter existente..."
        cd "$FLUTTER_DIR"
        git pull origin stable
    else
        cd "$(dirname "$FLUTTER_DIR")"
        git clone https://github.com/flutter/flutter.git -b stable
    fi

    # Adiciona ao PATH permanentemente e na sessão atual
    if ! grep -q "development/flutter/bin" ~/.bashrc; then
        log "Adicionando ao PATH"
        echo 'export PATH="$PATH:$FLUTTER_DIR/bin"' >> ~/.bashrc
    fi

    log "Adicionando ao Environment"
    #export PATH="$PATH:$HOME/development/flutter/bin"
    export PATH="$PATH:$FLUTTER_DIR/bin"

    log "Atualizando BASH"
    source ~/.bashrc

    log "1A) Verificar presença do DART e Flutter"

    if command -v dart &> /dev/null; then
        log "Encontrei o Dart SDK...."
        echo dart --version
    else
        log "Baixando Dart SDK...."
    fi

    if command -v flutter &> /dev/null; then
        log "Encontrei o Flutter SDK"
        echo flutter --version
    fi
}

# Herança do codigo original
stage_6a(){
    log "Instalando Android Studio..."

    # Snap
    android_studio_snap(){
        # Verifica se snap está disponível; caso contrário, baixa o tarball
        if command -v snap &> /dev/null; then
            sudo snap install android-studio --classic
        else
            warn "Snap não encontrado."
        fi
    }
    # Manual
    android_studio_manual(){
        warn "Fazendo download manual do Android Studio..."
        ANDROID_STUDIO_URL="https://edgedl.me.gvt1.com/android/studio/ide-zips/2026.1.4.7/android-studio-quail4-linux.tar.gz"

        # -q ---------------> Silenciosamente
        # --show-progress --> Exibe progresso do download
        # -O ---------------> Especifica o arquivo a ser salvo

        # wget -q --show-progress "$ANDROID_STUDIO_URL" -O /tmp/android-studio.tar.gz

        wget --show-progress "$ANDROID_STUDIO_URL" -O /tmp/android-studio.tar.gz

        sudo tar -xzf /tmp/android-studio.tar.gz -C /opt/
        sudo ln -sf /opt/android-studio/bin/studio.sh /usr/local/bin/android-studio
        rm -f /tmp/android-studio.tar.gz
    }

    android_studio_manual # No momento, sera manual
}
stage_6b1(){ # Dicas para configurar o Android SDK - 13/09/2026 revisão 14-09-2026-2stage_6b2 # Finalização

    log "Instruçoes para configurar o Android SDK"

    log "Instalando SDK e cmdline-tools via Android Studio"

    log "Passo 1: Abra o Android Studio."
    log "        Rode no terminal 'android-studio'"
    log "Passo 2: Abra o SDK Manager:"

    log "  A) Na tela de boas-vindas:"
    log "        Clique em More Actions (ou no ícone de três pontos)"
    log "        Clique em SDK Manager."

    log "  B) Com um projeto aberto:"
    log "        Vá em Tools"
    log "        SDK Manager (ou Settings/Preferences)"
    log "        Languages ​​& Frameworks"
    log "        Android SDK"

    log "Passo 3: Selecione a aba SDK Platforms na parte superior."
    log "        Marque todos os android sdk do 8.0 até o atual[17] (em 14-09-2026, do 29.0 ao 37.0)"
    log "Passo 4: Selecione a aba SDK Tools na parte superior."

    log "Passo 5: Procure por Android SDK Command-line Tools (latest) e marque a caixa de seleção ao lado."

    log "Passo 6: Clique em Apply no canto inferior direito."

    log "Passo 7: Clique em OK para confirmar o download e aguarde a conclusão da instalação."

    log "Apos isto, é somente rodar no terminal 'flutter doctor --android-licenses'"
}
stage_6b2(){ # Configurar o Android SDK - 13/09/2026 revisão 14-09-2026-2

    log "Configure o Android SDK"

    android-studio
    # O comando 'android-studio' abre a GUI e trava o script em background/terminal.
    # Enquanto o sdk do android é configurado

}

stage_6b3(){
    # Aceitação automática das licenças do Android SDK
    log "Aceitando licenças do Android SDK (pode levar alguns minutos)..."
    yes | flutter doctor --android-licenses || warn "Falha ao aceitar licenças. Execute 'flutter doctor --android-licenses' manualmente."

}
stage_6b4(){

    # Executa o flutter doctor para verificar o ambiente
    flutter doctor
}

etapa_1b(){ # Android Studio 13/09/2026 revisão 14-09-2026-2

    log "1B) Verificar status do Android Studio e preparativos"

    if command -v android-studio &> /dev/null; then
        log "Encontrei o Android Studio"
    else
        stage_6a # Instalação
    fi

    log "Verificaçao do Android Studio e Validaçao"

    stage_6b1 # Dicas

    stage_6b2 # Finalização

    stage_6b3 # Finalização

    stage_6b4 # Finalização

    log "Tudo está pronto!"


}
etapa_2a(){
# ==============================================================
    echo "2A) Criando o projeto"
    echo flutter create --org com.grupo4topicos3.petcuida --platform android,ios --project-name petcuida ./

    echo "Criando pasta para assets"
    mkdir -p ./assets

    # URL precisa ser o link "raw" do GitHub, não o link da página "blob"
    LOGO_URL="https://raw.githubusercontent.com/kasshinokun/Q3_Q4_2026_Public/main/TOPICOS_III/Atividade_VI/images/petcuida-logo.png"

    # -q ---------------> Silenciosamente
    # --show-progress --> Exibe progresso do download
    # -O ---------------> Especifica o arquivo a ser salvo
    wget -q --show-progress "$LOGO_URL" -O ./assets/petcuida-logo.png

    echo "Projeto criado com sucesso, estou abrindo o VS Code"

    rm -rf ./test

}

etapa_2b(){
    # ============================================================
    # Cria a estrutura de pastas e arquivos .dart (vazios) dentro
    # de ./lib para o projeto Flutter, organizada por feature.
    # ============================================================



    LIB_DIR="./lib"

    echo "Criando estrutura de pastas e arquivos em $LIB_DIR ..."

    # ------------------------------------------------------------
    # Função utilitária: cria a pasta (se não existir) e o arquivo
    # ------------------------------------------------------------
    create_file() {
    local filepath="$1"
    local dir
    dir=$(dirname "$filepath")
    mkdir -p "$dir"
    if [ ! -f "$filepath" ]; then
        touch "$filepath"
        echo "  [+] Criado: $filepath"
    else
        echo "  [=] Já existe: $filepath"
    fi
    }

    log "Criando Pastas-Base do Projeto"

    mkdir -p "$LIB_DIR/features/auth/screens"
    mkdir -p "$LIB_DIR/features/home/screens"
    mkdir -p "$LIB_DIR/features/pet/screens"
    mkdir -p "$LIB_DIR/features/triagem/screens"
    mkdir -p "$LIB_DIR/features/rede_solidaria/screens"
    mkdir -p "$LIB_DIR/features/perfil/screens"
    mkdir -p "$LIB_DIR/core/widgets"
    mkdir -p "$LIB_DIR/core/models"
    mkdir -p "$LIB_DIR/core/services"
    mkdir -p "$LIB_DIR/core/routes"

    # ------------------------------------------------------------
    # FEATURE: auth
    # ------------------------------------------------------------
    create_file "$LIB_DIR/features/auth/screens/splash_screen.dart"
    create_file "$LIB_DIR/features/auth/screens/login_screen.dart"
    create_file "$LIB_DIR/features/auth/screens/cadastro_screen.dart"
    create_file "$LIB_DIR/features/auth/screens/recuperar_senha_screen.dart"
    create_file "$LIB_DIR/features/auth/screens/onboarding_pet_screen.dart"

    # ------------------------------------------------------------
    # FEATURE: home
    # ------------------------------------------------------------
    create_file "$LIB_DIR/features/home/screens/home_dashboard_screen.dart"

    # ------------------------------------------------------------
    # FEATURE: pet
    # ------------------------------------------------------------
    create_file "$LIB_DIR/features/pet/screens/area_do_pet_screen.dart"
    create_file "$LIB_DIR/features/pet/screens/adicionar_editar_pet_screen.dart"
    cstage_6b1 # Dicas

    create_file "$LIB_DIR/features/pet/screens/calendario_vacinas_screen.dart"
    create_file "$LIB_DIR/features/pet/screens/prontuario_historico_screen.dart"
    create_file "$LIB_DIR/features/pet/screens/gerar_qrcode_screen.dart"

    # ------------------------------------------------------------
    # FEATURE: triagem
    # ------------------------------------------------------------
    create_file "$LIB_DIR/features/triagem/screens/triagem_orientativa_screen.dart"
    create_file "$LIB_DIR/features/triagem/screens/chat_orientacao_screen.dart"

    # ------------------------------------------------------------
    # FEATURE: rede_solidaria
    # ------------------------------------------------------------
    create_file "$LIB_DIR/features/rede_solidaria/screens/rede_solidaria_screen.dart"
    create_file "$LIB_DIR/features/rede_solidaria/screens/clinicas_usar_creditos_screen.dart"
    create_file "$LIB_DIR/features/rede_solidaria/screens/mapa_clinicas_screen.dart"
    create_file "$LIB_DIR/features/rede_solidaria/screens/agendamento_horario_screen.dart"
    create_file "$LIB_DIR/features/rede_solidaria/screens/checkout_hibrido_screen.dart"
    create_file "$LIB_DIR/features/rede_solidaria/screens/mural_pedidos_ofertas_screen.dart"

    # ------------------------------------------------------------
    # FEATURE: perfil
    # ------------------------------------------------------------
    create_file "$LIB_DIR/features/perfil/screens/menu_perfil_screen.dart"
    create_file "$LIB_DIR/features/perfil/screens/saldo_extrato_screen.dart"
    create_file "$LIB_DIR/features/perfil/screens/meus_agendamentos_screen.dart"
    create_file "$LIB_DIR/features/perfil/screens/configuracoes_conta_screen.dart"
    create_file "$LIB_DIR/features/perfil/screens/suporte_ajuda_screen.dart"

    # ------------------------------------------------------------
    # Estrutura comum (widgets, rotas, modelos) - pastas base
    # ------------------------------------------------------------
    mkdir -p "$LIB_DIR/core/widgets"
    mkdir -p "$LIB_DIR/core/models"
    mkdir -p "$LIB_DIR/core/services"
    create_file "$LIB_DIR/core/routes/app_router.dart"

    echo ""
    echo "Estrutura criada com sucesso em $LIB_DIR"
    echo "Total de telas: 24 (+ arquivo de rotas)"
}

stage_0(){
    etapa_0a
    etapa_0b
    etapa_0c
    etapa_0d
    etapa_0e
}
stage_1(){
    etapa_1a
    etapa_1b
}
stage_2(){
    etapa_2a
    etapa_2b
}

menu(){
    stage_0
    stage_1
    stage_2

    log "Abrindo Code ..."
    code ./
}
etapa_2b
