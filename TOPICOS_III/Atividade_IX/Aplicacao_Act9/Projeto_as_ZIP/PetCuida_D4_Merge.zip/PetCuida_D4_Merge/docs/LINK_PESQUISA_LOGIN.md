# Pesquisa PetCuida

O fluxo PF/PJ direciona o público para a pesquisa de mercado: [Google Forms](https://forms.gle/oPd1dTVgDdNcZHgn9).

O link foi adicionado ao login web e ao login Flutter. Ele abre numa nova aba/aplicação externa e não altera o fluxo de autenticação.
