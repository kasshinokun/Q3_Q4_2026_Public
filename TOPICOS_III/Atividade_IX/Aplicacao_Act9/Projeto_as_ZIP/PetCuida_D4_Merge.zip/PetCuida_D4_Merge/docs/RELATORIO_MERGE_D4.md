# Relatório do merge

## Diagnóstico

`petcuida.zip` contém a evolução visual/web e melhorias de apresentação, mas sua cópia `legacy_flutter` está PF-only. O D4B contém a implementação PJ completa.

## Estratégia

1. D4B foi usado como base para não perder `flutter/features/organization`, `organization_model.dart`, `organization_data_service.dart`, a rota `/organizacao` e o fluxo PJ web.
2. O link do Google Forms foi aplicado aos dois clientes.
3. O `url_launcher` foi adicionado ao Flutter para abertura externa segura.
4. Não foram copiados os ficheiros Flask PF-only de `petcuida.zip`, pois eles substituiriam rotas/repositórios PJ do D4B e causariam regressão funcional.

## Validação esperada

- Login PF: `petcuida` / `meu pet`.
- Login PJ: `clinica.petcuida` / `pet pj`.
- Flutter: `flutter analyze` e `flutter test`.
- Flask: `python -m pytest -q` dentro de `flask/`.
