# PetCuida — merge D4 + melhorias PF/PJ

Este pacote usa **Atividade IX / D4B como base funcional** e incorpora as melhorias compatíveis de `petcuida.zip`, sem remover a interface de Pessoa Jurídica.

## Interfaces preservadas

- **PF / Tutor:** login `petcuida` / `meu pet`, pets, agenda, rede solidária, triagem, perfil e prontuário.
- **PJ / Organização:** login `clinica.petcuida` / `pet pj`, painel de organização, equipe, importação JSON/XLS/XLSX, ofertas, demandas e designação de profissional.
- **Flutter:** projeto completo com Android, iOS, modelos, serviços e `features/organization/`.
- **Web Flask/Vue:** painel PF e painel PJ, com sessão/rotas existentes do D4B.

## Melhorias incorporadas

- Link da pesquisa de mercado no login web e Flutter: https://forms.gle/oPd1dTVgDdNcZHgn9
- Dependência `url_launcher` no Flutter para abrir a pesquisa externamente.
- Mantida a inicialização de localização `pt_BR`, o backend local e os adaptadores remotos do D4B.
- Mantida a arquitetura de organização/PJ em vez de substituí-la pela versão PF-only do `petcuida.zip`.

## Execução web

```bash
cd flask
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
python run.py
```

## Execução Flutter

```bash
cd flutter
flutter pub get
flutter analyze
flutter test
```

## Limites

O projeto continua sendo um protótipo alfa. Antes de produção, audite autenticação/autorização, CSRF, armazenamento de credenciais, regras dos backends remotos e proteção de dados.
