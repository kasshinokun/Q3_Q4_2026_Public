# Changelog — atualização mobile D4

## [1.1.0-mobile-organizations] — 2026-10-07

### Flutter atualizado a partir do dashboard web D4
- Criada a feature modular `flutter/lib/features/organization/` para clínicas, petshops e faculdades/ONGs.
- Adicionado painel mobile com quatro áreas: Visão geral, Equipe, Serviços e Demandas.
- Adicionados modelos locais de organização, profissional, oferta e demanda.
- Adicionado `OrganizationDataService` com seed da Clínica PetCuida, dois profissionais, uma oferta e duas demandas.
- Incluídas ações locais para cadastrar profissional, publicar serviço e aceitar demanda com designação de profissional.
- Adicionado login demo de organização: `clinica.petcuida` / `pet pj`.
- Criado redirecionamento automático de contas de organização para `/organizacao`.
- Incluído atalho de avaliação do painel parceiro na home do tutor.
- Mantida a separação entre dados locais alfa e os adaptadores remotos dormentes existentes.

### Validação
- A estrutura dos imports, providers, rota `/organizacao` e referências aos novos modelos foi verificada por inspeção estática.
- Flutter/Dart não estão instalados neste sandbox; portanto `flutter analyze`/`flutter test` não puderam ser executados aqui.
- A validação final deve ser executada no ambiente Flutter com `flutter pub get` e `flutter analyze`.
