enum OrganizationType { clinic, petshop, collegeOng }

extension OrganizationTypeLabel on OrganizationType {
  String get label => switch (this) {
    OrganizationType.clinic => 'Clínica',
    OrganizationType.petshop => 'Petshop',
    OrganizationType.collegeOng => 'Faculdade / ONG',
  };
  String get shortLabel => switch (this) {
    OrganizationType.clinic => 'Clínica',
    OrganizationType.petshop => 'Petshop',
    OrganizationType.collegeOng => 'Faculdade/ONG',
  };
}

class OrganizationProfile {
  const OrganizationProfile({required this.id, required this.legalName, required this.tradeName, required this.type, required this.location});
  final int id;
  final String legalName;
  final String tradeName;
  final OrganizationType type;
  final String location;
}

class Professional {
  const Professional({required this.id, required this.name, required this.role, this.registration = '', this.active = true});
  final int id;
  final String name;
  final String role;
  final String registration;
  final bool active;

  Professional copyWith({int? id, String? name, String? role, String? registration, bool? active}) => Professional(
    id: id ?? this.id, name: name ?? this.name, role: role ?? this.role,
    registration: registration ?? this.registration, active: active ?? this.active,
  );
}

class ServiceOffer {
  const ServiceOffer({required this.id, required this.name, required this.description, required this.location, required this.priceCents, required this.professionalId});
  final int id;
  final String name;
  final String description;
  final String location;
  final int priceCents;
  final int professionalId;
}

enum DemandStatus { pending, accepted }
class NetworkDemand {
  const NetworkDemand({required this.id, required this.serviceName, required this.petName, required this.scheduledFor, required this.requester, this.professionalId, this.status = DemandStatus.pending});
  final int id;
  final String serviceName;
  final String petName;
  final String scheduledFor;
  final String requester;
  final int? professionalId;
  final DemandStatus status;

  NetworkDemand copyWith({int? professionalId, DemandStatus? status}) => NetworkDemand(
    id: id, serviceName: serviceName, petName: petName, scheduledFor: scheduledFor,
    requester: requester, professionalId: professionalId ?? this.professionalId, status: status ?? this.status,
  );
}
