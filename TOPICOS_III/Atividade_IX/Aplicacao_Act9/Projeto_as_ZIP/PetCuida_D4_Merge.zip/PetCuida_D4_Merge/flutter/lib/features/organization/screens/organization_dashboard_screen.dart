import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/models/organization_model.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/organization_data_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';

class OrganizationDashboardScreen extends StatefulWidget {
  const OrganizationDashboardScreen({super.key});
  @override State<OrganizationDashboardScreen> createState() => _OrganizationDashboardScreenState();
}

class _OrganizationDashboardScreenState extends State<OrganizationDashboardScreen> {
  int _section = 0;
  @override
  Widget build(BuildContext context) {
    final data = context.watch<OrganizationDataService>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('PetCuida · Parceiros'),
        actions: [IconButton(tooltip: 'Sair', onPressed: () => context.read<AuthService>().logout(), icon: const Icon(Icons.logout_rounded))],
      ),
      body: IndexedStack(index: _section, children: [_overview(data), _team(data), _offers(data), _demands(data)]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _section,
        onDestinationSelected: (value) => setState(() => _section = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Visão geral'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Equipe'),
          NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Serviços'),
          NavigationDestination(icon: Icon(Icons.volunteer_activism_outlined), selectedIcon: Icon(Icons.volunteer_activism), label: 'Demandas'),
        ],
      ),
    );
  }

  Widget _page({required String eyebrow, required String title, required String subtitle, required List<Widget> children}) => ListView(
    padding: const EdgeInsets.fromLTRB(18, 20, 18, 28),
    children: [Text(eyebrow, style: const TextStyle(fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.w900, color: AppColors.navy)), const SizedBox(height: 8), Text(title, style: AppTheme.display(size: 25)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(fontSize: 13, color: AppColors.muted, height: 1.45)), const SizedBox(height: 20), ...children],
  );

  Widget _overview(OrganizationDataService data) => _page(
    eyebrow: 'PAINEL DA ORGANIZAÇÃO', title: 'Olá, ${data.organization.tradeName}.', subtitle: 'Vamos cuidar juntos. Organize a equipe, publique serviços e responda demandas da rede.',
    children: [
      _organizationCard(data), const SizedBox(height: 16),
      Row(children: [_metric('${data.professionals.length}', 'profissionais', Icons.groups, AppColors.navySoft), const SizedBox(width: 10), _metric('${data.offers.length}', 'serviços ativos', Icons.storefront, AppColors.pink), const SizedBox(width: 10), _metric('${data.pendingDemands}', 'pendentes', Icons.favorite, AppColors.yellow)]),
      const SizedBox(height: 22), _sectionTitle('Próximas ações'),
      _actionCard(Icons.groups_outlined, 'Minha equipe', 'Cadastre profissionais para aparecerem nas ofertas.', () => setState(() => _section = 1)),
      _actionCard(Icons.add_business_outlined, 'Publicar serviço', 'Crie uma oferta vinculada a um profissional ativo.', () => setState(() => _section = 2)),
      _actionCard(Icons.favorite_border, 'Responder demandas', 'Designe alguém da equipe e aceite um pedido.', () => setState(() => _section = 3)),
    ],
  );

  Widget _organizationCard(OrganizationDataService data) => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppColors.navy, AppColors.navyDeep]), borderRadius: BorderRadius.circular(22)), child: Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.business, color: Colors.white)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(data.organization.type.shortLabel.toUpperCase(), style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 3), Text(data.organization.location, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),]),)]));
  Widget _metric(String value, String label, IconData icon, Color bg) => Expanded(child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 19, color: AppColors.ink), const SizedBox(height: 8), Text(value, style: AppTheme.display(size: 22)), Text(label, style: const TextStyle(fontSize: 10, color: AppColors.muted))])));
  Widget _sectionTitle(String text) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(text, style: AppTheme.display(size: 17)));
  Widget _actionCard(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5), leading: CircleAvatar(backgroundColor: AppColors.navySoft, foregroundColor: AppColors.navy, child: Icon(icon, size: 20)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.muted)), trailing: const Icon(Icons.chevron_right), onTap: onTap));

  Widget _team(OrganizationDataService data) => _page(eyebrow: 'MINHA EQUIPE', title: 'Profissionais que fazem acontecer.', subtitle: 'Os nomes cadastrados aparecerão aos tutores em cada oferta e demanda aceita.', children: [FilledButton.icon(onPressed: () => _addProfessional(context), icon: const Icon(Icons.person_add_alt_1), label: const Text('Inserir profissional')), const SizedBox(height: 18), if (data.professionals.isEmpty) const _Empty(text: 'Cadastre o primeiro profissional.') else ...data.professionals.map((p) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: AppColors.navySoft, child: Text(p.name.substring(0, 1), style: const TextStyle(color: AppColors.navy, fontWeight: FontWeight.w900))), title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${p.role}${p.registration.isEmpty ? '' : ' · ${p.registration}'}'), trailing: const Chip(label: Text('ATIVO', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900))))))]);

  Widget _offers(OrganizationDataService data) => _page(eyebrow: 'SERVIÇOS PUBLICADOS', title: 'Ofertas que chegam a quem precisa.', subtitle: 'Publique serviços vinculados à sua equipe.', children: [FilledButton.icon(onPressed: data.activeProfessionals.isEmpty ? null : () => _addOffer(context), icon: const Icon(Icons.add_business), label: const Text('Publicar serviço')), const SizedBox(height: 18), if (data.offers.isEmpty) const _Empty(text: 'Publique seu primeiro serviço.') else ...data.offers.map((o) { final p = data.professional(o.professionalId); return Card(child: ListTile(contentPadding: const EdgeInsets.all(14), leading: const CircleAvatar(backgroundColor: AppColors.pink, child: Icon(Icons.add_business, color: AppColors.pinkInk)), title: Text(o.name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${o.description}\n${o.location} · ${p?.name ?? 'Profissional'}', maxLines: 3), trailing: Text('R\$ ${(o.priceCents / 100).toStringAsFixed(2).replaceAll('.', ',')}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.success)))); })]);

  Widget _demands(OrganizationDataService data) => _page(eyebrow: 'DEMANDAS DA REDE', title: 'Pedidos esperando uma resposta.', subtitle: 'Designe um profissional e aceite a demanda.', children: [if (data.demands.isEmpty) const _Empty(text: 'Nenhuma demanda ainda.') else ...data.demands.map((d) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Icon(Icons.favorite, color: AppColors.pinkStrong), const SizedBox(width: 10), Expanded(child: Text(d.serviceName, style: const TextStyle(fontWeight: FontWeight.w900))), Chip(label: Text(d.status == DemandStatus.pending ? 'PENDENTE' : 'ACEITA', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900)))]), const SizedBox(height: 8), Text('${d.petName} · ${d.scheduledFor} · solicitante ${d.requester}', style: const TextStyle(fontSize: 12, color: AppColors.muted)), if (d.status == DemandStatus.pending) Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => _acceptDemand(context, data, d), icon: const Icon(Icons.how_to_reg), label: const Text('Designar e aceitar')))])))) ]);

  Future<void> _addProfessional(BuildContext context) async { final name = TextEditingController(); final role = TextEditingController(); final registration = TextEditingController(); final result = await showDialog<List<String>>(context: context, builder: (_) => _FormDialog(title: 'Adicionar profissional', fields: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome'), autofocus: true), TextField(controller: role, decoration: const InputDecoration(labelText: 'Cargo/especialidade')), TextField(controller: registration, decoration: const InputDecoration(labelText: 'Registro profissional'))])); if (result != null && result.length == 3 && result[0].trim().isNotEmpty && result[1].trim().isNotEmpty && context.mounted) context.read<OrganizationDataService>().addProfessional(name: result[0], role: result[1], registration: result[2]); }
  Future<void> _addOffer(BuildContext context) async { final name = TextEditingController(); final description = TextEditingController(); final location = TextEditingController(text: 'Padre Eustáquio'); final price = TextEditingController(text: '60'); final data = context.read<OrganizationDataService>(); int selected = data.activeProfessionals.first.id; final result = await showDialog<List<String>>(context: context, builder: (_) => _FormDialog(title: 'Publicar serviço', fields: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome do serviço'), autofocus: true), TextField(controller: description, decoration: const InputDecoration(labelText: 'Descrição')), TextField(controller: location, decoration: const InputDecoration(labelText: 'Local')), TextField(controller: price, decoration: const InputDecoration(labelText: 'Valor (R\$)'), keyboardType: TextInputType.number), DropdownButtonFormField<int>(value: selected, decoration: const InputDecoration(labelText: 'Profissional'), items: data.activeProfessionals.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) => selected = v ?? selected)])); if (result != null && result.length == 4 && result[0].trim().isNotEmpty && context.mounted) { final cents = ((double.tryParse(result[3].replaceAll(',', '.')) ?? 0) * 100).round(); data.addOffer(name: result[0], description: result[1], location: result[2], priceCents: cents, professionalId: selected); } }
  Future<void> _acceptDemand(BuildContext context, OrganizationDataService data, NetworkDemand demand) async { final selected = await showDialog<int>(context: context, builder: (_) => SimpleDialog(title: const Text('Designar profissional'), children: data.activeProfessionals.map((p) => SimpleDialogOption(onPressed: () => Navigator.pop(context, p.id), child: Text('${p.name}\n${p.role}'))).toList())); if (selected != null && context.mounted) data.acceptDemand(demand.id, selected); }
}

class _FormDialog extends StatelessWidget { const _FormDialog({required this.title, required this.fields}); final String title; final List<Widget> fields; @override Widget build(BuildContext context) => AlertDialog(title: Text(title), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: fields.map((field) => Padding(padding: const EdgeInsets.only(bottom: 12), child: field)).toList()),), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')), FilledButton(onPressed: () { final values = fields.whereType<TextField>().map((f) => f.controller?.text ?? '').toList(); Navigator.pop(context, values); }, child: const Text('Salvar'))]); }
class _Empty extends StatelessWidget { const _Empty({required this.text}); final String text; @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.line)), child: Center(child: Text(text, style: const TextStyle(color: AppColors.muted)))); }
