import 'package:flutter/foundation.dart';
import '../models/organization_model.dart';

/// Estado local do painel parceiro. Reproduz o contrato do dashboard web D4
/// sem exigir backend para a avaliação da equipe mobile.
class OrganizationDataService extends ChangeNotifier {
  OrganizationDataService()
      : organization = const OrganizationProfile(
          id: 1,
          legalName: 'Clínica PetCuida Serviços Veterinários LTDA',
          tradeName: 'Clínica PetCuida',
          type: OrganizationType.clinic,
          location: 'Padre Eustáquio, Belo Horizonte',
        ),
        professionals = [
          const Professional(id: 1, name: 'Dra. Camila Andrade', role: 'Médica veterinária', registration: 'CRMV-MG 00000'),
          const Professional(id: 2, name: 'Marcos Lima', role: 'Tosador'),
        ],
        offers = [
          const ServiceOffer(id: 1, name: 'Consulta veterinária de rotina', description: 'Avaliação clínica geral com profissional credenciado.', location: 'Padre Eustáquio', priceCents: 6000, professionalId: 1),
        ],
        demands = [
          const NetworkDemand(id: 1, serviceName: 'Consulta veterinária de rotina', petName: 'Rex', scheduledFor: 'Amanhã · 14:00', requester: 'Marcos T.'),
          const NetworkDemand(id: 2, serviceName: 'Banho e tosa', petName: 'Luna', scheduledFor: '15/10 · 09:00', requester: 'Renata A.'),
        ];

  final OrganizationProfile organization;
  final List<Professional> professionals;
  final List<ServiceOffer> offers;
  final List<NetworkDemand> demands;

  int get pendingDemands => demands.where((d) => d.status == DemandStatus.pending).length;
  List<Professional> get activeProfessionals => professionals.where((p) => p.active).toList();
  Professional? professional(int id) {
    for (final item in professionals) {
      if (item.id == id) return item;
    }
    return null;
  }

  void addProfessional({required String name, required String role, String registration = ''}) {
    final next = professionals.isEmpty ? 1 : professionals.map((p) => p.id).reduce((a, b) => a > b ? a : b) + 1;
    professionals.add(Professional(id: next, name: name, role: role, registration: registration));
    notifyListeners();
  }

  void addOffer({required String name, required String description, required String location, required int priceCents, required int professionalId}) {
    final next = offers.isEmpty ? 1 : offers.map((o) => o.id).reduce((a, b) => a > b ? a : b) + 1;
    offers.add(ServiceOffer(id: next, name: name, description: description, location: location, priceCents: priceCents, professionalId: professionalId));
    notifyListeners();
  }

  void acceptDemand(int demandId, int professionalId) {
    final index = demands.indexWhere((d) => d.id == demandId);
    if (index < 0) return;
    demands[index] = demands[index].copyWith(professionalId: professionalId, status: DemandStatus.accepted);
    notifyListeners();
  }
}
