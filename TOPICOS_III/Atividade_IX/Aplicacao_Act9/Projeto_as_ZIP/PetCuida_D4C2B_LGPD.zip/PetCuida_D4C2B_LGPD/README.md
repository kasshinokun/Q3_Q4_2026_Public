# PetCuida — D4C2B LGPD

Release alfa que consolida a correção do merge D4, as melhorias de identidade visual já recuperadas em `PetCuida_D4C_LGPD`, os fluxos PF/PJ e uma revisão técnica de privacidade. Os projetos são independentes: **Flask + Vue** (API e aplicação web demonstrativa) e **Flutter** (protótipo móvel local).

## O que foi corrigido nesta revisão

- Corrigida a migração SQLite legada que interrompia o arranque por criar índices antes das colunas adicionadas por migração.
- O cookie guarda somente um ID aleatório; conta e organização são validadas no registro server-side. IDs enviados pelo cliente não escolhem o escopo.
- Separação de permissões Tutor/PF e Organização/PJ, validação de sessão contra o registo e rotação/revogação no login.
- Senhas de novas contas e seeds ficam em hash; senha em texto puro de versões antigas é atualizada para hash após autenticação válida.
- Limpeza de logout/expiração remove dependências em ordem, preserva os dados seed e os registros de auditoria; contas temporárias podem voltar a autenticar sem perder os próprios dados enquanto a sessão continua válida.
- Uploads temporários de imagem são autenticados e verificam MIME e assinatura do ficheiro; a rota de manutenção exige segredo explícito.
- Chaves compostas nas listas Vue da agenda evitam colisões entre IDs de tipos diferentes.
- Flutter inclui aviso de privacidade para o protótipo; o limite mínimo de senha para novas contas foi alinhado em oito caracteres.

## Executar o Flask

```bash
cd flask
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
python run.py
```

Abrir `http://127.0.0.1:5000`. Os logins de demonstração são `petcuida` / `meu pet` (Tutor) e `clinica.petcuida` / `pet pj` (Organização). A base SQLite é criada no primeiro arranque em `flask/app/storage/petcuida.db`; não é distribuída no ZIP.

## Executar o Flutter

```bash
cd flutter
flutter pub get
flutter analyze
flutter run
```

A app Flutter utiliza estado e dados de demonstração locais, sem ligação ao backend Flask nesta release. O SDK Flutter/Dart deve estar instalado; a validação final de compilação deve ser feita num ambiente com o SDK.

## Privacidade e segurança

Consulte [`flask/PRIVACIDADE_LGPD.md`](flask/PRIVACIDADE_LGPD.md) para configuração, ciclo de vida de dados e limitações. O PDF recebido foi preservado como `docs/PRIVACIDADE_LGPD_ORIGINAL.pdf`. O aviso Flutter distingue o protótipo da pesquisa externa Google Forms.

**Esta continua a ser uma release alfa demonstrativa, não uma aplicação pronta para dados reais.** Ainda requer avaliação jurídica e operacional do controlador, política de retenção, canal para direitos dos titulares, proteção CSRF explícita, limites de tentativas de login e validação de implantação. Backends remotos são recusados até terem paridade de sessão. Não utilize dados pessoais ou de saúde reais.

## Validação desta entrega

- Testes Flask: **17 aprovados**.
- Migração exercitada com esquema anterior sem colunas temporárias.
- JavaScript principal validado sintaticamente; assets Vue e desenho da release anterior preservados.
- `flutter analyze`/build não executados neste ambiente porque Flutter/Dart não estão instalados.
