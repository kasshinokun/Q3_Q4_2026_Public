# Relatório de revisão — PetCuida_D4C2B_LGPD

## Base de trabalho e objetivo

A release foi preparada a partir de `PetCuida_D4C_LGPD`, preservando as melhorias de interface web já reconciliadas com `petcuida.zip`, o fluxo Tutor/PF e o painel Organização/PJ. A análise seguiu também o pedido e os critérios recuperados da tarefa de referência indicada pelo usuário: conservar a separação PF/PJ, as telas e a aparência pretendida ao corrigir a base.

## Defeitos confirmados

1. **Bloqueador — arranque em base legada.** O DDL criava índices `temporary_session_id` antes das migrações adicionarem a coluna. Reprodução: `OperationalError: no such column: temporary_session_id` ao copiar a base incluída para um caminho de teste e chamar `create_app()`.
2. **Autorização baseada em ID do navegador.** Rotas utilizavam `user_id`/`organization_id` do corpo/query string; era possível solicitar IDs de outra conta/organização.
3. **Limpeza de sessão com integridade referencial.** A rotina removia apenas linhas marcadas diretamente com o ID da sessão e podia deixar demandas dependentes ou falhar ao apagar entidades-pai.
4. **Hash/agenda.** IDs independentes de marcações e demandas podiam colidir como `:key` do Vue; a composição da agenda também não garantia ordenação conjunta.
5. **Privacidade incompleta.** Rotas de foto e limpeza não exigiam autenticação/segredo de manutenção; a foto validava apenas extensão MIME, não a assinatura do conteúdo. O cadastro armazenava senhas em texto claro.
6. **Documentação desatualizada.** README dizia que não havia sessão/authorization e afirmava que senhas eram texto puro sem indicar os limites após a mudança; havia credenciais/schema e um banco binário seed incluídos no pacote.

## Correções nesta release

- Migrações de colunas ocorrem antes dos índices; seed idempotente e geração de hash para seeds em novas bases.
- Autenticação Flask com hash `scrypt`; senhas legadas são atualizadas após login válido; novas contas exigem 8–256 caracteres.
- O cookie guarda só o ID aleatório; identidade, tipo de conta e organização ficam no registro server-side e são revalidados. Sessões revogadas não voltam a autorizar chamadas.
- A inicialização recusa Firestore/Supabase nesta release, evitando operar com adaptadores sem paridade de sessão/autorização.
- IDs fornecidos pelo cliente são ignorados para escopo. Frontend deixa de enviá-los.
- Reentrada numa conta temporária transfere os dados da sessão anterior para a nova; logout/expiração limpam os registros transitivos em ordem segura e preservam seeds e auditoria.
- Endpoints de foto requerem autenticação e validam assinatura associada ao MIME. Endpoint remoto de expurgo requer token configurado; caso contrário responde `503`.
- Agenda recebe chaves compostas (`appointment-*`/`demand-*`) e é ordenada por data; dashboard PJ usa chaves tipadas.
- Flutter recebe aviso explícito de protótipo/dados e formulário local passa a exigir oito caracteres.
- README e nota técnica LGPD atualizados; banco SQLite de execução deixa de ser distribuído. PDF original fornecido é preservado com sufixo `ORIGINAL`.

## Testes/validação

- `python -m pytest -q` em Flask: **17 passed**.
- Inclui teste de esquema legado, migração de senha em texto claro, tentativa de trocar identidade por ID, separação Tutor/PJ, importação, criação/aceitação de demanda, purge transitivo, fotos e token de limpeza.
- JavaScript web: a sintaxe foi verificada com Node.js durante a revisão; deve ser repetida na validação final do pacote.
- Flutter/Dart não estão instalados neste ambiente. O código Flutter foi revisto estaticamente, mas `flutter analyze`, testes Flutter e builds Android não foram executados.

## Riscos ainda abertos

Não declarar conformidade legal nem usar dados pessoais/saúde reais. Antes de produção ainda faltam, entre outros: CSRF explícito, throttling/rate-limit de login, validação robusta de imagens, política de retenção de logs e backups, canal de direitos dos titulares, revisão de deploy/segredos e paridade dos backends remotos. As contas seed são públicas por conceção demonstrativa.
