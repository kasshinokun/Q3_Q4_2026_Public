"""Privacidade por padrão para a demonstração PetCuida.

Os dados funcionais recebem temporary_session_id e podem ser eliminados sem
alterar seeds. Auditoria minimizada. Esta referência técnica não substitui a
validação jurídica de bases legais, retenção nem direitos do titular.
"""
from __future__ import annotations
import hashlib
import json
import secrets
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from flask import current_app, request, session
from .db import db


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_session_id() -> str:
    return secrets.token_urlsafe(32)


def privacy_hash(value: str | None) -> str | None:
    if not value:
        return None
    salt = str(current_app.config.get("PRIVACY_HASH_SALT") or current_app.config["SECRET_KEY"])
    return hashlib.sha256(f"{salt}:{value}".encode("utf-8", "replace")).hexdigest()


def session_id() -> str:
    sid = session.get("session_id")
    if not sid:
        sid = new_session_id()
        session["session_id"] = sid
        session.permanent = True
    return sid


def ensure_session(path: str, sid: str | None = None) -> str:
    sid = sid or session_id()
    current = now_iso()
    expiry = (datetime.now(timezone.utc) + timedelta(minutes=int(current_app.config["SESSION_TTL_MINUTES"]))).isoformat()
    with db(path) as conn:
        existing = conn.execute(
            "SELECT user_id,username_hash,account_type,organization_id FROM session_registry WHERE session_id=?",
            (sid,),
        ).fetchone()
        conn.execute(
            """INSERT INTO session_registry(session_id,user_id,username_hash,account_type,organization_id,started_at,last_seen,expires_at)
               VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET
               last_seen=excluded.last_seen, expires_at=excluded.expires_at""",
            (sid, existing["user_id"] if existing else None, existing["username_hash"] if existing else None,
             existing["account_type"] if existing else None, existing["organization_id"] if existing else None,
             current, current, expiry),
        )
    return sid


def bind_user(path: str, user: dict[str, Any]) -> None:
    sid = session_id()
    ensure_session(path, sid)
    with db(path) as conn:
        conn.execute(
            "UPDATE session_registry SET user_id=?,username_hash=?,account_type=?,organization_id=? WHERE session_id=?",
            (user.get("id"), privacy_hash(user.get("username")), user.get("account_type"),
             user.get("organization_id"), sid),
        )
    # Flask assina, mas não cifra, o conteúdo do cookie. Apenas o ID aleatório
    # permanece no cliente; identidade e escopo PJ ficam no registro server-side.
    for key in ("user_id", "username", "username_hash", "account_type", "organization_id"):
        session.pop(key, None)


def log_event(path: str, event_type: str, *, status_code: int | None = None,
              metadata: dict[str, Any] | None = None, sid: str | None = None) -> None:
    """Regista metadados mínimos; nunca regista senha, corpo, foto ou ficheiro."""
    sid = sid or session_id()
    forbidden = {"password", "body", "photo", "file", "email", "phone", "address"}
    safe_metadata = {str(k): str(v)[:160] for k, v in (metadata or {}).items()
                     if str(k).lower() not in forbidden}
    with db(path) as conn:
        p = conn.execute(
            "SELECT user_id,username_hash,account_type FROM session_registry WHERE session_id=?", (sid,)
        ).fetchone()
        conn.execute(
            """INSERT INTO access_logs
            (session_id,user_id,username_hash,account_type,event_type,route,method,status_code,ip_hash,user_agent_hash,metadata_json,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (sid, p["user_id"] if p else None, p["username_hash"] if p else None,
             p["account_type"] if p else None, event_type,
             request.path if request else None, request.method if request else None, status_code,
             privacy_hash(request.remote_addr if request else None),
             privacy_hash(request.headers.get("User-Agent") if request else None),
             json.dumps(safe_metadata, ensure_ascii=False, separators=(",", ":")), now_iso()),
        )


def _session_folder(sid: str) -> Path:
    return Path(current_app.config["TEMP_UPLOAD_DIR"]) / sid


def _count_session_files(sid: str) -> int:
    base = _session_folder(sid)
    return sum(1 for path in base.rglob("*") if path.is_file()) if base.exists() else 0


def _remove_session_files(sid: str) -> None:
    shutil.rmtree(_session_folder(sid), ignore_errors=True)


def rebind_session_data(path: str, old_sid: str, new_sid: str) -> dict[str, int]:
    """Move a conta que acabou de se autenticar para um ID de sessão novo."""
    tables = ("organizations", "users", "pets", "professionals", "service_offers", "appointments", "demand_requests")
    moved: dict[str, int] = {}
    timestamp = now_iso()
    with db(path) as conn:
        for table in tables:
            cur = conn.execute(f"UPDATE {table} SET temporary_session_id=? WHERE temporary_session_id=?", (new_sid, old_sid))
            moved[table] = cur.rowcount
        conn.execute("UPDATE session_registry SET ended_at=?,expires_at=?,purged_at=? WHERE session_id=?",
                     (timestamp, timestamp, timestamp, old_sid))
        conn.execute(
            "INSERT INTO access_logs(session_id,event_type,route,method,status_code,metadata_json,created_at) VALUES (?,?,?,?,?,?,?)",
            (old_sid, "temporary_data_rebound", "/api/auth/login", "POST", 200,
             json.dumps({"moved": moved}, separators=(",", ":")), timestamp),
        )
    # Uploads são temporários e não estão associados a uma entidade persistente.
    _remove_session_files(old_sid)
    return moved


def purge_session_data(path: str, sid: str, *, reason: str = "session_end") -> dict[str, int]:
    """Apaga dados da sessão e dependências que ficariam órfãs; preserva seeds/logs."""
    removed = {"demand_requests": 0, "appointments": 0, "service_offers": 0,
               "professionals": 0, "pets": 0, "users": 0, "organizations": 0,
               "files": _count_session_files(sid)}
    with db(path) as conn:
        user_ids = [r[0] for r in conn.execute("SELECT id FROM users WHERE temporary_session_id=?", (sid,))]
        organization_ids = [r[0] for r in conn.execute("SELECT id FROM organizations WHERE temporary_session_id=?", (sid,))]
        professional_ids = [r[0] for r in conn.execute("SELECT id FROM professionals WHERE temporary_session_id=?", (sid,))]
        query = "SELECT id FROM service_offers WHERE temporary_session_id=?"
        params: list[Any] = [sid]
        if organization_ids:
            query += " OR organization_id IN (" + ",".join("?" for _ in organization_ids) + ")"
            params.extend(organization_ids)
        if professional_ids:
            query += " OR professional_id IN (" + ",".join("?" for _ in professional_ids) + ")"
            params.extend(professional_ids)
        offer_ids = [r[0] for r in conn.execute(query, params)]

        demand_clauses = ["temporary_session_id=?"]
        demand_params: list[Any] = [sid]
        if user_ids:
            demand_clauses.append("user_id IN (" + ",".join("?" for _ in user_ids) + ")")
            demand_params.extend(user_ids)
        if offer_ids:
            demand_clauses.append("offer_id IN (" + ",".join("?" for _ in offer_ids) + ")")
            demand_params.extend(offer_ids)
        cur = conn.execute("DELETE FROM demand_requests WHERE " + " OR ".join(demand_clauses), demand_params)
        removed["demand_requests"] = cur.rowcount

        appointment_clauses = ["temporary_session_id=?"]
        appointment_params: list[Any] = [sid]
        if user_ids:
            appointment_clauses.append("user_id IN (" + ",".join("?" for _ in user_ids) + ")")
            appointment_params.extend(user_ids)
        cur = conn.execute("DELETE FROM appointments WHERE " + " OR ".join(appointment_clauses), appointment_params)
        removed["appointments"] = cur.rowcount

        if offer_ids:
            marks = ",".join("?" for _ in offer_ids)
            cur = conn.execute(f"DELETE FROM service_offers WHERE id IN ({marks})", offer_ids)
        else:
            cur = conn.execute("DELETE FROM service_offers WHERE temporary_session_id=?", (sid,))
        removed["service_offers"] = cur.rowcount
        cur = conn.execute("DELETE FROM professionals WHERE temporary_session_id=?", (sid,))
        removed["professionals"] = cur.rowcount

        pet_clauses = ["temporary_session_id=?"]
        pet_params: list[Any] = [sid]
        if user_ids:
            pet_clauses.append("user_id IN (" + ",".join("?" for _ in user_ids) + ")")
            pet_params.extend(user_ids)
        cur = conn.execute("DELETE FROM pets WHERE " + " OR ".join(pet_clauses), pet_params)
        removed["pets"] = cur.rowcount
        cur = conn.execute("DELETE FROM users WHERE temporary_session_id=?", (sid,))
        removed["users"] = cur.rowcount
        cur = conn.execute("DELETE FROM organizations WHERE temporary_session_id=?", (sid,))
        removed["organizations"] = cur.rowcount

        timestamp = now_iso()
        conn.execute("UPDATE session_registry SET ended_at=?,expires_at=?,purged_at=? WHERE session_id=?",
                     (timestamp, timestamp, timestamp, sid))
        conn.execute(
            "INSERT INTO access_logs(session_id,event_type,route,method,status_code,metadata_json,created_at) VALUES (?,?,?,?,?,?,?)",
            (sid, "temporary_data_purged", "/api/auth/logout", "POST", 200,
             json.dumps({"reason": reason, "removed": removed}, separators=(",", ":")), timestamp),
        )
    _remove_session_files(sid)
    return removed


def purge_expired_sessions(path: str) -> int:
    now = now_iso()
    with db(path) as conn:
        rows = conn.execute(
            "SELECT session_id FROM session_registry WHERE purged_at IS NULL AND (ended_at IS NOT NULL OR expires_at < ?)",
            (now,),
        ).fetchall()
    count = 0
    for row in rows:
        purge_session_data(path, row["session_id"], reason="expired")
        count += 1
    return count


def _valid_image(content_type: str, header: bytes) -> str | None:
    if content_type == "image/jpeg" and header.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if content_type == "image/png" and header.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if content_type == "image/webp" and len(header) >= 12 and header[:4] == b"RIFF" and header[8:12] == b"WEBP":
        return ".webp"
    return None


def save_temp_photo(sid: str, file_storage, kind: str) -> dict[str, str]:
    if kind not in {"profile", "pet"}:
        raise ValueError("Tipo de foto inválido.")
    content_type = (file_storage.mimetype or "").lower()
    header = file_storage.stream.read(16)
    file_storage.stream.seek(0)
    extension = _valid_image(content_type, header)
    if not extension:
        raise ValueError("Formato ou conteúdo de foto inválido. Envie um JPG, PNG ou WebP real.")
    token = secrets.token_urlsafe(16)
    folder = _session_folder(sid) / kind
    folder.mkdir(parents=True, exist_ok=True)
    file_storage.save(folder / f"{token}{extension}")
    return {"token": token, "kind": kind}
