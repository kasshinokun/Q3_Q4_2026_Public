"""Rotas da API demonstrativa, com identidade derivada da sessão assinada."""
import secrets
from flask import Blueprint, current_app, jsonify, request, session
from .db import db
from .repository import build_repository, normalize_professional_row, parse_professionals_file
from .privacy import (bind_user, log_event, new_session_id, purge_session_data,
                      rebind_session_data, session_id, save_temp_photo)

api = Blueprint("api", __name__)


def repo():
    return build_repository(current_app.config)


def ok(data):
    return jsonify({"ok": True, **data})


def body_json():
    value = request.get_json(silent=True)
    return value if isinstance(value, dict) else {}


def sid():
    return session_id()


def bad_request(error):
    return jsonify({"ok": False, "error": str(error)}), 400


def require_identity(account_type=None):
    if current_app.config["BACKEND"].lower() == "sqlite":
        current_sid = session.get("session_id")
        if not current_sid:
            return None, (jsonify({"ok": False, "error": "Inicie sessão para continuar."}), 401)
        with db(current_app.config["DB_PATH"]) as conn:
            registry = conn.execute(
                "SELECT user_id,account_type,organization_id,purged_at FROM session_registry WHERE session_id=?",
                (current_sid,),
            ).fetchone()
            if not registry or registry["purged_at"]:
                return None, (jsonify({"ok": False, "error": "A sessão expirou. Inicie sessão novamente."}), 401)
            user_id = registry["user_id"]
            actual_type = registry["account_type"]
            organization_id = registry["organization_id"]
            user = conn.execute("SELECT account_type,organization_id FROM users WHERE id=?", (user_id,)).fetchone()
        if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0 or actual_type not in {"tutor", "organization"} or not user or user["account_type"] != actual_type:
            return None, (jsonify({"ok": False, "error": "A sessão expirou. Inicie sessão novamente."}), 401)
        if actual_type == "organization" and user["organization_id"] != organization_id:
            return None, (jsonify({"ok": False, "error": "A sessão de organização não é válida."}), 401)
    else:
        user_id = session.get("user_id")
        actual_type = session.get("account_type")
        organization_id = session.get("organization_id")
        if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0 or actual_type not in {"tutor", "organization"}:
            return None, (jsonify({"ok": False, "error": "Inicie sessão para continuar."}), 401)
    if account_type and actual_type != account_type:
        return None, (jsonify({"ok": False, "error": "Esta operação não está disponível para este tipo de conta."}), 403)
    return {"id": user_id, "account_type": actual_type, "organization_id": organization_id}, None


def organization_id_from_session():
    identity, error = require_identity("organization")
    if error:
        return None, error
    org_id = identity["organization_id"]
    if isinstance(org_id, bool) or not isinstance(org_id, int) or org_id <= 0:
        return None, (jsonify({"ok": False, "error": "A sessão não possui organização válida."}), 403)
    return org_id, None


def rotate_login_session(user):
    old = session.get("session_id")
    owner_session = user.pop("_temporary_session_id", None)
    new = new_session_id()
    if owner_session:
        rebind_session_data(current_app.config["DB_PATH"], owner_session, new)
    if old and old != owner_session:
        purge_session_data(current_app.config["DB_PATH"], old, reason="login_session_rotation")
    session.clear()
    session["session_id"] = new
    session.permanent = True
    bind_user(current_app.config["DB_PATH"], user)


@api.post("/auth/login")
def login():
    body = body_json()
    user = repo().authenticate(body.get("username", ""), body.get("password", ""))
    if not user:
        log_event(current_app.config["DB_PATH"], "login_failed", status_code=401)
        return jsonify({"ok": False, "error": "Usuário ou senha incorretos."}), 401
    rotate_login_session(user)
    log_event(current_app.config["DB_PATH"], "login_succeeded", status_code=200)
    return ok({"user": user})


@api.post("/auth/register")
def register():
    existing_identity, _ = require_identity()
    if existing_identity:
        return jsonify({"ok": False, "error": "Termine a sessão atual antes de criar outra conta."}), 409
    old = session.get("session_id")
    if old:
        purge_session_data(current_app.config["DB_PATH"], old, reason="registration_session_rotation")
    session.clear()
    session["session_id"] = new_session_id()
    session.permanent = True
    try:
        user = repo().register(body_json(), temporary_session_id=sid())
        bind_user(current_app.config["DB_PATH"], user)
        log_event(current_app.config["DB_PATH"], "account_created", status_code=200,
                  metadata={"account_type": user.get("account_type")})
        return ok({"user": user})
    except (KeyError, ValueError, TypeError) as error:
        log_event(current_app.config["DB_PATH"], "account_creation_failed", status_code=400)
        return bad_request(error)


@api.post("/auth/logout")
def logout():
    current = sid()
    log_event(current_app.config["DB_PATH"], "logout", status_code=200)
    removed = purge_session_data(current_app.config["DB_PATH"], current, reason="explicit_logout")
    session.clear()
    return ok({"purged": removed})


@api.post("/auth/cleanup")
def cleanup():
    expected = current_app.config.get("CLEANUP_TOKEN")
    if not expected:
        return jsonify({"ok": False, "error": "A limpeza remota não está configurada; use o comando local de manutenção."}), 503
    supplied = request.headers.get("X-PetCuida-Cleanup-Token", "")
    if not secrets.compare_digest(str(expected), supplied):
        return jsonify({"ok": False, "error": "Não autorizado."}), 403
    from .privacy import purge_expired_sessions
    count = purge_expired_sessions(current_app.config["DB_PATH"])
    log_event(current_app.config["DB_PATH"], "expired_sessions_cleanup", status_code=200,
              metadata={"sessions": count})
    return ok({"expired_sessions": count})


@api.post("/uploads/photo")
def upload_photo():
    identity, error = require_identity()
    if error:
        return error
    try:
        if "file" not in request.files:
            raise ValueError("Envie uma foto.")
        result = save_temp_photo(sid(), request.files["file"], request.form.get("kind", "pet"))
        log_event(current_app.config["DB_PATH"], "temporary_photo_created", status_code=200,
                  metadata={"kind": result["kind"]})
        return ok({"photo": {"token": result["token"], "kind": result["kind"]}})
    except (KeyError, ValueError, TypeError) as error:
        log_event(current_app.config["DB_PATH"], "temporary_photo_rejected", status_code=400)
        return bad_request(error)


@api.get("/pets")
def pets():
    identity, error = require_identity("tutor")
    if error:
        return error
    return ok({"pets": repo().list_pets(identity["id"])})


@api.post("/pets")
def add_pet():
    identity, error = require_identity("tutor")
    if error:
        return error
    body = body_json()
    try:
        result = repo().add_pet(identity["id"], body, temporary_session_id=sid())
        log_event(current_app.config["DB_PATH"], "pet_created", status_code=200)
        return ok({"id": result})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.get("/services")
def services():
    identity, error = require_identity()
    if error:
        return error
    return ok({"services": repo().services()})


@api.get("/appointments")
def appointments():
    identity, error = require_identity("tutor")
    if error:
        return error
    return ok({"appointments": repo().appointments(identity["id"])})


@api.post("/appointments")
def book():
    identity, error = require_identity("tutor")
    if error:
        return error
    body = body_json()
    try:
        result = repo().book(identity["id"], body, temporary_session_id=sid())
        log_event(current_app.config["DB_PATH"], "appointment_created", status_code=200)
        return ok({"id": result})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.get("/organization/overview")
def organization_overview():
    org_id, error = organization_id_from_session()
    if error:
        return error
    try:
        repository = repo()
        return ok({"organization": repository.organization(org_id),
                   "professionals": repository.professionals(org_id),
                   "offers": repository.service_offers(org_id),
                   "demands": repository.demands(org_id)})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.post("/organization/professionals")
def add_professional():
    org_id, error = organization_id_from_session()
    if error:
        return error
    try:
        return ok({"id": repo().add_professional(org_id, body_json(), temporary_session_id=sid())})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.post("/organization/professionals/import")
def import_professionals():
    org_id, error = organization_id_from_session()
    if error:
        return error
    try:
        if "file" not in request.files:
            raise ValueError("Envie um arquivo JSON, XLS ou XLSX.")
        rows = parse_professionals_file(request.files["file"])
        normalized = [normalize_professional_row(row) for row in rows]
        normalized = [row for row in normalized if row]
        if not normalized:
            raise ValueError("O arquivo não contém profissionais válidos.")
        created = repo().add_professionals_bulk(org_id, normalized, temporary_session_id=sid())
        log_event(current_app.config["DB_PATH"], "professionals_imported", status_code=200,
                  metadata={"count": len(created)})
        return ok({"created": len(created)})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.post("/organization/offers")
def add_offer():
    org_id, error = organization_id_from_session()
    if error:
        return error
    try:
        return ok({"id": repo().add_offer(org_id, body_json(), temporary_session_id=sid())})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.post("/organization/demands/<int:demand_id>/accept")
def accept_demand(demand_id):
    org_id, error = organization_id_from_session()
    if error:
        return error
    try:
        return ok({"id": repo().accept_demand(org_id, demand_id, body_json().get("professional_id"))})
    except (KeyError, ValueError, TypeError) as error:
        return bad_request(error)


@api.get("/triage")
def triage():
    identity, error = require_identity("tutor")
    if error:
        return error
    return ok({"disclaimer": "Triagem orientativa; não substitui avaliação veterinária.",
               "questions": ["O pet está com dificuldade para respirar?",
                             "Há sangramento intenso ou perda de consciência?",
                             "O sintoma começou de forma súbita?"]})


@api.get("/status")
def status():
    return ok({"app": "PetCuida", "version": "1.5.3-alpha", "revision": "d4c2b-lgpd",
               "backend": current_app.config["BACKEND"], "demo": current_app.config["BACKEND"] == "sqlite"})
