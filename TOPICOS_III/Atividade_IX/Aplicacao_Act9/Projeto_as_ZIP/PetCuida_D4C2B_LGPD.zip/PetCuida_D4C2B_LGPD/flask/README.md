# PetCuida Web — Flask + Vue (D4C2B LGPD)

Aplicação alfa demonstrativa em Flask/SQLite com frontend Vue 3 servido localmente, sem CDN. Revisão da API: `1.5.3-alpha` (`d4c2b-lgpd`).

## Requisitos e execução

- Python 3.10+
- Dependências listadas em `requirements.txt`

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
python run.py
```

A base `app/storage/petcuida.db` é criada/migrada no primeiro arranque. Para mudar o caminho, configure `PETCUIDA_DB_PATH`. O teste `test_legacy_database_migrates_before_creating_indexes` exercita um esquema anterior à coluna `temporary_session_id`.

## Logins fictícios

| Perfil | Utilizador | Senha de demonstração |
|---|---|---|
| Tutor/PF | `petcuida` | `meu pet` |
| Organização/PJ | `clinica.petcuida` | `pet pj` |

As credenciais seed são públicas e **não são seguras para produção**. Novas contas exigem senha com 8–256 caracteres e guardam hash; contas temporárias e os dados associados são removidos no logout/expiração, sem apagar seeds.

## Configuração de implantação

Defina pelo menos:

```bash
export SECRET_KEY="<segredo aleatório longo>"
export PETCUIDA_PRIVACY_HASH_SALT="<outro segredo aleatório>"
export PETCUIDA_ENV=production
export PETCUIDA_COOKIE_SECURE=1
export PETCUIDA_SESSION_TTL_MINUTES=45
export PETCUIDA_TEMP_UPLOAD_DIR=/caminho/privado/petcuida-uploads
export PETCUIDA_DB_PATH=/caminho/privado/petcuida.db
```

Com `PETCUIDA_ENV=production`, os dois segredos devem ser distintos e ter pelo menos 32 caracteres; `PETCUIDA_COOKIE_SECURE=1` também é obrigatório. Sirva apenas por HTTPS, restrinja permissões do SQLite e da pasta temporária, proteja backups e defina retenção auditável. Para habilitar limpeza remota, configure também `PETCUIDA_CLEANUP_TOKEN` e envie o valor no header `X-PetCuida-Cleanup-Token` a `POST /api/auth/cleanup`. Sem token, a rota responde `503`; a limpeza local permanece disponível pelo módulo de privacidade.

## Funcionalidade

- Tutor: área de pets, serviços, pedidos/agendamentos e triagem orientativa.
- Organização: equipa, importação JSON/XLS/XLSX, ofertas e aceitação de demandas com designação profissional.
- Sessão: o cookie assinado contém apenas um ID aleatório; identidade e escopo PJ vêm do registro server-side, não de IDs enviados pelo cliente.
- Imagens temporárias: autenticação obrigatória, limite total de pedido de 2 MiB, MIME/assinatura JPG/PNG/WebP e armazenamento fora dos arquivos públicos.

## Limitações

SQLite é o único backend testado de ponta a ponta; a inicialização falha de forma explícita se `PETCUIDA_BACKEND` apontar para um adaptador remoto sem paridade de sessão/autorização. A demonstração ainda não implementa token CSRF explícito, limitação de tentativas de login, fluxo de atendimento dos direitos dos titulares nem política de retenção pronta para produção. Hashes de IP/User-Agent/username permanecem nos logs até que uma rotina de retenção aprovada os remova. Consulte `PRIVACIDADE_LGPD.md`; isto não é parecer jurídico nem declaração de conformidade.
