from io import BytesIO
import json
import sqlite3
import pytest
from app import create_app
from app.db import connect


@pytest.fixture()
def app_client(tmp_path):
    app = create_app({"TESTING": True, "DB_PATH": str(tmp_path / "test.db"),
                      "TEMP_UPLOAD_DIR": str(tmp_path / "uploads")})
    return app, app.test_client()


def login(client, account="tutor"):
    credentials = {"tutor": ("petcuida", "meu pet"), "organization": ("clinica.petcuida", "pet pj")}[account]
    response = client.post("/api/auth/login", json={"username": credentials[0], "password": credentials[1]})
    assert response.status_code == 200
    return response.json["user"]


def test_routes_manifest_and_local_frontend(app_client):
    app, client = app_client
    page = client.get("/")
    status = client.get("/api/status")
    assert page.status_code == 200
    assert b"/static/js/main.js" in page.data
    assert b"fonts.googleapis.com" not in page.data
    assert status.json["version"] == "1.5.3-alpha"
    assert status.json["revision"] == "d4c2b-lgpd"
    assert client.get("/manus-routes.json").json["routes"][0]["path"] == "/"


def test_demo_tutor_and_organization_accounts(app_client):
    app, client = app_client
    user = login(client)
    assert user["account_type"] == "tutor"
    assert client.get("/api/pets").json["pets"][0]["name"] == "Rex"
    services = client.get("/api/services").json["services"]
    assert len(services) == 5
    assert any(item["offer_type"] == "offer" and item["professional_name"] for item in services)
    assert client.get("/api/organization/overview").status_code == 403

    other = app.test_client()
    partner = login(other, "organization")
    overview = other.get("/api/organization/overview").json
    assert partner["account_type"] == "organization"
    assert overview["professionals"] and overview["offers"]
    assert other.get("/api/pets").status_code == 403


def test_organization_can_publish_accept_and_tutor_sees_attribution(app_client):
    app, _ = app_client
    org_client = app.test_client()
    tutor_client = app.test_client()
    organization = login(org_client, "organization")
    overview = org_client.get("/api/organization/overview").json
    professional = overview["professionals"][0]
    created = org_client.post("/api/organization/offers", json={
        "organization_id": 99999, "professional_id": professional["id"],
        "name": "Plantão demonstrativo", "description": "Atendimento alfa", "location": "Centro", "price_cents": 1000,
    })
    assert created.status_code == 200
    assert login(tutor_client)["account_type"] == "tutor"
    offer = next(item for item in tutor_client.get("/api/services").json["services"]
                 if item["offer_type"] == "offer" and item["name"] == "Plantão demonstrativo")
    assert tutor_client.post("/api/appointments", json={
        "user_id": 99999, "pet_id": 1, "offer_id": offer["id"], "scheduled_for": "2026-10-10",
    }).status_code == 200
    demands = org_client.get("/api/organization/overview").json["demands"]
    demand = next(item for item in demands if item["service_name"] == "Plantão demonstrativo")
    accepted = org_client.post(f"/api/organization/demands/{demand['id']}/accept", json={
        "organization_id": 99999, "professional_id": professional["id"],
    })
    assert accepted.status_code == 200
    appointments = tutor_client.get("/api/appointments?user_id=99999").json["appointments"]
    appointment = next(item for item in appointments if item["service_name"] == "Plantão demonstrativo")
    assert appointment["status"] == "aceita"
    assert appointment["organization_name"] == "Clínica PetCuida Serviços Veterinários LTDA"
    assert appointment["professional_name"] == professional["name"]
    assert appointment["record_key"].startswith("demand-")


def test_import_professionals_is_validated_and_atomic(app_client):
    app, _ = app_client
    client = app.test_client()
    organization = login(client, "organization")
    bad_payload = json.dumps([{"nome": "Dra. Nova", "cargo": "Veterinária"}, {"cargo": "Sem nome"}]).encode()
    response = client.post("/api/organization/professionals/import", data={
        "organization_id": str(organization["organization_id"]), "file": (BytesIO(bad_payload), "equipe.json"),
    }, content_type="multipart/form-data")
    assert response.status_code == 400
    assert len(client.get("/api/organization/overview").json["professionals"]) == 2
    good_payload = json.dumps({"professionals": [{"Nome": "Dra. Nova", "Especialidade": "Veterinária", "CRMV": "MG 123"}]}).encode()
    response = client.post("/api/organization/professionals/import", data={
        "file": (BytesIO(good_payload), "equipe.json"),
    }, content_type="multipart/form-data")
    assert response.status_code == 200
    assert response.json["created"] == 1


def test_api_requires_session_and_ignores_client_supplied_identity(app_client):
    app, client = app_client
    assert client.get("/api/pets?user_id=1").status_code == 401
    login(client)
    # user_id malicioso ou inválido não troca a identidade da sessão autenticada.
    response = client.get("/api/pets?user_id=99999")
    assert response.status_code == 200
    assert response.json["pets"][0]["name"] == "Rex"
    created = client.post("/api/pets", json={"user_id": 99999, "name": "Só da sessão", "species": "Cão"})
    assert created.status_code == 200
    with connect(app.config["DB_PATH"]) as conn:
        row = conn.execute("SELECT user_id,temporary_session_id FROM pets WHERE name=?", ("Só da sessão",)).fetchone()
        assert row["user_id"] == 1
        assert row["temporary_session_id"]


def test_registration_duplicate_ids_and_invalid_payloads(app_client):
    app, client = app_client
    secret = "SenhaForte123"
    assert client.post("/api/auth/register", json={"username": "fraco", "password": "1234"}).status_code == 400
    registered = client.post("/api/auth/register", json={"username": "novo.tutor", "password": secret})
    assert registered.status_code == 200
    duplicate_client = app.test_client()
    assert duplicate_client.post("/api/auth/register", json={"username": "novo.tutor", "password": secret}).status_code == 400
    assert client.post("/api/auth/register", json={"username": "outro", "password": secret}).status_code == 409
    assert client.post("/api/auth/logout").status_code == 200
    # A conta demonstrativa temporária foi apagada no logout; o nome volta a estar disponível.
    reused = client.post("/api/auth/register", json={"username": "novo.tutor", "password": secret})
    assert reused.status_code == 200
    assert client.post("/api/auth/logout").status_code == 200

    login(client)
    assert client.post("/api/appointments", json={"user_id": 1, "pet_id": 1, "service_id": 1, "scheduled_for": "amanhã"}).status_code == 400
    assert client.get("/api/rota-inexistente").status_code == 404
    # Identificadores de organização no request são ignorados; só a sessão determina o escopo.
    org = app.test_client()
    login(org, "organization")
    assert org.get("/api/organization/overview?organization_id=not-valid!").status_code == 200
    assert org.post("/api/organization/professionals", json={
        "organization_id": 99999, "name": "Profissional da sessão", "role": "Veterinário",
    }).status_code == 200


def test_xlsx_import_and_upload_limit(app_client):
    from openpyxl import Workbook
    app, _ = app_client
    client = app.test_client()
    login(client, "organization")
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["Nome", "Especialidade", "CRMV"])
    sheet.append(["Dra. Planilha", "Veterinária", "MG 987"])
    stream = BytesIO()
    workbook.save(stream)
    response = client.post("/api/organization/professionals/import", data={
        "file": (BytesIO(stream.getvalue()), "equipe.xlsx"),
    }, content_type="multipart/form-data")
    assert response.status_code == 200
    assert response.json["created"] == 1
    oversized = BytesIO(b"x" * (2 * 1024 * 1024 + 1))
    response = client.post("/api/organization/professionals/import", data={
        "file": (oversized, "large.json"),
    }, content_type="multipart/form-data")
    assert response.status_code == 413
    assert response.json["ok"] is False


def test_legacy_database_migrates_before_creating_indexes(tmp_path):
    path = tmp_path / "legacy.db"
    conn = sqlite3.connect(path)
    conn.executescript("""
        CREATE TABLE organizations (id INTEGER PRIMARY KEY, legal_name TEXT NOT NULL, trade_name TEXT NOT NULL, org_type TEXT NOT NULL, document TEXT, location TEXT, created_at TEXT NOT NULL);
        CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE pets (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL, species TEXT NOT NULL, breed TEXT, birth_date TEXT, notes TEXT);
        CREATE TABLE professionals (id INTEGER PRIMARY KEY, organization_id INTEGER NOT NULL, name TEXT NOT NULL, role TEXT, registration TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
        CREATE TABLE services (id INTEGER PRIMARY KEY, name TEXT NOT NULL, provider TEXT NOT NULL, location TEXT NOT NULL, price_cents INTEGER NOT NULL, description TEXT NOT NULL, booked INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE service_offers (id INTEGER PRIMARY KEY, organization_id INTEGER NOT NULL, professional_id INTEGER NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL, location TEXT NOT NULL, price_cents INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'publicado', created_at TEXT NOT NULL);
        CREATE TABLE appointments (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, pet_id INTEGER NOT NULL, service_id INTEGER NOT NULL, scheduled_for TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'agendado');
        CREATE TABLE demand_requests (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, pet_id INTEGER NOT NULL, offer_id INTEGER NOT NULL, scheduled_for TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pendente', accepted_professional_id INTEGER, created_at TEXT NOT NULL);
    """)
    conn.commit()
    conn.close()
    app = create_app({"TESTING": True, "DB_PATH": str(path)})
    client = app.test_client()
    assert login(client)["account_type"] == "tutor"
    with connect(path) as migrated:
        assert "temporary_session_id" in {r["name"] for r in migrated.execute("PRAGMA table_info(users)")}
        assert migrated.execute("SELECT COUNT(*) FROM users WHERE username='clinica.petcuida'").fetchone()[0] == 1


def test_production_requires_distinct_strong_secrets_and_secure_cookie(tmp_path):
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        create_app({"TESTING": True, "ENVIRONMENT": "production", "DB_PATH": str(tmp_path / "bad.db")})
    app = create_app({
        "TESTING": True, "ENVIRONMENT": "production", "DB_PATH": str(tmp_path / "good.db"),
        "SECRET_KEY": "s" * 48, "PRIVACY_HASH_SALT": "h" * 48, "SESSION_COOKIE_SECURE": True,
    })
    assert app.config["SESSION_COOKIE_SECURE"] is True
    with pytest.raises(RuntimeError, match="PRIVACY_HASH_SALT"):
        create_app({
            "TESTING": True, "ENVIRONMENT": "production", "DB_PATH": str(tmp_path / "same.db"),
            "SECRET_KEY": "s" * 48, "PRIVACY_HASH_SALT": "s" * 48, "SESSION_COOKIE_SECURE": True,
        })


def test_unvalidated_remote_backend_fails_closed(tmp_path):
    with pytest.raises(RuntimeError, match="apenas PETCUIDA_BACKEND=sqlite"):
        create_app({"TESTING": True, "BACKEND": "supabase", "DB_PATH": str(tmp_path / "unused.db")})
