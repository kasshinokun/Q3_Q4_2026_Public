from io import BytesIO
from pathlib import Path
from app import create_app
from app.db import connect

PNG_1PX = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"


def make_app(tmp_path, **config):
    values = {"TESTING": True, "DB_PATH": str(tmp_path / "privacy.db"),
              "TEMP_UPLOAD_DIR": str(tmp_path / "uploads"), "SESSION_TTL_MINUTES": 45}
    values.update(config)
    app = create_app(values)
    return app, app.test_client()


def login(client, username="petcuida", password="meu pet"):
    response = client.post("/api/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200
    return response.json["user"]


def test_login_creates_session_minimized_audit_and_secure_cookie(tmp_path):
    app, client = make_app(tmp_path)
    response = client.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"})
    assert response.status_code == 200
    cookie = response.headers.get("Set-Cookie", "").lower()
    assert "httponly" in cookie and "samesite=lax" in cookie
    with connect(app.config["DB_PATH"]) as conn:
        rows = conn.execute("SELECT event_type,session_id,username_hash,metadata_json,ip_hash FROM access_logs WHERE event_type='login_succeeded'").fetchall()
        assert rows and rows[-1]["session_id"] and rows[-1]["username_hash"] and rows[-1]["ip_hash"]
        assert "password" not in rows[-1]["metadata_json"]
        stored = conn.execute("SELECT password FROM users WHERE username='petcuida'").fetchone()[0]
        assert stored.startswith("scrypt:") and stored != "meu pet"


def test_legacy_plaintext_password_is_upgraded_when_used(tmp_path):
    app, client = make_app(tmp_path)
    with connect(app.config["DB_PATH"]) as conn:
        conn.execute("UPDATE users SET password=? WHERE username=?", ("meu pet", "petcuida"))
    assert client.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"}).status_code == 200
    with connect(app.config["DB_PATH"]) as conn:
        assert conn.execute("SELECT password FROM users WHERE username='petcuida'").fetchone()[0].startswith("scrypt:")


def test_logout_purges_only_temporary_session_data_and_preserves_seeds(tmp_path):
    app, client = make_app(tmp_path)
    password = "SenhaForte123"
    registered = client.post("/api/auth/register", json={"username": "teste.temp", "password": password, "display_name": "Teste"})
    assert registered.status_code == 200
    assert client.post("/api/pets", json={"user_id": 1, "name": "Temporário", "species": "Cão"}).status_code == 200
    # Login num dispositivo/sessão nova transfere os dados próprios sem perder a conta.
    assert client.post("/api/auth/login", json={"username": "teste.temp", "password": password}).status_code == 200
    assert any(pet["name"] == "Temporário" for pet in client.get("/api/pets").json["pets"])
    response = client.post("/api/uploads/photo", data={
        "kind": "pet", "file": (BytesIO(PNG_1PX), "pet.png"),
    }, content_type="multipart/form-data")
    assert response.status_code == 200
    out = client.post("/api/auth/logout")
    assert out.status_code == 200
    with connect(app.config["DB_PATH"]) as conn:
        assert conn.execute("SELECT 1 FROM users WHERE username='teste.temp'").fetchone() is None
        assert conn.execute("SELECT 1 FROM pets WHERE name='Temporário'").fetchone() is None
        assert conn.execute("SELECT 1 FROM users WHERE username='petcuida'").fetchone() is not None
        assert conn.execute("SELECT 1 FROM pets WHERE name='Rex'").fetchone() is not None
        assert conn.execute("SELECT COUNT(*) FROM access_logs WHERE event_type='logout'").fetchone()[0] >= 1
        assert conn.execute("SELECT COUNT(*) FROM access_logs WHERE event_type='temporary_data_purged'").fetchone()[0] >= 1
    assert not list(Path(app.config["TEMP_UPLOAD_DIR"]).glob("*"))


def test_expiring_organization_removes_dependent_offer_and_other_session_demand(tmp_path):
    app, org_client = make_app(tmp_path)
    registered = org_client.post("/api/auth/register", json={
        "username": "org.temp", "password": "SenhaForte123", "account_type": "organization",
        "legal_name": "Organização de teste LTDA", "trade_name": "Org teste", "org_type": "Projeto social",
    })
    assert registered.status_code == 200
    overview = org_client.get("/api/organization/overview").json
    professional = org_client.post("/api/organization/professionals", json={
        "name": "Dra. Temporária", "role": "Veterinária",
    })
    assert professional.status_code == 200
    professional_id = professional.json["id"]
    offer = org_client.post("/api/organization/offers", json={
        "professional_id": professional_id, "name": "Oferta temporária", "location": "Centro", "price_cents": 5000,
    })
    assert offer.status_code == 200

    tutor_client = app.test_client()
    login(tutor_client)
    booked = tutor_client.post("/api/appointments", json={
        "pet_id": 1, "offer_id": offer.json["id"], "scheduled_for": "2026-10-10",
    })
    assert booked.status_code == 200
    assert org_client.post("/api/auth/logout").status_code == 200
    with connect(app.config["DB_PATH"]) as conn:
        assert conn.execute("SELECT 1 FROM organizations WHERE trade_name='Org teste'").fetchone() is None
        assert conn.execute("SELECT 1 FROM professionals WHERE name='Dra. Temporária'").fetchone() is None
        assert conn.execute("SELECT 1 FROM service_offers WHERE name='Oferta temporária'").fetchone() is None
        assert conn.execute("SELECT 1 FROM demand_requests WHERE offer_id=?", (offer.json["id"],)).fetchone() is None
        assert conn.execute("SELECT 1 FROM organizations WHERE trade_name='Clínica PetCuida'").fetchone() is not None


def test_photo_upload_requires_auth_and_rejects_mime_spoof(tmp_path):
    app, client = make_app(tmp_path)
    denied = client.post("/api/uploads/photo", data={
        "kind": "pet", "file": (BytesIO(b"not-an-image"), "pet.png"),
    }, content_type="multipart/form-data")
    assert denied.status_code == 401
    login(client)
    response = client.post("/api/uploads/photo", data={
        "kind": "pet", "file": (BytesIO(b"not-an-image"), "pet.png"),
    }, content_type="multipart/form-data")
    assert response.status_code == 400
    assert not list(Path(app.config["TEMP_UPLOAD_DIR"]).rglob("*"))


def test_cleanup_route_requires_configured_secret(tmp_path):
    _, client = make_app(tmp_path)
    assert client.post("/api/auth/cleanup").status_code == 503
    app2, client2 = make_app(tmp_path / "second", CLEANUP_TOKEN="private-maintenance-token")
    assert client2.post("/api/auth/cleanup").status_code == 403
    authorized = client2.post("/api/auth/cleanup", headers={"X-PetCuida-Cleanup-Token": "private-maintenance-token"})
    assert authorized.status_code == 200
    assert authorized.json["expired_sessions"] == 0


def test_cookie_contains_only_random_session_id_and_old_login_is_revoked(tmp_path):
    app, client = make_app(tmp_path)
    response = client.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"})
    token = response.headers["Set-Cookie"].split(";", 1)[0].split("=", 1)[1]
    claims = app.session_interface.get_signing_serializer(app).loads(token)
    assert set(claims).issubset({"session_id", "_permanent"})
    assert "petcuida" not in token and "user_id" not in claims and "organization_id" not in claims

    stale_client = app.test_client()
    stale_client.set_cookie("session", token)
    # Um novo login rotaciona e revoga a sessão anterior no registro server-side.
    assert client.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"}).status_code == 200
    assert stale_client.get("/api/pets").status_code == 401
