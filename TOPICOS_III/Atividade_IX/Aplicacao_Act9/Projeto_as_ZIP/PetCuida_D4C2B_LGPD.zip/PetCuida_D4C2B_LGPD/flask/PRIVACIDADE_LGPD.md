# PetCuida — privacidade e ciclo de vida dos dados (D4C2B)

## Escopo e aviso

Esta é uma **nota técnica do protótipo Flask/SQLite**, não uma política de privacidade pronta nem um parecer jurídico. O controlador do projeto deve determinar e documentar as finalidades, bases legais, categorias de titulares/dados, prazos de retenção, encarregado/canal de contacto, operadores e resposta a incidentes antes de qualquer operação real.

Não usar dados reais de tutores ou animais nesta release alfa. O PDF original recebido foi preservado em `docs/PRIVACIDADE_LGPD_ORIGINAL.pdf` sem alterações.

## Controles implementados

- O cookie assinado contém apenas um ID de sessão aleatório; identidade, tipo de conta e organização ficam no registro SQLite server-side. IDs enviados pelo navegador são ignorados e as rotas revalidam conta, escopo e sessão.
- Cookies com `HttpOnly` e `SameSite=Lax`; `Secure` é ativado por padrão quando `PETCUIDA_ENV=production` e pode ser configurado por `PETCUIDA_COOKIE_SECURE`. A rotação do login revoga o identificador anterior.
- Senhas novas, incluindo seeds de base nova, são guardadas com hash Werkzeug (`scrypt`). Uma senha legada em texto claro só é aceite numa autenticação bem-sucedida e é substituída por hash nesse momento. Não se trata de credenciais de produção.
- Sessão temporária com TTL padrão de 45 minutos. O logout elimina registos temporários e dependências antes das entidades-pai; a limpeza por expiração segue a mesma rotina. Os seeds com `temporary_session_id IS NULL` são preservados.
- Se uma conta temporária válida iniciar sessão novamente, os respetivos registos temporários passam para o novo ID de sessão. Uploads não associados a entidades são apagados na rotação.
- Fotos exigem sessão autenticada, tamanho total da requisição limitado a 2 MiB e correspondência entre MIME declarado e assinatura JPG/PNG/WebP. Os ficheiros ficam fora da árvore pública e são removidos com a sessão.
- A auditoria não regista senha, corpo de pedido, foto, IP ou User-Agent em claro. Mantém IDs pseudónimos, hashes e metadados técnicos; **esses logs também são dados e necessitam de prazo de retenção definido**.
- O endpoint remoto `POST /api/auth/cleanup` só executa com `PETCUIDA_CLEANUP_TOKEN` e header `X-PetCuida-Cleanup-Token`; sem configuração fica desativado (`503`).

## Limites e riscos remanescentes

- A implementação é demonstrativa e usa credenciais seed públicas; não é apropriada para dados reais, mesmo com hash.
- Não há token CSRF explícito nem limitação de tentativas de autenticação. `SameSite=Lax` é defesa parcial, não substituto para avaliação de CSRF, abuso e brute force.
- Assinatura/MIME de imagem não substitui descodificação/validação robusta do ficheiro nem análise antimalware.
- Não existe processo de atendimento de acesso, correção, eliminação ou outros direitos dos titulares; não entregar a base SQLite diretamente.
- A política de retenção dos logs, cópias de segurança e expurgo após incidente/encerramento precisa ser definida e testada.
- Firestore/Supabase não têm paridade funcional ou revisão de segurança; esta release recusa inicializar com esses backends.
- O Flutter é um protótipo separado, com estado local demonstrativo; não sincroniza com esta API. O login Google é simulado. A pesquisa abre um formulário Google externo.

## Configuração recomendada

```bash
export SECRET_KEY="<segredo aleatório longo>"
export PETCUIDA_PRIVACY_HASH_SALT="<segredo distinto>"
export PETCUIDA_ENV=production
export PETCUIDA_COOKIE_SECURE=1
export PETCUIDA_SESSION_TTL_MINUTES=45
export PETCUIDA_TEMP_UPLOAD_DIR=/caminho/privado/uploads
export PETCUIDA_DB_PATH=/caminho/privado/petcuida.db
# Opcional, só se a rota remota de limpeza for necessária:
export PETCUIDA_CLEANUP_TOKEN="<segredo de manutenção>"
```

A aplicação exige em produção `SECRET_KEY` e `PETCUIDA_PRIVACY_HASH_SALT` distintos, com pelo menos 32 caracteres cada, além de `PETCUIDA_COOKIE_SECURE=1`. Use HTTPS e permissões restritas na base, diretório de uploads, segredos e backups.

## Limpeza local

Para uma rotina local com o mesmo ambiente/`PETCUIDA_DB_PATH` do site:

```bash
cd flask
python -c "from app import create_app; from app.privacy import purge_expired_sessions; app=create_app(); ctx=app.app_context(); ctx.push(); print(purge_expired_sessions(app.config['DB_PATH']))"
```

Uma tarefa remota autenticada pode usar `POST /api/auth/cleanup`, fornecendo o header acima. A limpeza oportunística também corre no tráfego da API SQLite, mas não substitui uma política de retenção operacional.
