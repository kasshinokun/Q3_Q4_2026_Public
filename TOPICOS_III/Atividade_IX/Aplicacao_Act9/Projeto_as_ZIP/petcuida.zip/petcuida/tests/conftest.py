"""Fixtures: a mesma suíte da API roda em SQLite e nos dublês de Firestore/Supabase."""
from __future__ import annotations

import json
import re

import pytest

from app import create_app
from app.data_backends.firestore_adapter import FirestoreDocumentStore
from app.data_backends.supabase_adapter import SupabaseDocumentStore


# ------------------------------------------------------------- dublê Firestore
class _Snap:
    def __init__(self, doc_id, data):
        self.id, self._d, self.exists = doc_id, data, data is not None

    def to_dict(self):
        return dict(self._d) if self._d is not None else None


class _DocRef:
    def __init__(self, db, coll, doc_id):
        self.db, self.coll, self.doc_id = db, coll, doc_id

    def get(self):
        return _Snap(self.doc_id, self.db.data.get(self.coll, {}).get(self.doc_id))

    def set(self, data):
        self.db.data.setdefault(self.coll, {})[self.doc_id] = json.loads(json.dumps(data))

    def delete(self):
        self.db.data.get(self.coll, {}).pop(self.doc_id, None)


class _Query:
    def __init__(self, db, coll, filters=()):
        self.db, self.coll, self.filters = db, coll, list(filters)

    def where(self, field, op, value):
        assert op == "=="
        return _Query(self.db, self.coll, [*self.filters, (field, value)])

    def document(self, doc_id):
        return _DocRef(self.db, self.coll, doc_id)

    def stream(self):
        for doc_id, d in list(self.db.data.get(self.coll, {}).items()):
            if all(d.get(f) == v for f, v in self.filters):
                yield _Snap(doc_id, d)


class FakeFirestore:
    def __init__(self):
        self.data: dict = {}

    def collection(self, name):
        return _Query(self, name)


# -------------------------------------------------------------- dublê Supabase
class _Resp:
    def __init__(self, status=200, payload=None):
        self.status_code, self._p, self.text = status, payload, json.dumps(payload or "")

    def json(self):
        return self._p


class FakePostgREST:
    """Implementa o subconjunto de PostgREST usado pelo adaptador."""

    def __init__(self):
        self.tables: dict[str, dict] = {}

    def request(self, method, url, params=None, json=None, headers=None, timeout=None):
        assert headers and headers.get("apikey") and headers["Authorization"].startswith("Bearer ")
        table = self.tables.setdefault(url.rsplit("/", 1)[-1], {})
        params = params or {}
        if method == "POST":
            table[json["id"]] = dict(json)
            return _Resp(201)
        rows = [r for r in table.values() if self._match(r, params)]
        if method == "DELETE":
            for r in rows:
                table.pop(r["id"])
            return _Resp(204)
        if "limit" in params:
            rows = rows[: int(params["limit"])]
        return _Resp(200, [dict(r) for r in rows])

    @staticmethod
    def _match(row, params):
        for key, val in params.items():
            if key in ("select", "limit", "on_conflict"):
                continue
            op, _, expected = val.partition(".")
            assert op == "eq"
            m = re.match(r"data->>(\w+)", key)
            actual = str(row["data"].get(m.group(1))) if m else row.get(key)
            if actual != expected and str(actual).lower() != expected.lower():
                return False
        return True


def make_store(kind, tmp_path):
    if kind == "sqlite":
        from app.data_backends.sqlite_adapter import SQLiteDocumentStore
        return SQLiteDocumentStore(str(tmp_path / "t.db"))
    if kind == "firestore":
        return FirestoreDocumentStore(client=FakeFirestore())
    return SupabaseDocumentStore("https://x.supabase.co", "service-key", session=FakePostgREST())


@pytest.fixture(params=["sqlite", "firestore", "supabase"])
def store(request, tmp_path):
    return make_store(request.param, tmp_path)


@pytest.fixture()
def client(store):
    app = create_app({"TESTING": True}, store=store)
    return app.test_client()


@pytest.fixture()
def demo(client):
    r = client.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"})
    assert r.status_code == 200
    return client
