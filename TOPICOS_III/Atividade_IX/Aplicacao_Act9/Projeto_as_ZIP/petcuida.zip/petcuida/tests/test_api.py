from datetime import date, timedelta

TOMORROW = (date.today() + timedelta(days=1)).isoformat()


def test_manifest_and_index(client):
    assert client.get("/manus-routes.json").json["routes"][0]["path"] == "/"
    html = client.get("/").get_data(as_text=True)
    assert 'id="app"' in html and "PetCuida" in html
    assert client.get("/api/nao-existe").status_code == 404


def test_session_endpoint_is_silent(client):
    r = client.get("/api/session")
    assert r.status_code == 200 and r.json["user"] is None
    client.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"})
    assert client.get("/api/session").json["user"]["username"] == "petcuida"


def test_survey_link_on_login_page(client, monkeypatch):
    html = client.get("/").get_data(as_text=True)
    assert 'name="petcuida-survey" content="https://forms.gle/N3C947f2NfmwQeoRA"' in html


def test_survey_link_rejects_non_https(client):
    client.application.config["SURVEY_URL"] = "javascript:alert(1)"
    assert 'content=""' in client.get("/").get_data(as_text=True)


def test_auth_required_and_login(client):
    assert client.get("/api/me").status_code == 401
    bad = client.post("/api/auth/login", json={"username": "petcuida", "password": "x"})
    assert bad.status_code == 401 and "incorretos" in bad.json["error"]
    assert client.post("/api/auth/login", json={}).status_code == 400
    ok = client.post("/api/auth/login", json={"username": "PetCuida", "password": "meu pet"})
    assert ok.status_code == 200 and ok.json["user"]["onboarded"] is True
    assert "password_hash" not in ok.json["user"]
    assert client.get("/api/me").status_code == 200
    client.post("/api/auth/logout")
    assert client.get("/api/me").status_code == 401


def test_seed_matches_flutter_alpha(demo):
    s = demo.get("/api/me").json
    assert s["user"]["saldo"] == 3.5
    assert s["pets"][0]["nome"] == "Rex" and s["pets"][0]["tipo"] == "cao"
    assert [x["nome"] for x in s["servicos"]] == [
        "Consulta veterinária de rotina", "Vacinação V10", "Castração", "Banho e tosa"]
    assert len(s["pedidos"]) == 3 and len(s["lembretes"]) == 2 and len(s["registros"]) == 3


def test_register_validation_and_onboarding(client):
    def reg(u, p, c):
        return client.post("/api/auth/register", json={"username": u, "password": p, "confirm": c})
    assert reg("", "1234", "1234").status_code == 400
    assert reg("ana", "1234", "9999").json["error"] == "As senhas não conferem."
    assert reg("ana", "123", "123").status_code == 400
    assert reg("ana", "1234", "1234").status_code == 201
    assert reg("ANA", "1234", "1234").status_code == 409
    me = client.post("/api/auth/login", json={"username": "ana", "password": "1234"}).json
    assert me["user"]["onboarded"] is False and me["pets"] == []
    bad = client.post("/api/me/onboarding", json={"nome": "Luna", "tipo": "gato", "nascimento": "2999-01-01"})
    assert bad.status_code == 400
    ok = client.post("/api/me/onboarding", json={"nome": "Luna", "tipo": "gato", "nascimento": "2023-05-01"})
    assert ok.status_code == 201 and ok.json["user"]["onboarded"] and ok.json["pets"][0]["nome"] == "Luna"


def test_pet_crud_and_isolation(demo, client):
    pet = demo.post("/api/pets", json={"nome": "Mia", "tipo": "gato", "nascimento": "2022-01-02"}).json["pet"]
    assert demo.put(f"/api/pets/{pet['id']}", json={"nome": "Mia 2", "raca": "Siamês"}).json["pet"]["nome"] == "Mia 2"
    assert demo.put(f"/api/pets/{pet['id']}", json={"nome": " "}).status_code == 400
    assert demo.post("/api/pets", json={"nome": "X", "nascimento": "2020-01-01", "foto": "javascript:1"}).status_code == 400
    # outro usuário não enxerga nem altera
    client.post("/api/auth/logout")
    client.post("/api/auth/register", json={"username": "bia", "password": "1234", "confirm": "1234"})
    client.post("/api/auth/login", json={"username": "bia", "password": "1234"})
    assert client.put(f"/api/pets/{pet['id']}", json={"nome": "Hack"}).status_code == 404
    assert client.get("/api/me").json["pets"] == []
    client.post("/api/auth/logout")
    demo.post("/api/auth/login", json={"username": "petcuida", "password": "meu pet"})
    assert demo.delete(f"/api/pets/{pet['id']}").status_code == 200
    only = demo.get("/api/me").json["pets"][0]["id"]
    assert demo.delete(f"/api/pets/{only}").status_code == 409


def test_reminders_and_records(demo):
    r = demo.post("/api/lembretes", json={"titulo": "Vermífugo", "data": "2026-12-01"})
    assert r.status_code == 201
    assert demo.post("/api/lembretes", json={"titulo": "", "data": "2026-12-01"}).status_code == 400
    assert demo.post("/api/lembretes", json={"titulo": "x", "data": "ontem"}).status_code == 400
    assert any(l["titulo"] == "Vermífugo" for l in demo.get("/api/me").json["lembretes"])
    assert demo.delete(f"/api/lembretes/{r.json['lembrete']['id']}").status_code == 200
    rec = demo.post("/api/registros", json={"titulo": "Cirurgia", "detalhes": "15/09 - Clínica X"})
    assert rec.status_code == 201 and len(demo.get("/api/me").json["registros"]) == 4
    assert demo.post("/api/registros", json={"titulo": "Só título"}).status_code == 400


def test_booking_with_credits_and_cancel(demo):
    s = demo.post("/api/agendamentos", json={"servico_id": "s4", "dia": TOMORROW, "horario": "09:00",
                                             "usar_creditos": True})
    assert s.status_code == 201 and s.json["agendamento"]["creditos"] == 1.0
    assert s.json["agendamento"]["dinheiro"] == 34.0
    snap = demo.get("/api/me").json
    assert snap["user"]["saldo"] == 2.5
    assert next(x for x in snap["servicos"] if x["id"] == "s4")["agendado"] is True
    assert snap["atividades"][0]["variacao"] == -1.0
    dup = demo.post("/api/agendamentos", json={"servico_id": "s4", "dia": TOMORROW, "horario": "10:30"})
    assert dup.status_code == 409
    assert demo.post("/api/agendamentos", json={"servico_id": "zz", "dia": TOMORROW, "horario": "09:00"}).status_code == 404
    assert demo.post("/api/agendamentos", json={"servico_id": "s1", "dia": "2020-01-01", "horario": "09:00"}).status_code == 400
    assert demo.post("/api/agendamentos", json={"servico_id": "s1", "dia": TOMORROW, "horario": "9h"}).status_code == 400
    bid = demo.get("/api/me").json["agendamentos"][0]["id"]
    assert demo.delete(f"/api/agendamentos/{bid}").status_code == 200
    snap = demo.get("/api/me").json
    assert snap["user"]["saldo"] == 3.5 and snap["agendamentos"][0]["status"] == "cancelado"
    assert demo.delete(f"/api/agendamentos/{bid}").status_code == 409


def test_booking_cash_only_keeps_balance(demo):
    r = demo.post("/api/agendamentos", json={"servico_id": "s1", "dia": TOMORROW, "horario": "14:00"})
    assert r.json["agendamento"]["creditos"] == 0 and r.json["agendamento"]["dinheiro"] == 60
    assert demo.get("/api/me").json["user"]["saldo"] == 3.5


def test_requests_board(demo):
    assert demo.post("/api/pedidos/p1/candidatura").status_code == 201
    assert demo.post("/api/pedidos/p1/candidatura").status_code == 409
    assert demo.post("/api/pedidos/nope/candidatura").status_code == 404
    new = demo.post("/api/pedidos", json={"titulo": "Dar remédio", "descricao": "2x ao dia", "recompensa": 2})
    assert new.status_code == 201
    assert demo.post("/api/pedidos", json={"titulo": "x", "descricao": "y", "recompensa": 99}).status_code == 400
    snap = demo.get("/api/me").json
    assert snap["pedidos"][0]["meu"] is True
    assert next(p for p in snap["pedidos"] if p["id"] == "p1")["candidatado"] is True
    assert demo.post(f"/api/pedidos/{new.json['pedido']['id']}/candidatura").status_code == 409


def test_profile_settings_password(demo):
    r = demo.patch("/api/me", json={"nome": "Giovanna", "settings": {"emails": True, "push": False}})
    assert r.json["user"]["nome"] == "Giovanna" and r.json["user"]["settings"] == {
        "push": False, "vacinas": True, "emails": True}
    assert demo.patch("/api/me", json={"email": "sem-arroba"}).status_code == 400
    assert demo.post("/api/me/password", json={"current": "errada", "new": "abcd"}).status_code == 403
    assert demo.post("/api/me/password", json={"current": "meu pet", "new": "abc"}).status_code == 400
    assert demo.post("/api/me/password", json={"current": "meu pet", "new": "novasenha"}).status_code == 200
    demo.post("/api/auth/logout")
    assert demo.post("/api/auth/login", json={"username": "petcuida", "password": "novasenha"}).status_code == 200


def test_triage(demo):
    ev = lambda **k: demo.post("/api/triage/evaluate", json=k).json["result"]["level"]
    assert ev(urgent="sim", onset="dias") == "urgent"
    assert ev(urgent="nao", onset="horas") == "attention"
    assert ev(urgent="nao", onset="dias") == "monitor"
    assert demo.post("/api/triage/chat", json={"message": "Ele teve CONVULSÃO agora"}).json["urgent"] is True
    assert demo.post("/api/triage/chat", json={"message": "Está coçando as orelhas"}).json["urgent"] is False
    assert demo.post("/api/triage/chat", json={"message": " "}).status_code == 400


def test_reset_demo_and_health(demo):
    demo.post("/api/pedidos/p1/candidatura")
    demo.post("/api/agendamentos", json={"servico_id": "s2", "dia": TOMORROW, "horario": "09:00", "usar_creditos": True})
    snap = demo.post("/api/demo/reset").json
    assert snap["user"]["saldo"] == 3.5 and snap["agendamentos"] == [] and snap["user"]["onboarded"]
    assert snap["pets"][0]["nome"] == "Rex" and len(snap["lembretes"]) == 2
    assert not any(p["candidatado"] for p in snap["pedidos"])
    h = demo.get("/api/health").json
    assert h["ok"] and h["healthy"]
