"""Contrato DocumentStore: comportamento idêntico em todos os backends."""
import pytest

from app.data_backends import build_store
from app.data_backends.base import BackendNotConfiguredError


def test_roundtrip_and_filters(store):
    store.set("pets", "a", {"user_id": "u1", "nome": "Rex", "ativo": True})
    store.set("pets", "b", {"user_id": "u2", "nome": "Mia", "ativo": False})
    assert store.get("pets", "a")["nome"] == "Rex"
    assert store.get("pets", "zzz") is None
    assert [d["id"] for d in store.find("pets", user_id="u1")] == ["a"]
    assert len(store.find("pets")) == 2
    assert [d["id"] for d in store.find("pets", user_id="u2", nome="Mia")] == ["b"]
    store.set("pets", "a", {"user_id": "u1", "nome": "Rex II"})  # upsert substitui
    assert store.get("pets", "a")["nome"] == "Rex II"
    assert store.delete_where("pets", user_id="u1") == 1
    assert store.get("pets", "a") is None
    assert store.healthcheck()


def test_remote_backends_fail_clearly_without_config(monkeypatch):
    for var in ("SUPABASE_URL", "SUPABASE_SERVICE_KEY", "SUPABASE_ANON_KEY"):
        monkeypatch.delenv(var, raising=False)
    with pytest.raises(BackendNotConfiguredError):
        build_store("supabase", db_path=":memory:")
    with pytest.raises(BackendNotConfiguredError):
        build_store("nope", db_path=":memory:")
