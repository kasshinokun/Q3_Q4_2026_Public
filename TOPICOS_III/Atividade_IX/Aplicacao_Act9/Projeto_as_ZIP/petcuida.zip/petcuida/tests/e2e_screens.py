# Percorre todas as telas em desktop e mobile, gera screenshots em /tmp/shots e acusa erros de console/overflow.
# Requer playwright e servidor em http://127.0.0.1:5055 (mkdir -p /tmp/shots).
import sys, json
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:5055'
errors=[]
def run(p, name, vp, mobile=False):
    b=p.chromium.launch()
    ctx=b.new_context(viewport=vp, device_scale_factor=1, is_mobile=mobile, has_touch=mobile)
    page=ctx.new_page()
    page.on('console', lambda m: errors.append((name,'console',m.text)) if m.type in('error','warning') else None)
    page.on('pageerror', lambda e: errors.append((name,'pageerror',str(e))))
    page.on('requestfailed', lambda r: errors.append((name,'reqfail',r.url)))
    page.goto(BASE); page.wait_for_selector('.auth-card', timeout=8000); page.wait_for_selector('.splash', state='detached', timeout=8000)
    page.screenshot(path=f'/tmp/shots/{name}-login.png')
    page.click('text=Entrar agora'); page.wait_for_selector('.hero-card', timeout=8000)
    page.wait_for_timeout(500)
    page.screenshot(path=f'/tmp/shots/{name}-home.png', full_page=True)
    for path in ['pet','pet/vacinas','pet/prontuario','pet/qrcode','pet/editar','triagem','triagem/chat','rede','rede/clinicas','rede/mapa','rede/mural','rede/agendar/s4','perfil','perfil/saldo','perfil/agendamentos','perfil/configuracoes','perfil/suporte','sobre']:
        page.goto(f'{BASE}/#/{path}'); page.wait_for_timeout(350)
        assert page.locator('.page').count()==1, f'{name} {path} sem .page'
        # sem overflow horizontal
        ov=page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')
        if ov>0: errors.append((name,'overflow',f'{path} {ov}px'))
        page.screenshot(path=f'/tmp/shots/{name}-{path.replace("/","_")}.png', full_page=True)
    b.close()
with sync_playwright() as p:
    run(p,'desk',{'width':1280,'height':800})
    run(p,'mob',{'width':390,'height':844},True)
print(json.dumps(errors,indent=1,ensure_ascii=False)[:3000])
