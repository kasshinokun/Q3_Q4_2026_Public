# Teste visual/funcional opcional (requer: pip install playwright && playwright install chromium).
# Suba o servidor antes: PORT=5055 python run.py   |   Rode: python tests/e2e_flow.py
from playwright.sync_api import sync_playwright, expect
B='http://127.0.0.1:5055'
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_context(viewport={'width':1280,'height':800}).new_page()
    pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
    pg.goto(B); pg.wait_for_selector('.splash',state='detached')
    # link da pesquisa
    a=pg.locator('a.survey-link'); assert a.get_attribute('href')=='https://forms.gle/N3C947f2NfmwQeoRA'
    assert a.get_attribute('target')=='_blank' and 'noopener' in a.get_attribute('rel')
    # login inválido
    pg.fill('#lg-user','petcuida'); pg.fill('#lg-pass','errada'); pg.click('button:has-text("Entrar") >> nth=0')
    expect(pg.locator('.msg.error')).to_contain_text('incorretos')
    # cadastro + onboarding
    pg.click('text=Criar conta'); pg.fill('#cd-user','visitante1'); pg.fill('#cd-pass','1234'); pg.fill('#cd-conf','1234'); pg.click('button:has-text("Criar conta")')
    pg.wait_for_selector('#pf-nome'); pg.fill('#pf-nome','Luna'); pg.click('button[role=radio]:has-text("Gato")'); pg.fill('#pf-nasc','2023-03-10')
    pg.click('button:has-text("Concluir cadastro")'); pg.wait_for_selector('.hero-card')
    expect(pg.locator('.hero-card')).to_contain_text('Luna')
    # reload mantém sessão
    pg.reload(); pg.wait_for_selector('.hero-card'); 
    # agendar com créditos
    pg.goto(B+'/#/rede/clinicas'); pg.click('.list-card:has-text("Banho e tosa") button:has-text("Agendar")')
    pg.click('button[role=radio]:has-text("10:30")'); pg.click('text=Continuar para pagamento')
    expect(pg.locator('.sum-row.total')).to_contain_text('34'); pg.click('button:has-text("Confirmar agendamento")')
    pg.wait_for_selector('text=Meus agendamentos'); expect(pg.locator('.list-card')).to_contain_text('Banho e tosa')
    pg.goto(B+'/#/perfil/saldo'); expect(pg.locator('.balance-card')).to_contain_text('2,5')
    pg.goto(B+'/#/perfil/agendamentos'); pg.click('button:has-text("Cancelar")'); pg.wait_for_selector('text=Nenhum agendamento ativo')
    pg.goto(B+'/#/perfil/saldo'); expect(pg.locator('.balance-card')).to_contain_text('3,5')
    # triagem
    pg.goto(B+'/#/triagem'); pg.click('.choice >> nth=0'); pg.click('.choice >> nth=0'); expect(pg.locator('.notice.danger')).to_contain_text('Procure atendimento agora')
    pg.goto(B+'/#/triagem/chat'); pg.fill('#chat-in','ele teve convulsão'); pg.press('#chat-in','Enter'); pg.wait_for_selector('.bubble.urgent')
    # lembrete
    pg.goto(B+'/#/pet/vacinas'); pg.click('button:has-text("Novo lembrete")'); pg.fill('#lm-t','Vermífugo'); pg.fill('#lm-d','2026-12-20'); pg.click('.modal button:has-text("Adicionar")')
    expect(pg.locator('.list-card').filter(has_text='Vermífugo')).to_have_count(1)
    # mural
    pg.goto(B+'/#/rede/mural'); pg.click('.list-card:has-text("Passear com 2 cães") button'); pg.wait_for_selector('.list-card:has-text("Passear") .tag:has-text("Candidatura enviada")')
    # QR
    pg.goto(B+'/#/pet/qrcode'); assert pg.locator('.qr-box svg').count()==1
    # config + reset
    pg.goto(B+'/#/perfil/configuracoes'); pg.click('button:has-text("Restaurar dados")'); pg.click('.modal button:has-text("Restaurar")'); pg.wait_for_selector('#pf-nome')
    # logout
    pg.goto(B+'/#/home'); 
    print('URL final:',pg.url)
    # guard: sem login volta ao login
    ctx2=b.new_context(); p2=ctx2.new_page(); p2.goto(B+'/#/pet'); p2.wait_for_selector('.auth-card'); print('guard ->',p2.url)
    b.close()
print('ERROS:',errs)
