# Changelog

## [1.1.0-alpha] — 2026-10-08

### Identidade visual
- Front reconstruído com os tokens do app Flutter (navy `#4F6997`, creme, rosa, amarelo, lavanda), marca "paw" amarela, cartões coloridos, tipografia e raios equivalentes. Removida a paleta anterior (verde/coral) que não existia no Flutter.
- `--muted` escurecido de `#718096` para `#5E6B80` para atingir contraste AA em textos pequenos.

### UI/UX web
- Layout responsivo: barra superior + navegação em pílulas no desktop, barra inferior no mobile; login em duas colunas (desktop) / cabeçalho curvo (mobile).
- Telas completas equivalentes ao Flutter: splash, login, cadastro, onboarding, início, área do pet (editar/adicionar/vacinas/prontuário/QR), triagem + chat, rede solidária (busca, clínicas, mapa, mural, agendar, checkout híbrido), perfil (saldo, agendamentos, configurações, suporte) e sobre.
- Acessibilidade: foco visível, rótulos ligados a campos, `aria-live` em toasts/resultados, diálogos com Esc e retorno de foco, `prefers-reduced-motion`.
- Funciona 100 % offline (Vue, QR Code e fontes locais — sem CDN).
- Demo: botão "Entrar agora", **Restaurar dados de demonstração**, roteiro em `docs/APRESENTACAO.md`.
- Link da pesquisa de mercado (Google Forms) no login, em Sobre e em Suporte; configurável por `PETCUIDA_SURVEY_URL`.

### Backend
- Sessão por cookie assinado (HttpOnly, SameSite=Lax) com **autorização por recurso** (cada tutor só acessa os próprios dados) — substitui o `user_id` enviado pelo cliente.
- Senhas com hash (werkzeug); validações no servidor; créditos debitados/estornados; cancelamento de agendamento.
- Camada de dados desacoplada (`DocumentStore`): **SQLite** (padrão), **Firestore** e **Supabase** com contrato único, espelhando o `RemoteDataSource` do Flutter.
- Adaptadores Firestore/Supabase reescritos (antes dormentes e incompletos), com `schema.sql`, `firestore.rules` e testes por dublê — a mesma suíte de 40+ testes roda nos 3 backends.
- `/api/health` e `/api/session`; cabeçalhos de segurança; `SECRET_KEY` obrigatório em produção.
- Corrigido: erros de login não eram exibidos (`$emit` não retorna Promise), componentes com template no DOM, dependência de CDN.
