-- PetCuida · esquema Supabase (Postgres). Rode no SQL Editor do projeto.
-- O servidor Flask usa a chave service_role (ignora RLS); as políticas abaixo
-- bloqueiam qualquer acesso direto via chave anon/clientes.

do $$
declare c text;
begin
  foreach c in array array['users','pets','servicos','pedidos','candidaturas',
                           'atividades','agendamentos','lembretes','registros']
  loop
    execute format('create table if not exists public.pc_%I (
        id         text primary key,
        user_id    text not null default '''',
        data       jsonb not null,
        updated_at timestamptz not null default now()
      )', c);
    execute format('create index if not exists pc_%1$s_user_idx on public.pc_%1$I (user_id)', c);
    execute format('alter table public.pc_%I enable row level security', c);
    -- Sem políticas permissivas: somente service_role acessa.
  end loop;
end $$;

-- Índice para login por usuário
create unique index if not exists pc_users_username_uidx
  on public.pc_users ((data->>'username'));
