from __future__ import annotations

import os
from datetime import timedelta

from flask import Flask, jsonify, render_template, request

from .data_backends import build_store
from .data_backends.base import BackendNotConfiguredError
from .errors import ApiError
from .repository import Repository
from .routes import api

APP_VERSION = "1.1.0-alpha"
# Pesquisa de mercado (Google Forms). Troque via PETCUIDA_SURVEY_URL; vazio desativa o link.
DEFAULT_SURVEY_URL = "https://forms.gle/N3C947f2NfmwQeoRA"


def _survey(app) -> str:
    """Só aceita links https (evita esquemas perigosos vindos de configuração)."""
    url = (app.config.get("SURVEY_URL") or "").strip()
    return url if url.startswith("https://") else ""


def create_app(test_config: dict | None = None, store=None) -> Flask:
    """Application factory.

    ``store`` permite injetar um ``DocumentStore`` pronto (usado nos testes com
    dublês de Firestore/Supabase).
    """
    app = Flask(__name__, template_folder="templates", static_folder="static")
    base_dir = os.path.abspath(os.path.join(app.root_path, os.pardir))
    app.config.from_mapping(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-me"),
        DB_PATH=os.getenv("PETCUIDA_DB_PATH", os.path.join(app.root_path, "storage", "petcuida.db")),
        BACKEND=os.getenv("PETCUIDA_BACKEND", "sqlite"),
        APP_VERSION=APP_VERSION,
        SURVEY_URL=os.getenv("PETCUIDA_SURVEY_URL", DEFAULT_SURVEY_URL),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("SESSION_COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=12),
        MAX_CONTENT_LENGTH=1024 * 1024,  # fotos já chegam redimensionadas
        JSON_AS_ASCII=False,
    )
    if test_config:
        app.config.update(test_config)
    if app.config["SECRET_KEY"] == "dev-only-change-me" and not app.debug and not app.testing \
            and os.getenv("PETCUIDA_ENV") == "production":
        raise RuntimeError("Defina SECRET_KEY em produção.")

    if store is None:
        store = build_store(app.config["BACKEND"], db_path=app.config["DB_PATH"])
    repo = Repository(store)
    repo.ensure_catalog()
    repo.ensure_demo_user()
    app.extensions["petcuida_store"] = store
    app.extensions["petcuida_repo"] = repo

    app.register_blueprint(api, url_prefix="/api")

    @app.get("/")
    def index():
        return render_template("index.html", version=APP_VERSION, backend=store.name, survey_url=_survey(app))

    @app.get("/manus-routes.json")
    def routes_manifest():
        return {"routes": [{"path": "/", "title": "PetCuida"}]}

    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(ApiError)
    def api_error(err):
        return jsonify({"ok": False, "error": err.message}), err.status

    @app.errorhandler(404)
    def not_found(_):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": "Rota não encontrada."}), 404
        return render_template("index.html", version=APP_VERSION, backend=store.name, survey_url=_survey(app)), 200

    @app.errorhandler(413)
    def too_large(_):
        return jsonify({"ok": False, "error": "Arquivo muito grande."}), 413

    @app.errorhandler(Exception)
    def unexpected(err):
        from werkzeug.exceptions import HTTPException
        if isinstance(err, HTTPException):
            return err
        app.logger.exception("Erro inesperado")
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": "Erro interno. Tente novamente."}), 500
        raise err

    return app


__all__ = ["create_app", "BackendNotConfiguredError"]
