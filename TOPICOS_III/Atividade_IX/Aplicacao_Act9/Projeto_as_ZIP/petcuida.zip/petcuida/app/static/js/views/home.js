import { computed } from 'vue';
import { all } from '../components/ui.js';
import { state, pet, nextReminder, firstName, activeBookings, petReminders } from '../store.js';
import { go } from '../router.js';
import { ageLabel, tipoLabel, relative, fmtDate, credits } from '../utils.js';

export const STATUS = {
  concluido: { label: 'Concluído', tone: 'good' },
  agendado: { label: 'Agendado', tone: '' },
  andamento: { label: 'Em andamento', tone: 'warn' },
};

export const Home = {
  components: all,
  setup() {
    const recent = computed(() => state.atividades.slice(0, 4));
    return { state, pet, nextReminder, firstName, activeBookings, petReminders, recent, go, ageLabel, tipoLabel, relative, fmtDate, credits, STATUS };
  },
  template: `
  <div class="page">
    <header class="page-head" style="margin-bottom:24px">
      <div><div class="eyebrow">Painel do tutor</div><h1>Olá, {{ firstName }} 👋</h1></div>
    </header>
    <div class="split">
      <div>
        <section class="hero-card" aria-label="Resumo">
          <Icon class="paw-bg" name="paw" :size="190" fill />
          <h2><template v-if="pet">O cuidado de {{ pet.nome }} está em dia?</template><template v-else>Cadastre seu primeiro pet</template></h2>
          <p>Veja lembretes, prontuário e encontre atendimento acessível perto de você.</p>
          <div class="actions">
            <button class="btn btn-primary" type="button" @click="go(pet ? '/pet' : '/pet/novo')"><Icon name="paw" :size="18" /> {{ pet ? 'Ver área do pet' : 'Cadastrar pet' }}</button>
            <button class="btn btn-outline" type="button" @click="go('/rede/clinicas')">Agendar na rede</button>
            <span class="pill glass"><Icon name="diamond" :size="16" /> {{ credits(state.user.saldo) }} créditos</span>
          </div>
        </section>

        <div class="section-head"><h2>O que você precisa hoje?</h2></div>
        <div class="grid-3">
          <FeatureTile icon="paw" title="Área do Pet" subtitle="Prontuário e vacinas" tone="pink" @click="go('/pet')" />
          <FeatureTile icon="sparkle" title="Triagem" subtitle="Orientação rápida" tone="yellow" @click="go('/triagem')" />
          <FeatureTile icon="handheart" title="Rede Solidária" subtitle="Clínicas e ajuda" tone="lavender" @click="go('/rede')" />
        </div>

        <div class="section-head"><h2>Atividade recente</h2><button class="btn btn-ghost sm" @click="go('/perfil/saldo')">Ver extrato</button></div>
        <div class="stack">
          <ListCard v-for="a in recent" :key="a.id" icon="calendarcheck" tone="navy" :title="a.nome" :subtitle="a.data">
            <template #end><Tag :tone="STATUS[a.status].tone">{{ STATUS[a.status].label }}</Tag></template>
          </ListCard>
          <EmptyState v-if="!recent.length" icon="list" title="Nada por aqui ainda" text="Seus agendamentos e ajudas aparecem neste painel." />
        </div>
      </div>

      <aside class="stack" style="gap:16px" aria-label="Resumo do pet">
        <div class="stats">
          <StatTile :value="credits(state.user.saldo)" label="Créditos" />
          <StatTile :value="petReminders.length" label="Lembretes" />
          <StatTile :value="activeBookings.length" label="Agendados" />
        </div>
        <div v-if="pet" class="card">
          <div class="eyebrow" style="margin-bottom:12px">Pet em destaque</div>
          <div class="row">
            <PetAvatar :pet="pet" :size="64" />
            <div class="grow"><div class="card-title" style="font-size:18px">{{ pet.nome }}</div>
              <div class="muted small">{{ tipoLabel(pet.tipo) }}<template v-if="pet.raca"> · {{ pet.raca }}</template> · {{ ageLabel(pet.nascimento) }}</div></div>
          </div>
          <hr class="divider">
          <div class="row"><button class="btn btn-soft sm grow" @click="go('/pet/prontuario')"><Icon name="folder" :size="16" /> Prontuário</button>
            <button class="btn btn-soft sm grow" @click="go('/pet/qrcode')"><Icon name="qr" :size="16" /> QR Code</button></div>
        </div>
        <Notice v-if="nextReminder" tone="yellow" icon="bell">
          <b>Próximo cuidado</b>{{ nextReminder.titulo }} — {{ relative(nextReminder.data) }} ({{ fmtDate(nextReminder.data) }})
        </Notice>
        <Notice tone="navy" icon="shield"><b>Cuidado responsável</b>A triagem é orientativa e não substitui a avaliação de um médico-veterinário.</Notice>
      </aside>
    </div>
  </div>`,
};
