import { ref, computed, onMounted, onBeforeUnmount, nextTick } from 'vue';
import { ICONS } from '../icons.js';
import { back } from '../router.js';
import { tipoEmoji, initials } from '../utils.js';

export const Icon = {
  props: { name: String, size: { type: Number, default: 20 }, fill: Boolean },
  setup(p) {
    const html = computed(() => ICONS[p.name] || '');
    return { html };
  },
  template: `<svg class="icon" :width="size" :height="size" viewBox="0 0 24 24" aria-hidden="true"
    :fill="fill ? 'currentColor' : 'none'" :stroke="fill ? 'none' : 'currentColor'" stroke-width="2"
    stroke-linecap="round" stroke-linejoin="round" v-html="html"></svg>`,
};

export const BrandMark = {
  components: { Icon },
  props: { size: { type: Number, default: 40 } },
  template: `<span class="brandmark" :style="{width:size+'px',height:size+'px',borderRadius:size*0.31+'px'}"><Icon name="paw" :size="size*0.58" fill /></span>`,
};

export const PetAvatar = {
  props: { pet: Object, size: { type: Number, default: 56 }, tone: { type: String, default: 'pink' } },
  setup: () => ({ tipoEmoji }),
  template: `<span class="avatar square" :class="'bg-'+tone" :style="{width:size+'px',height:size+'px',fontSize:size*0.5+'px',borderRadius:size*0.28+'px'}">
    <img v-if="pet && pet.foto" :src="pet.foto" :alt="'Foto de '+pet.nome"><template v-else>{{ tipoEmoji(pet && pet.tipo) }}</template></span>`,
};

export const UserAvatar = {
  props: { user: Object, size: { type: Number, default: 40 } },
  setup: () => ({ initials }),
  template: `<span class="avatar" :style="{width:size+'px',height:size+'px',fontSize:size*0.38+'px'}">
    <img v-if="user && user.foto" :src="user.foto" alt=""><template v-else>{{ initials(user && (user.nome || user.username)) }}</template></span>`,
};

export const PageHeader = {
  components: { Icon },
  props: { title: String, eyebrow: String, backTo: { type: String, default: '/home' }, noBack: Boolean },
  setup: (p) => ({ goBack: () => back(p.backTo) }),
  template: `<header class="page-head">
    <button v-if="!noBack" class="back" type="button" @click="goBack" aria-label="Voltar"><Icon name="back" :size="20" /></button>
    <div><div v-if="eyebrow" class="eyebrow">{{ eyebrow }}</div><h1>{{ title }}</h1></div>
    <div class="actions"><slot name="actions" /></div></header>`,
};

export const SectionHeader = {
  props: { title: String, action: String },
  emits: ['action'],
  template: `<div class="section-head"><h2>{{ title }}</h2><button v-if="action" class="btn btn-ghost sm" type="button" @click="$emit('action')">{{ action }}</button></div>`,
};

export const StatTile = {
  props: { value: [String, Number], label: String },
  template: `<div class="stat"><strong class="num">{{ value }}</strong><span>{{ label }}</span></div>`,
};

export const FeatureTile = {
  components: { Icon },
  props: { icon: String, title: String, subtitle: String, tone: { type: String, default: 'pink' } },
  template: `<button type="button" class="feature" :class="'tone-'+tone"><Icon :name="icon" :size="28" /><span><b>{{ title }}</b><small>{{ subtitle }}</small></span></button>`,
};

export const Notice = {
  components: { Icon },
  props: { tone: { type: String, default: 'yellow' }, icon: { type: String, default: 'info' } },
  template: `<div class="notice" :class="tone === 'yellow' ? '' : tone"><Icon :name="icon" :size="20" /><div><slot /></div></div>`,
};

export const Tag = {
  props: { tone: { type: String, default: '' } },
  template: `<span class="tag" :class="tone"><slot /></span>`,
};

// Cartão de lista: renderiza <button> se tiver @click, <div> caso contrário.
export const ListCard = {
  components: { Icon },
  props: { emoji: String, icon: String, tone: { type: String, default: 'navy' }, title: String, subtitle: String, clickable: Boolean, chevron: Boolean },
  emits: ['click'],
  template: `<component :is="clickable ? 'button' : 'div'" :type="clickable ? 'button' : undefined" class="list-card" @click="clickable && $emit('click')">
    <span class="lead" :class="['bg-'+tone,'fg-'+tone]"><template v-if="emoji">{{ emoji }}</template><Icon v-else-if="icon" :name="icon" :size="22" /><slot name="lead" /></span>
    <span class="grow"><span class="title" style="display:block">{{ title }}</span><span v-if="subtitle" class="sub" style="display:block">{{ subtitle }}</span></span>
    <span class="end"><slot name="end" /></span><Icon v-if="chevron" name="right" :size="18" style="color:var(--muted)" /></component>`,
};

export const EmptyState = {
  components: { Icon },
  props: { icon: { type: String, default: 'paw' }, title: String, text: String },
  template: `<div class="empty"><Icon :name="icon" :size="40" /><b>{{ title }}</b><p>{{ text }}</p><slot /></div>`,
};

export const Spinner = { props: { dark: Boolean }, template: `<span class="spinner" :class="{dark}" role="status" aria-label="Carregando"></span>` };

// Diálogo acessível: Esc fecha, foco inicial no diálogo, clique fora fecha.
export const Modal = {
  components: { Icon },
  props: { title: String, danger: Boolean },
  emits: ['close'],
  setup(p, { emit }) {
    const el = ref(null);
    const onKey = (e) => { if (e.key === 'Escape') emit('close'); };
    let previous = null;
    onMounted(async () => {
      previous = document.activeElement;
      document.addEventListener('keydown', onKey);
      await nextTick();
      const first = el.value && el.value.querySelector('input,textarea,select,button:not(.x)');
      (first || el.value).focus();
    });
    onBeforeUnmount(() => { document.removeEventListener('keydown', onKey); previous && previous.focus && previous.focus(); });
    return { el };
  },
  template: `<div class="overlay" @mousedown.self="$emit('close')"><div class="modal" ref="el" role="dialog" aria-modal="true" :aria-label="title" tabindex="-1">
    <h2>{{ title }}</h2><slot /></div></div>`,
};

export const Switch = {
  props: { modelValue: Boolean, label: String },
  emits: ['update:modelValue'],
  template: `<label class="switch"><input type="checkbox" role="switch" :checked="modelValue" :aria-label="label" @change="$emit('update:modelValue', $event.target.checked)"><span></span></label>`,
};

export const all = { Icon, BrandMark, PetAvatar, UserAvatar, PageHeader, SectionHeader, StatTile, FeatureTile, Notice, Tag, ListCard, EmptyState, Spinner, Modal, Switch };
