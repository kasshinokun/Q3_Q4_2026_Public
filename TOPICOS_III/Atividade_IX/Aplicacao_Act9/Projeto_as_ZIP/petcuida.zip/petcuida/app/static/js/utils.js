export const TIPOS = {
  cao: { label: 'Cão', emoji: '🐶' },
  gato: { label: 'Gato', emoji: '🐱' },
  passaro: { label: 'Pássaro', emoji: '🐦' },
  outro: { label: 'Outro', emoji: '🐾' },
};
export const tipoEmoji = (t) => (TIPOS[t] || TIPOS.outro).emoji;
export const tipoLabel = (t) => (TIPOS[t] || TIPOS.outro).label;

export const todayISO = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};
export const parseISO = (iso) => {
  const [y, m, d] = String(iso).split('-').map(Number);
  return new Date(y, m - 1, d);
};
export const addDaysISO = (iso, n) => {
  const d = parseISO(iso); d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
export const fmtDate = (iso) => (iso ? parseISO(iso).toLocaleDateString('pt-BR') : '');
export const fmtShort = (iso) => parseISO(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
export const fmtWeekday = (iso) => parseISO(iso).toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '');
export const daysUntil = (iso) => Math.round((parseISO(iso) - parseISO(todayISO())) / 86400000);

export function relative(iso) {
  const n = daysUntil(iso);
  if (n === 0) return 'Hoje';
  if (n === 1) return 'Amanhã';
  if (n === -1) return 'Ontem';
  if (n > 1 && n <= 60) return `Em ${n} dias`;
  if (n < -1) return `Há ${-n} dias`;
  return fmtDate(iso);
}

export function ageLabel(nascimento) {
  if (!nascimento) return '';
  const b = parseISO(nascimento), t = parseISO(todayISO());
  let months = (t.getFullYear() - b.getFullYear()) * 12 + t.getMonth() - b.getMonth();
  if (t.getDate() < b.getDate()) months -= 1;
  months = Math.max(months, 0);
  const y = Math.floor(months / 12), m = months % 12;
  if (y === 0) return m === 1 ? '1 mês' : `${m} meses`;
  const anos = y === 1 ? '1 ano' : `${y} anos`;
  return m ? `${anos} e ${m} ${m === 1 ? 'mês' : 'meses'}` : anos;
}

export const money = (n) => `R$ ${Number(n).toLocaleString('pt-BR', { minimumFractionDigits: Number.isInteger(+n) ? 0 : 2, maximumFractionDigits: 2 })}`;
export const credits = (n) => Number(n).toLocaleString('pt-BR', { maximumFractionDigits: 2 });
export const initials = (nome = '') => nome.trim().split(/\s+/).slice(0, 2).map((p) => p[0]).join('').toUpperCase() || '?';

// Redimensiona a foto no navegador (lado máx. 360 px) antes de enviar ao servidor.
export function resizeImage(file, max = 360, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) return reject(new Error('Escolha um arquivo de imagem.'));
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Não foi possível ler a imagem.')); };
    img.src = url;
  });
}

export function download(filename, content, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = Object.assign(document.createElement('a'), { href: url, download: filename });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
