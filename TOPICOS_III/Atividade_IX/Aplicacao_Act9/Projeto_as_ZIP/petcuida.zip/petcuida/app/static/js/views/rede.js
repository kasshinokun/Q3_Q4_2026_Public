import { ref, reactive, computed } from 'vue';
import { all } from '../components/ui.js';
import { api } from '../api.js';
import { state, pet, refresh, toast, activeBookings } from '../store.js';
import { go, route } from '../router.js';
import { money, credits, todayISO, addDaysISO, fmtWeekday, fmtShort, fmtDate } from '../utils.js';

const norm = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const SERVICE_ICON = { stethoscope: 'stethoscope', syringe: 'syringe', heart: 'heart', scissors: 'scissors' };
const SERVICE_TONE = ['pink', 'yellow', 'lavender', 'navy'];

export const Rede = {
  components: all,
  setup() {
    const q = ref('');
    const results = computed(() => {
      const t = norm(q.value.trim());
      if (!t) return null;
      const hit = (...f) => f.some((x) => norm(String(x || '')).includes(t));
      return {
        servicos: state.servicos.filter((s) => hit(s.nome, s.prestador, s.local, s.descricao)),
        pedidos: state.pedidos.filter((p) => hit(p.titulo, p.solicitante, p.local, p.descricao)),
      };
    });
    return { state, q, results, go, credits, money, SERVICE_ICON, SERVICE_TONE, activeBookings };
  },
  template: `
  <div class="page">
    <PageHeader title="Rede Solidária" eyebrow="Cuidado em comunidade" no-back>
      <template #actions><a class="credit-chip" style="background:var(--navy-soft);color:var(--navy)" href="#/perfil/saldo"><Icon name="diamond" :size="16" /> {{ credits(state.user.saldo) }} créditos</a></template>
    </PageHeader>
    <div class="field input-icon" style="position:relative;max-width:640px;margin-bottom:22px">
      <Icon name="search" :size="20" /><label class="sr-only" for="rd-q">Buscar na rede</label>
      <input id="rd-q" class="input" v-model="q" type="search" placeholder="Buscar clínica, serviço ou pedido de ajuda" autocomplete="off">
    </div>

    <template v-if="results">
      <div class="section-head"><h2>Resultados para “{{ q }}”</h2></div>
      <div class="stack" style="max-width:760px">
        <ListCard v-for="s in results.servicos" :key="s.id" clickable chevron icon="stethoscope" tone="navy" :title="s.nome" :subtitle="s.prestador + ' · ' + s.local" @click="go('/rede/agendar/' + s.id)"><template #end><span class="price">{{ money(s.preco) }}</span></template></ListCard>
        <ListCard v-for="p in results.pedidos" :key="p.id" clickable chevron icon="handheart" tone="lavender" :title="p.titulo" :subtitle="p.solicitante + ' · ' + p.local" @click="go('/rede/mural')"><template #end><Tag tone="lavender">+{{ p.recompensa }} cr.</Tag></template></ListCard>
        <EmptyState v-if="!results.servicos.length && !results.pedidos.length" icon="search" title="Nada encontrado" text="Tente buscar por 'vacina', 'banho' ou o nome de um bairro." />
      </div>
    </template>

    <div v-else class="split">
      <div>
        <div class="map" role="img" aria-label="Mapa esquemático da região com clínicas parceiras e pedidos de ajuda">
          <Icon class="center" name="pin" :size="58" fill />
          <button class="pin" style="left:8%;top:14%;background:var(--pink);color:var(--pink-ink)" @click="go('/rede/clinicas')"><Icon name="stethoscope" :size="16" /> Clínica PetCuida</button>
          <button class="pin" style="right:7%;top:30%;background:var(--yellow);color:var(--yellow-ink)" @click="go('/rede/clinicas')"><Icon name="scissors" :size="16" /> Ana Pet Estética</button>
          <button class="pin" style="left:14%;bottom:16%;background:var(--lavender);color:var(--lavender-ink)" @click="go('/rede/mural')"><Icon name="handheart" :size="16" /> Pedidos de ajuda</button>
          <span class="pin" style="right:9%;bottom:10%;background:#fff;color:var(--muted);box-shadow:none;border:1px dashed var(--line)">Você está aqui</span>
        </div>
        <p class="muted xs" style="margin-top:8px">Mapa ilustrativo. A integração com mapas reais (Google Maps / OpenStreetMap) está prevista para a próxima fase.</p>
      </div>
      <div class="stack">
        <ListCard clickable chevron icon="stethoscope" tone="pink" title="Clínicas e serviços" subtitle="Preço social e pagamento híbrido" @click="go('/rede/clinicas')" />
        <ListCard clickable chevron icon="map" tone="yellow" title="Mapa de clínicas" subtitle="Parceiros por região" @click="go('/rede/mapa')" />
        <ListCard clickable chevron icon="handheart" tone="lavender" title="Mural de ajuda" subtitle="Ganhe créditos ajudando outros tutores" @click="go('/rede/mural')" />
        <Notice tone="navy" icon="diamond"><b>Como funcionam os créditos?</b>Você ganha créditos ajudando outros tutores e usa para abater o valor de serviços na rede.</Notice>
        <button v-if="activeBookings.length" class="btn btn-soft block" @click="go('/perfil/agendamentos')"><Icon name="calendarcheck" :size="18" /> {{ activeBookings.length }} agendamento(s) ativo(s)</button>
      </div>
    </div>
  </div>`,
};

export const Servicos = {
  components: all,
  setup: () => ({ state, go, money, SERVICE_ICON, SERVICE_TONE }),
  template: `
  <div class="page narrow">
    <PageHeader title="Clínicas e serviços" back-to="/rede" />
    <Notice tone="pink" icon="heart"><b>Preço social</b>Serviços com valores reduzidos para tutores da rede. Use créditos para abater parte do valor.</Notice>
    <div class="stack" style="margin-top:16px">
      <ListCard v-for="(s, i) in state.servicos" :key="s.id" :icon="SERVICE_ICON[s.icone] || 'stethoscope'" :tone="SERVICE_TONE[i % 4]" :title="s.nome" :subtitle="s.prestador + ' · ' + s.local + ' — ' + s.descricao">
        <template #end><span class="price">{{ money(s.preco) }}</span>
          <Tag v-if="s.agendado" tone="good">Agendado ✓</Tag>
          <button v-else class="btn btn-primary sm" @click="go('/rede/agendar/' + s.id)">Agendar</button></template>
      </ListCard>
    </div>
  </div>`,
};

export const Mapa = {
  components: all,
  setup: () => ({ go }),
  template: `
  <div class="page">
    <PageHeader title="Mapa de clínicas" back-to="/rede" />
    <div class="split">
      <div class="map" role="img" aria-label="Mapa esquemático de clínicas parceiras" style="min-height:440px">
        <Icon class="center" name="pin" :size="58" fill />
        <span class="pin" style="left:10%;top:16%;background:var(--pink);color:var(--pink-ink)"><Icon name="stethoscope" :size="16" /> Clínica PetCuida · Padre Eustáquio</span>
        <span class="pin" style="right:6%;top:42%;background:var(--yellow);color:var(--yellow-ink)"><Icon name="scissors" :size="16" /> Ana Pet Estética · Floresta</span>
        <span class="pin" style="left:20%;bottom:14%;background:var(--lavender);color:var(--lavender-ink)"><Icon name="handheart" :size="16" /> Prado</span>
      </div>
      <div class="stack">
        <ListCard icon="stethoscope" tone="pink" title="Clínica PetCuida" subtitle="Padre Eustáquio · consultas, vacinas e castração"><template #end><Tag tone="good">Parceira</Tag></template></ListCard>
        <ListCard icon="scissors" tone="yellow" title="Ana Pet Estética" subtitle="Floresta · banho e tosa"><template #end><Tag tone="good">Parceira</Tag></template></ListCard>
        <Notice tone="navy" icon="info"><b>Em breve</b>Localização em tempo real, rotas e horários de funcionamento.</Notice>
        <button class="btn btn-primary block" @click="go('/rede/clinicas')">Ver serviços e agendar</button>
      </div>
    </div>
  </div>`,
};

export const Mural = {
  components: all,
  setup() {
    const open = ref(false), busy = ref(false), error = ref('');
    const f = reactive({ titulo: '', descricao: '', recompensa: 2 });
    const apply = async (p) => {
      try { await api.post(`/pedidos/${p.id}/candidatura`); await refresh(); toast('Candidatura enviada! Acompanhe em “Atividade recente”.'); }
      catch (e) { toast(e.message, 'error'); }
    };
    const create = async () => {
      error.value = '';
      if (!f.titulo.trim() || !f.descricao.trim()) { error.value = 'Preencha título e descrição.'; return; }
      busy.value = true;
      try { await api.post('/pedidos', { ...f }); await refresh(); open.value = false; Object.assign(f, { titulo: '', descricao: '', recompensa: 2 }); toast('Pedido publicado no mural.'); }
      catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    return { state, open, busy, error, f, apply, create };
  },
  template: `
  <div class="page narrow">
    <PageHeader title="Mural de ajuda" back-to="/rede">
      <template #actions><button class="btn btn-primary sm" @click="open = true"><Icon name="plus" :size="16" /> Pedir ajuda</button></template>
    </PageHeader>
    <Notice tone="yellow" icon="handheart"><b>Ajude e ganhe créditos</b>Candidate-se a um pedido. Ao concluir, os créditos vão para o seu saldo.</Notice>
    <div class="stack" style="margin-top:16px">
      <ListCard v-for="p in state.pedidos" :key="p.id" icon="handheart" tone="lavender" :title="p.titulo" :subtitle="p.descricao + ' — ' + p.solicitante + ' · ' + p.local">
        <template #end><Tag tone="lavender">+{{ p.recompensa }} créditos</Tag>
          <Tag v-if="p.meu">Seu pedido</Tag>
          <Tag v-else-if="p.candidatado" tone="good">Candidatura enviada</Tag>
          <button v-else class="btn btn-soft sm" @click="apply(p)">Candidatar-se</button></template>
      </ListCard>
    </div>
    <Modal v-if="open" title="Pedir ajuda" @close="open = false">
      <form @submit.prevent="create" novalidate style="margin-top:14px">
        <div class="field"><label class="label" for="pd-t">Título</label><input id="pd-t" class="input" v-model="f.titulo" maxlength="90" placeholder="Ex.: Levar gato ao veterinário"></div>
        <div class="field"><label class="label" for="pd-d">Descrição</label><textarea id="pd-d" class="textarea" v-model="f.descricao" maxlength="300" placeholder="Conte o que precisa, dia e horário"></textarea></div>
        <div class="field"><span class="label" id="pd-r">Recompensa (créditos)</span>
          <div class="chips" role="radiogroup" aria-labelledby="pd-r"><button v-for="n in [1,2,3,4,5]" :key="n" type="button" class="chip" role="radio" :aria-checked="f.recompensa === n" @click="f.recompensa = n">{{ n }}</button></div></div>
        <div v-if="error" class="msg error" role="alert">{{ error }}</div>
        <div class="actions"><button type="button" class="btn btn-line" @click="open = false">Cancelar</button><button class="btn btn-primary" :disabled="busy"><Spinner v-if="busy" />Publicar</button></div>
      </form>
    </Modal>
  </div>`,
};

const HORARIOS = ['09:00', '10:30', '14:00', '16:30'];

export const Agendar = {
  components: all,
  setup() {
    const servico = computed(() => state.servicos.find((s) => s.id === route.params.id));
    const dias = Array.from({ length: 5 }, (_, i) => addDaysISO(todayISO(), i + 1));
    const dia = ref(dias[0]), hora = ref('');
    const next = () => go(`/rede/checkout/${servico.value.id}?dia=${dia.value}&h=${hora.value}`);
    return { servico, dias, dia, hora, HORARIOS, pet, next, fmtWeekday, fmtShort, money, go };
  },
  template: `
  <div v-if="!servico" class="page narrow"><EmptyState icon="search" title="Serviço não encontrado"><button class="btn btn-primary" style="margin-top:12px" @click="go('/rede/clinicas')">Ver serviços</button></EmptyState></div>
  <div v-else class="page narrow">
    <PageHeader title="Agendar atendimento" back-to="/rede/clinicas" />
    <div class="card">
      <div class="row"><span class="avatar square bg-pink fg-pink" style="width:52px;height:52px"><Icon name="stethoscope" :size="26" /></span>
        <div class="grow"><div class="card-title">{{ servico.nome }}</div><div class="muted small">{{ servico.prestador }} · {{ servico.local }}</div></div><span class="price">{{ money(servico.preco) }}</span></div>
      <hr class="divider">
      <div class="field"><span class="label" id="ag-d">Escolha o dia</span>
        <div class="chips" role="radiogroup" aria-labelledby="ag-d"><button v-for="d in dias" :key="d" type="button" class="chip" role="radio" :aria-checked="dia === d" @click="dia = d" style="text-transform:capitalize">{{ fmtWeekday(d) }} · {{ fmtShort(d) }}</button></div></div>
      <div class="field"><span class="label" id="ag-h">Escolha o horário</span>
        <div class="chips" role="radiogroup" aria-labelledby="ag-h"><button v-for="h in HORARIOS" :key="h" type="button" class="chip" role="radio" :aria-checked="hora === h" @click="hora = h">{{ h }}</button></div></div>
      <p v-if="pet" class="muted small" style="margin-bottom:16px">Atendimento para <b>{{ pet.nome }}</b>.</p>
      <button class="btn btn-primary block" :disabled="!hora" @click="next">Continuar para pagamento</button>
    </div>
  </div>`,
};

export const Checkout = {
  components: all,
  setup() {
    const servico = computed(() => state.servicos.find((s) => s.id === route.params.id));
    const usar = ref(true), busy = ref(false), error = ref('');
    const aplicados = computed(() => (usar.value && servico.value ? Math.min(state.user.saldo, 1, servico.value.preco) : 0));
    const restante = computed(() => (servico.value ? servico.value.preco - aplicados.value : 0));
    const confirm = async () => {
      busy.value = true; error.value = '';
      try {
        await api.post('/agendamentos', { servico_id: servico.value.id, dia: route.query.dia, horario: route.query.h, usar_creditos: usar.value, pet_id: pet.value && pet.value.id });
        await refresh(); toast('Agendamento confirmado!'); go('/perfil/agendamentos', { replace: true });
      } catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    return { servico, usar, busy, error, aplicados, restante, confirm, route, state, money, credits, fmtDate, go };
  },
  template: `
  <div v-if="!servico || !route.query.dia" class="page narrow"><EmptyState icon="search" title="Escolha um serviço primeiro"><button class="btn btn-primary" style="margin-top:12px" @click="go('/rede/clinicas')">Ver serviços</button></EmptyState></div>
  <div v-else class="page narrow">
    <PageHeader title="Pagamento híbrido" :back-to="'/rede/agendar/' + servico.id" />
    <div class="card">
      <div class="card-title">{{ servico.nome }}</div>
      <div class="muted small">{{ servico.prestador }} · {{ fmtDate(route.query.dia) }} às {{ route.query.h }}</div>
      <hr class="divider">
      <label class="setting" style="padding-top:0"><span class="grow"><b>Usar créditos da rede</b><br><span class="muted small">Saldo disponível: {{ credits(state.user.saldo) }} créditos (até 1 por serviço)</span></span>
        <Switch v-model="usar" label="Usar créditos" /></label>
      <div class="sum-row"><span>Valor do serviço</span><span class="num">{{ money(servico.preco) }}</span></div>
      <div class="sum-row"><span>Créditos aplicados</span><span class="num">− {{ money(aplicados) }} ({{ credits(aplicados) }} cr.)</span></div>
      <div class="sum-row total"><span>A pagar na clínica</span><span class="num">{{ money(restante) }}</span></div>
    </div>
    <Notice tone="navy" icon="info" style="margin-top:14px"><b>Pagamento no local</b>Nesta versão alfa não há cobrança online: o valor restante é pago na clínica.</Notice>
    <div v-if="error" class="msg error" role="alert" style="margin-top:14px">{{ error }}</div>
    <button class="btn btn-primary block" style="margin-top:16px" :disabled="busy" @click="confirm"><Spinner v-if="busy" />Confirmar agendamento</button>
  </div>`,
};
