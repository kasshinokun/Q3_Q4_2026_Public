import { ref, reactive, computed, onMounted } from 'vue';
import { all } from '../components/ui.js';
import { PetForm } from '../components/PetForm.js';
import { api } from '../api.js';
import { state, pet, petReminders, petRecords, refresh, toast } from '../store.js';
import { go, route } from '../router.js';
import { ageLabel, tipoLabel, daysUntil, fmtDate, relative, todayISO, download } from '../utils.js';

const NoPet = { components: all, setup: () => ({ go }), template: `<div class="page narrow"><EmptyState title="Nenhum pet cadastrado" text="Cadastre seu pet para liberar prontuário, vacinas e QR Code."><button class="btn btn-primary" style="margin-top:14px" @click="go('/pet/novo')">Cadastrar pet</button></EmptyState></div>` };

export const AreaPet = {
  components: { ...all, NoPet },
  setup() {
    const tiles = [
      { icon: 'edit', title: 'Editar dados', sub: 'Nome, foto, nascimento', tone: 'pink', to: '/pet/editar' },
      { icon: 'calendarcheck', title: 'Calendário de vacinas', sub: 'Lembretes e reforços', tone: 'yellow', to: '/pet/vacinas' },
      { icon: 'folder', title: 'Prontuário e histórico', sub: 'Consultas e exames', tone: 'lavender', to: '/pet/prontuario' },
      { icon: 'qr', title: 'QR Code do pet', sub: 'Identificação rápida', tone: 'navy', to: '/pet/qrcode' },
    ];
    return { state, pet, tiles, go, ageLabel, tipoLabel, petReminders, petRecords, relative };
  },
  template: `
  <NoPet v-if="!pet" />
  <div v-else class="page">
    <PageHeader title="Área do Pet" eyebrow="Tudo sobre o seu companheiro" no-back />
    <div class="split even" style="align-items:stretch">
      <section class="card pet-profile">
        <span class="photo-edit"><PetAvatar :pet="pet" :size="128" /></span>
        <h2>{{ pet.nome }}</h2>
        <p class="muted">{{ tipoLabel(pet.tipo) }}<template v-if="pet.raca"> · {{ pet.raca }}</template></p>
        <div class="row" style="justify-content:center;margin-top:12px;gap:8px;flex-wrap:wrap">
          <Tag tone="lavender"><Icon name="cake" :size="13" />&nbsp;{{ ageLabel(pet.nascimento) }}</Tag>
          <Tag>{{ petReminders.length }} lembretes</Tag><Tag>{{ petRecords.length }} registros</Tag>
        </div>
        <div v-if="state.pets.length > 1" class="chips" style="justify-content:center;margin-top:18px" role="group" aria-label="Escolher pet">
          <button v-for="p in state.pets" :key="p.id" class="chip" :aria-pressed="p.id === pet.id" @click="state.petId = p.id">{{ p.nome }}</button>
        </div>
        <button class="btn btn-ghost sm" style="margin-top:14px" @click="go('/pet/novo')"><Icon name="plus" :size="16" /> Adicionar outro pet</button>
      </section>
      <div class="stack">
        <ListCard v-for="t in tiles" :key="t.to" clickable chevron :icon="t.icon" :tone="t.tone" :title="t.title" :subtitle="t.sub" @click="go(t.to)" />
      </div>
    </div>
  </div>`,
};

export const PetEdit = {
  components: { ...all, PetForm, NoPet },
  setup() {
    const isNew = computed(() => route.path === '/pet/novo');
    const busy = ref(false), error = ref(''), confirmDel = ref(false);
    const initial = computed(() => (isNew.value ? undefined : pet.value ? { ...pet.value } : undefined));
    const submit = async (data) => {
      busy.value = true; error.value = '';
      try {
        if (isNew.value) {
          const r = await api.post('/pets', data); await refresh(); state.petId = r.pet.id; toast(`${data.nome} foi adicionado!`);
        } else { await api.put(`/pets/${pet.value.id}`, data); await refresh(); toast('Dados atualizados.'); }
        go('/pet', { replace: true });
      } catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    const remove = async () => {
      try { await api.del(`/pets/${pet.value.id}`); await refresh(); confirmDel.value = false; toast('Pet removido.'); go('/pet', { replace: true }); }
      catch (e) { confirmDel.value = false; toast(e.message, 'error'); }
    };
    return { isNew, busy, error, initial, submit, pet, confirmDel, remove, state };
  },
  template: `
  <NoPet v-if="!isNew && !pet" />
  <div v-else class="page narrow">
    <PageHeader :title="isNew ? 'Adicionar pet' : 'Editar dados'" back-to="/pet" />
    <div class="card">
      <div v-if="error" class="msg error" role="alert">{{ error }}</div>
      <PetForm :key="isNew ? 'new' : pet.id" :initial="initial" :submit-label="isNew ? 'Adicionar pet' : 'Salvar alterações'" :busy="busy" @submit="submit" />
      <template v-if="!isNew && state.pets.length > 1"><hr class="divider">
        <button class="btn btn-danger block" type="button" @click="confirmDel = true"><Icon name="trash" :size="18" /> Remover {{ pet.nome }}</button></template>
    </div>
    <Modal v-if="confirmDel" title="Remover pet?" @close="confirmDel = false">
      <p class="body">Os lembretes e registros de {{ pet.nome }} também serão removidos. Esta ação não pode ser desfeita.</p>
      <div class="actions"><button class="btn btn-line" @click="confirmDel = false">Cancelar</button><button class="btn btn-danger" @click="remove">Remover</button></div>
    </Modal>
  </div>`,
};

export const Vacinas = {
  components: { ...all, NoPet },
  setup() {
    const open = ref(false), busy = ref(false), error = ref('');
    const f = reactive({ titulo: '', data: '' });
    const today = todayISO();
    const list = computed(() => petReminders.value.map((l) => {
      const d = daysUntil(l.data);
      const custom = l.cor === 'navy';
      return { ...l, custom, tag: d < 0 ? ['Passou', ''] : d <= 7 ? ['Alerta', 'warn'] : custom ? ['Novo', 'good'] : ['Agendado', ''], tone: l.cor === 'pink' ? 'pink' : l.cor === 'yellow' ? 'yellow' : 'navy' };
    }));
    const add = async () => {
      error.value = '';
      if (!f.titulo.trim() || !f.data) { error.value = 'Informe título e data.'; return; }
      busy.value = true;
      try { await api.post('/lembretes', { ...f, pet_id: pet.value.id }); await refresh(); open.value = false; f.titulo = ''; f.data = ''; toast('Lembrete adicionado.'); }
      catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    const remove = async (id) => { try { await api.del(`/lembretes/${id}`); await refresh(); toast('Lembrete removido.'); } catch (e) { toast(e.message, 'error'); } };
    return { pet, list, open, f, busy, error, add, remove, today, relative, fmtDate };
  },
  template: `
  <NoPet v-if="!pet" />
  <div v-else class="page narrow">
    <PageHeader title="Calendário de vacinas" back-to="/pet">
      <template #actions><button class="btn btn-primary sm" @click="open = true"><Icon name="plus" :size="16" /> Novo lembrete</button></template>
    </PageHeader>
    <Notice tone="yellow" icon="bell"><b>Lembretes de {{ pet.nome }}</b>Os avisos aparecem em destaque quando faltam 7 dias ou menos.</Notice>
    <div class="stack" style="margin-top:16px">
      <ListCard v-for="l in list" :key="l.id" :emoji="l.emoji" :tone="l.tone" :title="l.titulo" :subtitle="fmtDate(l.data) + ' · ' + relative(l.data)">
        <template #end><Tag :tone="l.tag[1]">{{ l.tag[0] }}</Tag>
          <button v-if="l.custom" class="icon-btn" style="width:32px;height:32px" @click="remove(l.id)" :aria-label="'Remover ' + l.titulo"><Icon name="trash" :size="16" /></button></template>
      </ListCard>
      <EmptyState v-if="!list.length" icon="calendar" title="Sem lembretes" text="Adicione vacinas, vermífugos e consultas para não esquecer." />
    </div>
    <Modal v-if="open" title="Novo lembrete" @close="open = false">
      <form @submit.prevent="add" novalidate style="margin-top:14px">
        <div class="field"><label class="label" for="lm-t">Título</label><input id="lm-t" class="input" v-model="f.titulo" maxlength="80" placeholder="Ex.: Vermífugo"></div>
        <div class="field"><label class="label" for="lm-d">Data</label><input id="lm-d" type="date" class="input" v-model="f.data" :min="today"></div>
        <div v-if="error" class="msg error" role="alert">{{ error }}</div>
        <div class="actions"><button type="button" class="btn btn-line" @click="open = false">Cancelar</button><button class="btn btn-primary" :disabled="busy"><Spinner v-if="busy" />Adicionar</button></div>
      </form>
    </Modal>
  </div>`,
};

export const Prontuario = {
  components: { ...all, NoPet },
  setup() {
    const open = ref(false), busy = ref(false), error = ref('');
    const f = reactive({ titulo: '', detalhes: '' });
    const add = async () => {
      error.value = '';
      if (!f.titulo.trim() || !f.detalhes.trim()) { error.value = 'Preencha título e detalhes.'; return; }
      busy.value = true;
      try { await api.post('/registros', { ...f, pet_id: pet.value.id }); await refresh(); open.value = false; f.titulo = ''; f.detalhes = ''; toast('Registro adicionado ao prontuário.'); }
      catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    const remove = async (id) => { try { await api.del(`/registros/${id}`); await refresh(); toast('Registro removido.'); } catch (e) { toast(e.message, 'error'); } };
    const tone = (r) => ({ pink: 'pink', yellow: 'yellow', lavender: 'lavender' }[r.cor] || 'navy');
    return { pet, records: petRecords, open, f, busy, error, add, remove, tone, go, ageLabel, tipoLabel };
  },
  template: `
  <NoPet v-if="!pet" />
  <div v-else class="page">
    <PageHeader title="Prontuário e histórico" back-to="/pet">
      <template #actions><button class="btn btn-primary sm" @click="open = true"><Icon name="plus" :size="16" /> Novo registro</button></template>
    </PageHeader>
    <div class="split">
      <div class="stack">
        <ListCard v-for="r in records" :key="r.id" :emoji="r.emoji" :tone="tone(r)" :title="r.titulo" :subtitle="r.detalhes">
          <template #end><Tag :tone="r.tom === 'good' ? 'good' : ''">{{ r.status }}</Tag>
            <button v-if="r.cor === 'navy'" class="icon-btn" style="width:32px;height:32px" @click="remove(r.id)" :aria-label="'Remover ' + r.titulo"><Icon name="trash" :size="16" /></button></template>
        </ListCard>
        <EmptyState v-if="!records.length" icon="folder" title="Prontuário vazio" text="Registre consultas, exames e procedimentos." />
      </div>
      <aside class="stack">
        <div class="card"><div class="row"><PetAvatar :pet="pet" :size="56" />
          <div><div class="card-title">{{ pet.nome }}</div><div class="muted small">{{ tipoLabel(pet.tipo) }} · {{ ageLabel(pet.nascimento) }}</div></div></div>
          <hr class="divider"><button class="btn btn-lavender block" @click="go('/pet/qrcode')"><Icon name="qr" :size="18" /> Gerar QR Code do prontuário</button></div>
        <Notice tone="navy" icon="shield"><b>Seus dados</b>O prontuário fica vinculado à sua conta e pode ser compartilhado com clínicas parceiras.</Notice>
      </aside>
    </div>
    <Modal v-if="open" title="Novo registro" @close="open = false">
      <form @submit.prevent="add" novalidate style="margin-top:14px">
        <div class="field"><label class="label" for="rg-t">Título</label><input id="rg-t" class="input" v-model="f.titulo" maxlength="80" placeholder="Ex.: Consulta dermatológica"></div>
        <div class="field"><label class="label" for="rg-d">Detalhes</label><textarea id="rg-d" class="textarea" v-model="f.detalhes" maxlength="160" placeholder="Data, local, observações…"></textarea></div>
        <div v-if="error" class="msg error" role="alert">{{ error }}</div>
        <div class="actions"><button type="button" class="btn btn-line" @click="open = false">Cancelar</button><button class="btn btn-primary" :disabled="busy"><Spinner v-if="busy" />Salvar</button></div>
      </form>
    </Modal>
  </div>`,
};

export const QrCode = {
  components: { ...all, NoPet },
  setup() {
    const payload = computed(() => pet.value ? `PETCUIDA|${pet.value.id}|${pet.value.nome}|${tipoLabel(pet.value.tipo)}|${ageLabel(pet.value.nascimento)}` : '');
    const svg = computed(() => {
      if (!payload.value || !window.qrcode) return '';
      const qr = window.qrcode(0, 'M'); qr.addData(payload.value); qr.make();
      return qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    });
    const share = async () => {
      const text = `${pet.value.nome} — ${tipoLabel(pet.value.tipo)}, ${ageLabel(pet.value.nascimento)} (PetCuida)`;
      try {
        if (navigator.share) await navigator.share({ title: 'PetCuida', text });
        else { await navigator.clipboard.writeText(payload.value); toast('Dados do QR copiados.'); }
      } catch (e) { if (e.name !== 'AbortError') toast('Não foi possível compartilhar.', 'error'); }
    };
    const save = () => { download(`qrcode-${pet.value.nome.toLowerCase().replace(/\W+/g, '-')}.svg`, svg.value, 'image/svg+xml'); toast('QR Code salvo.'); };
    return { pet, payload, svg, share, save, tipoLabel, ageLabel };
  },
  template: `
  <NoPet v-if="!pet" />
  <div v-else class="page narrow">
    <PageHeader title="QR Code do pet" back-to="/pet" />
    <div class="card" style="text-align:center;padding:32px 20px">
      <div class="qr-box" role="img" :aria-label="'QR Code de ' + pet.nome" v-html="svg"></div>
      <h2 class="display" style="font-size:24px;margin-top:18px">{{ pet.nome }}</h2>
      <p class="muted">{{ tipoLabel(pet.tipo) }} · {{ ageLabel(pet.nascimento) }}</p>
      <p class="muted small" style="margin:14px auto 0;max-width:46ch">Aponte a câmera de um leitor de QR Code para ver os dados de identificação. Ideal para coleira, carteirinha ou clínica parceira.</p>
      <div class="row" style="justify-content:center;margin-top:20px;flex-wrap:wrap">
        <button class="btn btn-primary" @click="share"><Icon name="share" :size="18" /> Compartilhar</button>
        <button class="btn btn-outline" @click="save"><Icon name="download" :size="18" /> Baixar</button>
      </div>
    </div>
  </div>`,
};
