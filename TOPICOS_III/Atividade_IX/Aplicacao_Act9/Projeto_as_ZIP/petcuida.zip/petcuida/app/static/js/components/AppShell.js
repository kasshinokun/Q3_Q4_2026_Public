import { ref, computed, onMounted, onBeforeUnmount } from 'vue';
import { state, clear, toast } from '../store.js';
import { go, section } from '../router.js';
import { api } from '../api.js';
import { credits } from '../utils.js';
import { all } from './ui.js';

const NAV = [
  { key: 'home', label: 'Início', icon: 'home', to: '/home' },
  { key: 'pet', label: 'Meu pet', icon: 'paw', to: '/pet' },
  { key: 'triagem', label: 'Triagem', icon: 'sparkle', to: '/triagem' },
  { key: 'rede', label: 'Rede', icon: 'handheart', to: '/rede' },
];

export const AppShell = {
  components: all,
  setup() {
    const menu = ref(null); // 'brand' | 'user' | null
    const root = ref(null);
    const close = (e) => { if (!root.value || !root.value.contains(e.target) || !e.target.closest('.rel')) menu.value = null; };
    const esc = (e) => { if (e.key === 'Escape') menu.value = null; };
    onMounted(() => { document.addEventListener('click', close); document.addEventListener('keydown', esc); });
    onBeforeUnmount(() => { document.removeEventListener('click', close); document.removeEventListener('keydown', esc); });
    const goTo = (to) => { menu.value = null; go(to); };
    const logout = async () => {
      menu.value = null;
      try { await api.post('/auth/logout'); } catch { /* sessão já inválida */ }
      clear(); toast('Você saiu da sua conta.'); go('/login', { replace: true });
    };
    return { state, NAV, section, menu, root, goTo, logout, credits };
  },
  template: `
  <div ref="root">
    <a class="sr-only" href="#/home" @click.prevent="goTo('/home')">Ir para o início</a>
    <header class="topbar"><div class="topbar-in">
      <div class="rel">
        <button class="brand-btn" type="button" aria-haspopup="menu" :aria-expanded="menu === 'brand'" @click.stop="menu = menu === 'brand' ? null : 'brand'">
          <BrandMark :size="38" /><span>PetCuida</span><Icon class="chev" name="down" :size="16" />
        </button>
        <div v-if="menu === 'brand'" class="popover left" role="menu">
          <div class="po-label">Mais</div>
          <button role="menuitem" @click="goTo('/sobre')"><Icon name="info" :size="18" /> Sobre o projeto</button>
          <button role="menuitem" @click="goTo('/perfil/suporte')"><Icon name="help" :size="18" /> Ajuda e suporte</button>
        </div>
      </div>
      <nav class="nav-desktop" aria-label="Principal">
        <a v-for="n in NAV" :key="n.key" class="nav-link" :href="'#' + n.to" :aria-current="section === n.key ? 'page' : undefined">
          <Icon :name="n.icon" :size="18" />{{ n.label }}</a>
      </nav>
      <div class="right">
        <a class="credit-chip" href="#/perfil/saldo" :title="'Saldo de créditos: ' + credits(state.user.saldo)"><Icon name="diamond" :size="16" /><span class="num">{{ credits(state.user.saldo) }} <span class="t">créditos</span></span></a>
        <div class="rel">
          <button class="avatar-btn" type="button" aria-haspopup="menu" :aria-expanded="menu === 'user'" aria-label="Menu da conta" @click.stop="menu = menu === 'user' ? null : 'user'">
            <UserAvatar :user="state.user" :size="40" /></button>
          <div v-if="menu === 'user'" class="popover right" role="menu">
            <div class="po-label">{{ state.user.nome }} · @{{ state.user.username }}</div>
            <button role="menuitem" @click="goTo('/perfil')"><Icon name="user" :size="18" /> Meu perfil</button>
            <button role="menuitem" @click="goTo('/perfil/agendamentos')"><Icon name="calendarcheck" :size="18" /> Meus agendamentos</button>
            <button role="menuitem" @click="goTo('/perfil/configuracoes')"><Icon name="settings" :size="18" /> Configurações</button>
            <button role="menuitem" @click="logout"><Icon name="logout" :size="18" /> Sair</button>
          </div>
        </div>
      </div>
    </div></header>
    <main id="main"><slot /></main>
    <nav class="bottom-nav" aria-label="Principal">
      <a v-for="n in NAV" :key="n.key" :href="'#' + n.to" :aria-current="section === n.key ? 'page' : undefined">
        <span class="pillbg"><Icon :name="n.icon" :size="22" /></span>{{ n.label }}</a>
    </nav>
  </div>`,
};
