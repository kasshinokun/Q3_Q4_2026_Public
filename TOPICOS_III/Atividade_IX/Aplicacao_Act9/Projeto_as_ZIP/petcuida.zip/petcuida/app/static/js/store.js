import { reactive, computed } from 'vue';
import { api } from './api.js';
import { daysUntil } from './utils.js';

export const state = reactive({
  ready: false, user: null, pets: [], servicos: [], pedidos: [], lembretes: [], registros: [],
  atividades: [], agendamentos: [], petId: null, toasts: [], backend: '', version: '',
});

export function apply(snapshot) {
  if (!snapshot || !snapshot.user) return;
  const { user, pets, servicos, pedidos, lembretes, registros, atividades, agendamentos } = snapshot;
  Object.assign(state, { user, pets, servicos, pedidos, lembretes, registros, atividades, agendamentos });
  if (!pets.some((p) => p.id === state.petId)) state.petId = pets[0] ? pets[0].id : null;
}

export function clear() {
  Object.assign(state, { user: null, pets: [], servicos: [], pedidos: [], lembretes: [], registros: [], atividades: [], agendamentos: [], petId: null });
}

export async function refresh() { apply(await api.get('/me')); }

export async function boot() {
  try { apply(await api.get('/session')); } catch { clear(); }
  state.ready = true;
}

export const pet = computed(() => state.pets.find((p) => p.id === state.petId) || state.pets[0] || null);
export const petReminders = computed(() => state.lembretes.filter((l) => !pet.value || l.pet_id === pet.value.id));
export const petRecords = computed(() => state.registros.filter((r) => !pet.value || r.pet_id === pet.value.id));
export const nextReminder = computed(() => petReminders.value.find((l) => daysUntil(l.data) >= 0) || null);
export const firstName = computed(() => (state.user ? (state.user.nome || state.user.username).split(' ')[0] : ''));
export const activeBookings = computed(() => state.agendamentos.filter((a) => a.status === 'agendado'));

let toastId = 0;
export function toast(message, tone = 'success') {
  const id = ++toastId;
  state.toasts.push({ id, message, tone });
  setTimeout(() => { state.toasts = state.toasts.filter((t) => t.id !== id); }, 3600);
}
