import { ref, reactive, computed, nextTick } from 'vue';
import { all } from '../components/ui.js';
import { api } from '../api.js';
import { pet, toast } from '../store.js';
import { go } from '../router.js';

const LEVEL = {
  urgent: { tone: 'danger', icon: 'alert' },
  attention: { tone: 'yellow', icon: 'info' },
  monitor: { tone: 'navy', icon: 'shield' },
};

export const Triagem = {
  components: all,
  setup() {
    const step = ref(0), answers = reactive({ urgent: '', onset: '' }), result = ref(null), busy = ref(false);
    const questions = computed(() => [
      { key: 'urgent', title: `${pet.value ? pet.value.nome : 'Seu pet'} apresenta sinais de alerta agora?`,
        hint: 'Falta de ar, convulsão, sangramento intenso, desmaio ou dor muito forte.',
        options: [['sim', 'Sim, há sinais de alerta'], ['nao', 'Não, parece estável'], ['incerto', 'Não tenho certeza']] },
      { key: 'onset', title: 'Há quanto tempo os sinais começaram?', hint: 'Isso ajuda a priorizar a avaliação.',
        options: [['horas', 'Há poucas horas'], ['dias', 'Há alguns dias ou mais'], ['incerto', 'Não sei dizer']] },
    ]);
    const choose = async (key, value) => {
      answers[key] = value;
      if (step.value < questions.value.length - 1) { step.value++; return; }
      busy.value = true;
      try { result.value = (await api.post('/triage/evaluate', { ...answers })).result; }
      catch (e) { toast(e.message, 'error'); } finally { busy.value = false; }
    };
    const restart = () => { step.value = 0; result.value = null; answers.urgent = answers.onset = ''; };
    return { step, questions, result, busy, choose, restart, go, LEVEL };
  },
  template: `
  <div class="page narrow">
    <PageHeader title="Triagem" eyebrow="Orientação rápida" no-back />
    <section class="colored-head tone-yellow" aria-label="Sobre a triagem">
      <div class="eyebrow">Passo a passo</div>
      <h2>Vamos entender o que está acontecendo</h2>
      <p>Responda 2 perguntas rápidas. É uma orientação inicial — não substitui o médico-veterinário.</p>
      <div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="2" :aria-valuenow="result ? 2 : step"><i :style="{width: (result ? 100 : step * 50) + '%'}"></i></div>
    </section>

    <div class="card" style="margin-top:18px" aria-live="polite">
      <template v-if="!result">
        <div class="eyebrow">Pergunta {{ step + 1 }} de {{ questions.length }}</div>
        <h2 class="display" style="font-size:21px;margin:6px 0 4px">{{ questions[step].title }}</h2>
        <p class="muted small" style="margin-bottom:16px">{{ questions[step].hint }}</p>
        <div class="stack"><button v-for="o in questions[step].options" :key="o[0]" class="choice" :disabled="busy" @click="choose(questions[step].key, o[0])">
          <Icon name="right" :size="18" style="color:var(--navy)" />{{ o[1] }}</button></div>
        <button v-if="step > 0" class="btn btn-ghost sm" style="margin-top:12px" @click="step--"><Icon name="back" :size="16" /> Voltar</button>
      </template>
      <template v-else>
        <div class="notice" :class="LEVEL[result.level].tone === 'yellow' ? '' : LEVEL[result.level].tone" role="status">
          <Icon :name="LEVEL[result.level].icon" :size="22" /><div><b style="font-size:16px">{{ result.title }}</b>{{ result.text }}</div></div>
        <div class="stack" style="margin-top:16px">
          <button class="btn btn-primary block" @click="go('/rede/clinicas')"><Icon name="stethoscope" :size="18" /> Encontrar atendimento</button>
          <button class="btn btn-outline block" @click="go('/pet/prontuario')"><Icon name="folder" :size="18" /> Registrar no prontuário</button>
          <button class="btn btn-ghost block" @click="restart"><Icon name="refresh" :size="16" /> Refazer triagem</button>
        </div>
        <p class="muted xs" style="margin-top:14px">{{ result.disclaimer }}</p>
      </template>
    </div>

    <button class="list-card" style="margin-top:16px" @click="go('/triagem/chat')">
      <span class="lead bg-lavender fg-lavender"><Icon name="message" :size="22" /></span>
      <span class="grow"><span class="title" style="display:block">Prefiro descrever em uma conversa</span><span class="sub" style="display:block">Conte com suas palavras o que você observou.</span></span>
      <Icon name="right" :size="18" style="color:var(--muted)" />
    </button>
  </div>`,
};

export const Chat = {
  components: all,
  setup() {
    const msgs = ref([{ role: 'bot', text: `Olá! Conte o que você observou em ${pet.value ? pet.value.nome : 'seu pet'}: sintomas, quando começaram e se ele está comendo e bebendo normalmente.` }]);
    const text = ref(''), busy = ref(false), log = ref(null);
    const suggestions = ['Está coçando muito as orelhas', 'Vomitou duas vezes hoje', 'Teve uma convulsão agora'];
    const scroll = async () => { await nextTick(); if (log.value) log.value.scrollTop = log.value.scrollHeight; };
    const send = async (t) => {
      const message = (t ?? text.value).trim();
      if (!message || busy.value) return;
      msgs.value.push({ role: 'me', text: message }); text.value = ''; busy.value = true; scroll();
      try {
        const r = await api.post('/triage/chat', { message });
        await new Promise((res) => setTimeout(res, 450));
        msgs.value.push({ role: 'bot', text: r.reply, urgent: r.urgent });
      } catch (e) { msgs.value.push({ role: 'bot', text: e.message }); }
      finally { busy.value = false; scroll(); }
    };
    return { msgs, text, busy, log, send, suggestions, go };
  },
  template: `
  <div class="page narrow">
    <PageHeader title="Conversa de triagem" back-to="/triagem" />
    <div class="chat">
      <div class="chat-log" ref="log" role="log" aria-live="polite">
        <div v-for="(m, i) in msgs" :key="i" class="bubble" :class="[m.role, m.urgent && 'urgent']">{{ m.text }}
          <button v-if="m.urgent" class="btn btn-danger sm" style="margin-top:10px;display:flex;background:#fff" @click="go('/rede/clinicas')">Ver clínicas parceiras</button></div>
        <div v-if="busy" class="bubble bot typing" aria-label="Digitando"><i></i><i></i><i></i></div>
        <div v-if="msgs.length === 1" class="chips" style="margin-top:6px"><button v-for="s in suggestions" :key="s" class="chip" @click="send(s)">{{ s }}</button></div>
      </div>
      <form class="chat-form" @submit.prevent="send()">
        <label class="sr-only" for="chat-in">Mensagem</label>
        <input id="chat-in" class="input" v-model="text" maxlength="600" placeholder="Descreva o que você observou…" autocomplete="off">
        <button class="btn btn-primary" :disabled="busy || !text.trim()" aria-label="Enviar"><Icon name="send" :size="18" /></button>
      </form>
    </div>
    <p class="muted xs" style="margin-top:12px">Orientação automática e limitada. Em caso de dúvida ou piora, procure um médico-veterinário.</p>
  </div>`,
};
