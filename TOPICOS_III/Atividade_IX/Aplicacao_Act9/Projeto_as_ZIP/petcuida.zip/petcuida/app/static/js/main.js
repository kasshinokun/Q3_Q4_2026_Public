import { createApp, ref, computed, defineComponent } from 'vue';
import { state, boot, toast } from './store.js';
import { define, setGuard, sync, current, route, go } from './router.js';
import { all, Icon } from './components/ui.js';
import { AppShell } from './components/AppShell.js';
import { Splash, Login, Cadastro, Onboarding } from './views/auth.js';
import { Home } from './views/home.js';
import { AreaPet, PetEdit, Vacinas, Prontuario, QrCode } from './views/pet.js';
import { Triagem, Chat } from './views/triagem.js';
import { Rede, Servicos, Mapa, Mural, Agendar, Checkout } from './views/rede.js';
import { Perfil, Saldo, Agendamentos, Config, Suporte } from './views/perfil.js';
import { Sobre } from './views/sobre.js';

const NotFound = {
  components: all,
  setup: () => ({ go }),
  template: `<div class="page narrow"><EmptyState title="Página não encontrada" text="O endereço não existe ou foi movido."><button class="btn btn-primary" style="margin-top:14px" @click="go('/home')">Ir para o início</button></EmptyState></div>`,
};

// auth: exige login · guest: só visitante · tab: aba ativa na navegação
define([
  { path: '/login', component: Login, guest: true },
  { path: '/cadastro', component: Cadastro, guest: true },
  { path: '/onboarding', component: Onboarding, auth: true },
  { path: '/home', component: Home, auth: true, shell: true, tab: 'home' },
  { path: '/pet', component: AreaPet, auth: true, shell: true, tab: 'pet' },
  { path: '/pet/editar', component: PetEdit, auth: true, shell: true, tab: 'pet' },
  { path: '/pet/novo', component: PetEdit, auth: true, shell: true, tab: 'pet' },
  { path: '/pet/vacinas', component: Vacinas, auth: true, shell: true, tab: 'pet' },
  { path: '/pet/prontuario', component: Prontuario, auth: true, shell: true, tab: 'pet' },
  { path: '/pet/qrcode', component: QrCode, auth: true, shell: true, tab: 'pet' },
  { path: '/triagem', component: Triagem, auth: true, shell: true, tab: 'triagem' },
  { path: '/triagem/chat', component: Chat, auth: true, shell: true, tab: 'triagem' },
  { path: '/rede', component: Rede, auth: true, shell: true, tab: 'rede' },
  { path: '/rede/clinicas', component: Servicos, auth: true, shell: true, tab: 'rede' },
  { path: '/rede/mapa', component: Mapa, auth: true, shell: true, tab: 'rede' },
  { path: '/rede/mural', component: Mural, auth: true, shell: true, tab: 'rede' },
  { path: '/rede/agendar/:id', component: Agendar, auth: true, shell: true, tab: 'rede' },
  { path: '/rede/checkout/:id', component: Checkout, auth: true, shell: true, tab: 'rede' },
  { path: '/perfil', component: Perfil, auth: true, shell: true, tab: 'perfil' },
  { path: '/perfil/saldo', component: Saldo, auth: true, shell: true, tab: 'perfil' },
  { path: '/perfil/agendamentos', component: Agendamentos, auth: true, shell: true, tab: 'perfil' },
  { path: '/perfil/configuracoes', component: Config, auth: true, shell: true, tab: 'perfil' },
  { path: '/perfil/suporte', component: Suporte, auth: true, shell: true, tab: 'perfil' },
  { path: '/sobre', component: Sobre, auth: true, shell: true, tab: 'perfil' },
  { path: '/*', component: NotFound, shell: true },
]);

setGuard((next) => {
  const d = next.def;
  const u = state.user;
  if (next.path === '/' || next.path === '') return u ? (u.onboarded ? '/home' : '/onboarding') : '/login';
  if (d && d.auth && !u) return '/login';
  if (d && d.guest && u) return u.onboarded ? '/home' : '/onboarding';
  if (u && !u.onboarded && d && d.auth && next.path !== '/onboarding') return '/onboarding';
  if (u && u.onboarded && next.path === '/onboarding') return '/home';
  return null;
});

const App = defineComponent({
  components: { ...all, AppShell, Splash },
  setup() {
    const showSplash = ref(!sessionStorage.getItem('pc_splash'));
    const leaving = ref(false);
    const hide = () => { if (leaving.value) return; leaving.value = true; setTimeout(() => { showSplash.value = false; }, 350); sessionStorage.setItem('pc_splash', '1'); };
    boot().then(() => { sync(); setTimeout(hide, showSplash.value ? 1500 : 0); });
    const view = computed(() => current.value && current.value.component);
    const shell = computed(() => state.user && current.value && current.value.shell);
    return { state, view, shell, route, showSplash, leaving, hide };
  },
  template: `
  <Splash v-if="showSplash || !state.ready" :leaving="leaving" @click="hide" />
  <template v-if="state.ready">
    <AppShell v-if="shell"><component :is="view" :key="route.path" /></AppShell>
    <component v-else-if="view" :is="view" :key="route.path" />
  </template>
  <div class="toasts" aria-live="polite"><div v-for="t in state.toasts" :key="t.id" class="toast" :class="t.tone" role="status">
    <Icon :name="t.tone === 'error' ? 'alert' : 'check'" :size="18" />{{ t.message }}</div></div>`,
});

const app = createApp(App);
app.config.errorHandler = (err) => { console.error(err); toast('Ocorreu um erro inesperado. Recarregue a página.', 'error'); };
app.mount('#app');
