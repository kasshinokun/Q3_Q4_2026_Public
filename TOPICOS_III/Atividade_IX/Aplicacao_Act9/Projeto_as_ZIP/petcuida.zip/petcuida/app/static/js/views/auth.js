import { ref, reactive, onMounted } from 'vue';
import { all } from '../components/ui.js';
import { PetForm } from '../components/PetForm.js';
import { api } from '../api.js';
import { apply, state, toast } from '../store.js';
import { go } from '../router.js';

// URL da pesquisa vem do servidor (meta tag). Só links https são exibidos.
const surveyEl = document.querySelector('meta[name="petcuida-survey"]');
export const SURVEY_URL = surveyEl && /^https:\/\//.test(surveyEl.content) ? surveyEl.content : '';

export const Splash = {
  components: all,
  props: { leaving: Boolean },
  template: `<div class="splash" :class="{out: leaving}" role="status" aria-live="polite">
    <BrandMark :size="96" /><h1>PetCuida</h1><p>Cuidado acessível, rede solidária</p><span class="spinner"></span></div>`,
};

const AuthLayout = {
  components: all,
  template: `
  <div class="auth">
    <aside class="auth-hero" aria-label="Apresentação do PetCuida">
      <span class="blob" style="width:340px;height:340px;background:var(--pink);right:-90px;top:-70px"></span>
      <span class="blob" style="width:220px;height:220px;background:var(--yellow);left:-60px;bottom:90px"></span>
      <span class="blob" style="width:160px;height:160px;background:var(--lavender);right:60px;bottom:-40px"></span>
      <div class="brand"><BrandMark :size="44" /> PetCuida</div>
      <div class="copy">
        <div class="eyebrow">Rede local de cuidado animal</div>
        <h1>Cuide antes.<br>Cuide junto.</h1>
        <p class="lead">Prontuário digital, triagem orientativa e uma rede solidária de clínicas e tutores — tudo para o seu pet ter cuidado de verdade, sem pesar no bolso.</p>
        <ul class="auth-points">
          <li><span class="dot" style="background:var(--pink);color:var(--pink-ink)"><Icon name="paw" :size="18" /></span>Prontuário, vacinas e QR Code do pet</li>
          <li><span class="dot" style="background:var(--yellow);color:var(--yellow-ink)"><Icon name="sparkle" :size="18" /></span>Triagem rápida e orientação responsável</li>
          <li><span class="dot" style="background:var(--lavender);color:var(--lavender-ink)"><Icon name="handheart" :size="18" /></span>Serviços com preço social e créditos de ajuda</li>
        </ul>
      </div>
      <div class="foot">Versão alfa · Projeto acadêmico PUC Minas</div>
    </aside>
    <main class="auth-main"><slot /></main>
  </div>`,
};

export const Login = {
  components: { ...all, AuthLayout },
  setup() {
    const f = reactive({ username: '', password: '' });
    const show = ref(false), busy = ref(false), error = ref(''), recover = ref(false);
    const enter = (snapshot) => {
      apply(snapshot);
      go(state.user.onboarded ? '/home' : '/onboarding', { replace: true });
    };
    const submit = async () => {
      error.value = '';
      if (!f.username.trim() || !f.password) { error.value = 'Informe usuário e senha.'; return; }
      busy.value = true;
      try { enter(await api.post('/auth/login', f)); }
      catch (e) { error.value = e.message; }
      finally { busy.value = false; }
    };
    const google = async () => {
      busy.value = true;
      try { enter(await api.post('/auth/google-demo')); toast('Login simulado com Google (demonstração).'); }
      catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    const demo = () => { f.username = 'petcuida'; f.password = 'meu pet'; submit(); };
    return { f, show, busy, error, recover, submit, google, demo, go, SURVEY_URL };
  },
  template: `
  <AuthLayout>
    <div class="auth-card">
      <h2>Bem-vindo de volta</h2>
      <p class="sub">Entre para cuidar do seu pet.</p>
      <form @submit.prevent="submit" novalidate>
        <div class="field"><label class="label" for="lg-user">Usuário</label>
          <div class="input-wrap input-icon"><Icon name="user" :size="20" />
            <input id="lg-user" class="input" v-model="f.username" autocomplete="username" autocapitalize="none" placeholder="seu.usuario"></div></div>
        <div class="field"><label class="label" for="lg-pass">Senha</label>
          <div class="input-wrap input-icon"><Icon name="lock" :size="20" />
            <input id="lg-pass" class="input" :type="show ? 'text' : 'password'" v-model="f.password" autocomplete="current-password" placeholder="••••••••">
            <button type="button" class="icon-btn" @click="show = !show" :aria-label="show ? 'Ocultar senha' : 'Mostrar senha'"><Icon :name="show ? 'eyeoff' : 'eye'" :size="20" /></button></div></div>
        <div v-if="error" class="msg error" role="alert">{{ error }}</div>
        <button class="btn btn-primary block" type="submit" :disabled="busy"><Spinner v-if="busy" />Entrar</button>
      </form>
      <button class="btn btn-line block" type="button" style="margin-top:10px" :disabled="busy" @click="google"><span class="g-mark">G</span> Continuar com Google</button>
      <div class="link-row">
        <button class="btn btn-ghost sm" type="button" @click="recover = true">Esqueci a senha</button>
        <button class="btn btn-ghost sm" type="button" @click="go('/cadastro')">Criar conta</button>
      </div>
      <div class="demo-box"><Icon name="sparkle" :size="18" />
        <div class="grow"><b>Demonstração</b><br>usuário <b>petcuida</b> · senha <b>meu pet</b></div>
        <button type="button" @click="demo" :disabled="busy">Entrar agora</button></div>
      <a v-if="SURVEY_URL" class="survey-link" :href="SURVEY_URL" target="_blank" rel="noopener noreferrer">
        <span class="s-ico"><Icon name="message" :size="20" /></span>
        <span class="grow"><b>Ajude a construir o PetCuida</b><small>Responda nossa pesquisa de mercado · 3 a 5 min · participação voluntária</small></span>
        <Icon name="right" :size="18" /><span class="sr-only">(abre em nova aba)</span></a>
    </div>
    <Modal v-if="recover" title="Recuperar senha" @close="recover = false">
      <p class="body">O envio de e-mail de recuperação será ativado junto à integração com autenticação (Firebase Auth ou Supabase Auth). Nesta versão alfa, use o usuário de demonstração ou crie uma nova conta.</p>
      <div class="actions"><button class="btn btn-primary" @click="recover = false">Entendi</button></div>
    </Modal>
  </AuthLayout>`,
};

export const Cadastro = {
  components: { ...all, AuthLayout },
  setup() {
    const f = reactive({ username: '', password: '', confirm: '' });
    const busy = ref(false), error = ref(''), show = ref(false);
    const submit = async () => {
      error.value = '';
      if (!f.username.trim() || !f.password || !f.confirm) { error.value = 'Preencha todos os campos.'; return; }
      if (f.password !== f.confirm) { error.value = 'As senhas não conferem.'; return; }
      if (f.password.length < 4) { error.value = 'A senha deve ter pelo menos 4 caracteres.'; return; }
      busy.value = true;
      try {
        await api.post('/auth/register', f);
        apply(await api.post('/auth/login', { username: f.username, password: f.password }));
        toast('Conta criada! Agora cadastre seu pet.');
        go('/onboarding', { replace: true });
      } catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    return { f, busy, error, show, submit, go };
  },
  template: `
  <AuthLayout>
    <div class="auth-card">
      <h2>Crie sua conta</h2>
      <p class="sub">Leva menos de um minuto.</p>
      <form @submit.prevent="submit" novalidate>
        <div class="field"><label class="label" for="cd-user">Usuário</label>
          <div class="input-wrap input-icon"><Icon name="user" :size="20" /><input id="cd-user" class="input" v-model="f.username" autocomplete="username" autocapitalize="none" placeholder="escolha um usuário"></div></div>
        <div class="field"><label class="label" for="cd-pass">Senha</label>
          <div class="input-wrap input-icon"><Icon name="lock" :size="20" />
            <input id="cd-pass" class="input" :type="show ? 'text' : 'password'" v-model="f.password" autocomplete="new-password" placeholder="mínimo 4 caracteres">
            <button type="button" class="icon-btn" @click="show = !show" :aria-label="show ? 'Ocultar senha' : 'Mostrar senha'"><Icon :name="show ? 'eyeoff' : 'eye'" :size="20" /></button></div></div>
        <div class="field"><label class="label" for="cd-conf">Confirmar senha</label>
          <div class="input-wrap input-icon"><Icon name="lock" :size="20" /><input id="cd-conf" class="input" :type="show ? 'text' : 'password'" v-model="f.confirm" autocomplete="new-password" placeholder="repita a senha"></div></div>
        <div v-if="error" class="msg error" role="alert">{{ error }}</div>
        <button class="btn btn-primary block" type="submit" :disabled="busy"><Spinner v-if="busy" />Criar conta</button>
      </form>
      <div class="link-row" style="justify-content:center"><button class="btn btn-ghost sm" type="button" @click="go('/login')">Já tenho conta</button></div>
    </div>
  </AuthLayout>`,
};

export const Onboarding = {
  components: { ...all, AuthLayout, PetForm },
  setup() {
    const busy = ref(false), error = ref('');
    const submit = async (pet) => {
      busy.value = true; error.value = '';
      try { apply(await api.post('/me/onboarding', pet)); toast(`${pet.nome} foi cadastrado!`); go('/home', { replace: true }); }
      catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    return { busy, error, submit, go, state };
  },
  template: `
  <AuthLayout>
    <div class="auth-card" style="max-width:480px">
      <div class="eyebrow">Passo final</div>
      <h2>Vamos conhecer seu pet</h2>
      <p class="sub">Com isso montamos o prontuário e os lembretes de cuidado.</p>
      <div v-if="error" class="msg error" role="alert">{{ error }}</div>
      <PetForm submit-label="Concluir cadastro" :busy="busy" @submit="submit" />
    </div>
  </AuthLayout>`,
};
