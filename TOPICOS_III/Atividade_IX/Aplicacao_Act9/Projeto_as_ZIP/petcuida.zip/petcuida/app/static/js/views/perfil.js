import { ref, reactive, computed } from 'vue';
import { all } from '../components/ui.js';
import { api } from '../api.js';
import { state, refresh, apply, clear, toast, activeBookings } from '../store.js';
import { go } from '../router.js';
import { credits, fmtDate, resizeImage, money } from '../utils.js';
import { STATUS } from './home.js';
import { SURVEY_URL } from './auth.js';

export const Perfil = {
  components: all,
  setup() {
    const photo = ref(null);
    const pick = async (e) => {
      const file = e.target.files && e.target.files[0]; e.target.value = '';
      if (!file) return;
      try { apply(await api.patch('/me', { foto: await resizeImage(file, 280) })); toast('Foto atualizada.'); }
      catch (err) { toast(err.message, 'error'); }
    };
    const logout = async () => {
      try { await api.post('/auth/logout'); } catch { /* sessão já encerrada */ }
      clear(); toast('Você saiu da sua conta.'); go('/login', { replace: true });
    };
    const items = [
      { icon: 'calendarcheck', title: 'Meus agendamentos', sub: 'Consultas e serviços', tone: 'pink', to: '/perfil/agendamentos' },
      { icon: 'diamond', title: 'Saldo e extrato', sub: 'Créditos da rede solidária', tone: 'yellow', to: '/perfil/saldo' },
      { icon: 'settings', title: 'Configurações da conta', sub: 'Dados, notificações e senha', tone: 'lavender', to: '/perfil/configuracoes' },
      { icon: 'help', title: 'Suporte e ajuda', sub: 'Dúvidas frequentes', tone: 'navy', to: '/perfil/suporte' },
      { icon: 'info', title: 'Sobre o projeto', sub: 'Equipe, termos e privacidade', tone: 'pink', to: '/sobre' },
    ];
    return { state, photo, pick, logout, items, go, credits, activeBookings };
  },
  template: `
  <div class="page">
    <PageHeader title="Meu perfil" no-back />
    <div class="split even">
      <section class="card tone-lavender" style="text-align:center;padding:30px 20px;border:0">
        <span class="photo-edit"><UserAvatar :user="state.user" :size="112" />
          <button class="cam" type="button" @click="photo.click()" aria-label="Alterar foto de perfil"><Icon name="camera" :size="16" /></button></span>
        <input ref="photo" type="file" accept="image/*" hidden @change="pick">
        <h2 class="display" style="font-size:24px;margin-top:14px">{{ state.user.nome }}</h2>
        <p class="small" style="opacity:.85">@{{ state.user.username }}<template v-if="state.user.email"> · {{ state.user.email }}</template></p>
        <p v-if="state.user.bairro" class="small" style="opacity:.85;margin-top:4px"><Icon name="pin" :size="14" /> {{ state.user.bairro }}</p>
        <div class="stats" style="margin-top:20px;text-align:left">
          <StatTile :value="credits(state.user.saldo)" label="Créditos" /><StatTile :value="activeBookings.length" label="Agendados" /><StatTile :value="state.pets.length" label="Pets" />
        </div>
      </section>
      <div class="stack">
        <ListCard v-for="i in items" :key="i.to" clickable chevron :icon="i.icon" :tone="i.tone" :title="i.title" :subtitle="i.sub" @click="go(i.to)" />
        <button class="btn btn-danger block" style="margin-top:6px" @click="logout"><Icon name="logout" :size="18" /> Sair da conta</button>
      </div>
    </div>
  </div>`,
};

export const Saldo = {
  components: all,
  setup: () => ({ state, credits, STATUS, go }),
  template: `
  <div class="page">
    <PageHeader title="Saldo e extrato" back-to="/perfil" />
    <div class="split">
      <div>
        <div class="section-head"><h2>Movimentações</h2></div>
        <div class="stack">
          <ListCard v-for="a in state.atividades" :key="a.id" :icon="a.variacao > 0 ? 'plus' : 'calendarcheck'" :tone="a.variacao > 0 ? 'lavender' : 'navy'" :title="a.nome" :subtitle="a.data">
            <template #end><span v-if="a.variacao" class="price num" :style="{color: a.variacao > 0 ? 'var(--success)' : 'var(--navy)'}">{{ a.variacao > 0 ? '+' : '' }}{{ credits(a.variacao) }} cr.</span>
              <Tag :tone="STATUS[a.status].tone">{{ STATUS[a.status].label }}</Tag></template>
          </ListCard>
          <EmptyState v-if="!state.atividades.length" icon="coin" title="Sem movimentações" text="Agende serviços ou ajude outros tutores para movimentar seu saldo." />
        </div>
      </div>
      <aside class="stack" style="gap:16px">
        <div class="balance-card"><div class="eyebrow">Saldo disponível</div><strong class="num">{{ credits(state.user.saldo) }} <span style="font-size:18px;font-weight:700">créditos</span></strong></div>
        <Notice tone="yellow" icon="handheart"><b>Como ganhar créditos</b>Candidate-se a pedidos no Mural de ajuda e conclua a tarefa.</Notice>
        <button class="btn btn-primary block" @click="go('/rede/mural')">Ir para o mural de ajuda</button>
      </aside>
    </div>
  </div>`,
};

export const Agendamentos = {
  components: all,
  setup() {
    const busy = ref(null);
    const upcoming = computed(() => state.agendamentos.filter((a) => a.status === 'agendado'));
    const past = computed(() => state.agendamentos.filter((a) => a.status !== 'agendado'));
    const cancel = async (a) => {
      busy.value = a.id;
      try { await api.del(`/agendamentos/${a.id}`); await refresh(); toast('Agendamento cancelado e créditos devolvidos.'); }
      catch (e) { toast(e.message, 'error'); } finally { busy.value = null; }
    };
    const petName = (a) => (state.pets.find((p) => p.id === a.pet_id) || {}).nome || 'Pet';
    return { upcoming, past, cancel, busy, go, fmtDate, money, credits, petName };
  },
  template: `
  <div class="page narrow">
    <PageHeader title="Meus agendamentos" back-to="/perfil" />
    <div class="stack">
      <ListCard v-for="a in upcoming" :key="a.id" icon="calendarcheck" tone="pink" :title="a.servico.nome" :subtitle="fmtDate(a.dia) + ' às ' + a.horario + ' · ' + a.servico.prestador + ' · ' + petName(a)">
        <template #end><Tag tone="good">Agendado</Tag><span class="muted xs">Pagar {{ money(a.dinheiro) }}<template v-if="a.creditos"> + {{ credits(a.creditos) }} cr.</template></span>
          <button class="btn btn-danger sm" :disabled="busy === a.id" @click="cancel(a)">Cancelar</button></template>
      </ListCard>
      <EmptyState v-if="!upcoming.length" icon="calendar" title="Nenhum agendamento ativo" text="Escolha um serviço na rede e agende em poucos cliques.">
        <button class="btn btn-primary" style="margin-top:14px" @click="go('/rede/clinicas')">Ver serviços</button></EmptyState>
    </div>
    <template v-if="past.length"><div class="section-head"><h2>Histórico</h2></div>
      <div class="stack"><ListCard v-for="a in past" :key="a.id" icon="calendar" tone="navy" :title="a.servico.nome" :subtitle="fmtDate(a.dia) + ' às ' + a.horario"><template #end><Tag tone="danger">Cancelado</Tag></template></ListCard></div></template>
  </div>`,
};

export const Config = {
  components: all,
  setup() {
    const f = reactive({ nome: state.user.nome, email: state.user.email || '', bairro: state.user.bairro || '' });
    const busy = ref(false), error = ref('');
    const pw = reactive({ open: false, current: '', next: '', error: '', busy: false });
    const reset = reactive({ open: false, busy: false });
    const save = async () => {
      busy.value = true; error.value = '';
      try { apply(await api.patch('/me', f)); toast('Dados salvos.'); } catch (e) { error.value = e.message; } finally { busy.value = false; }
    };
    const setting = async (key, value) => {
      try { apply(await api.patch('/me', { settings: { [key]: value } })); } catch (e) { toast(e.message, 'error'); }
    };
    const changePw = async () => {
      pw.busy = true; pw.error = '';
      try { await api.post('/me/password', { current: pw.current, new: pw.next }); pw.open = false; pw.current = pw.next = ''; toast('Senha alterada.'); }
      catch (e) { pw.error = e.message; } finally { pw.busy = false; }
    };
    const doReset = async () => {
      reset.busy = true;
      try { apply(await api.post('/demo/reset')); reset.open = false; toast('Dados restaurados ao estado inicial.'); go(state.user.onboarded ? '/home' : '/onboarding', { replace: true }); }
      catch (e) { toast(e.message, 'error'); reset.busy = false; }
    };
    const toggles = [['push', 'Notificações push', 'Avisos no navegador e no app'], ['vacinas', 'Lembretes de vacina', 'Receba avisos antes dos reforços'], ['emails', 'E-mails de novidades', 'Novidades e campanhas da rede']];
    return { state, f, busy, error, save, setting, pw, changePw, reset, doReset, toggles };
  },
  template: `
  <div class="page">
    <PageHeader title="Configurações" back-to="/perfil" />
    <div class="split even">
      <section class="card"><h2 class="card-title" style="margin-bottom:16px">Dados da conta</h2>
        <form @submit.prevent="save" novalidate>
          <div class="field"><label class="label" for="cf-n">Nome</label><input id="cf-n" class="input" v-model="f.nome" maxlength="80"></div>
          <div class="field"><label class="label" for="cf-e">E-mail</label><input id="cf-e" type="email" class="input" v-model="f.email" maxlength="120" placeholder="voce@exemplo.com"></div>
          <div class="field"><label class="label" for="cf-b">Bairro / cidade</label><input id="cf-b" class="input" v-model="f.bairro" maxlength="80" placeholder="Ex.: Padre Eustáquio, Belo Horizonte"></div>
          <div v-if="error" class="msg error" role="alert">{{ error }}</div>
          <div class="row" style="flex-wrap:wrap"><button class="btn btn-primary" :disabled="busy"><Spinner v-if="busy" />Salvar dados</button>
          <button type="button" class="btn btn-line" @click="pw.open = true"><Icon name="lock" :size="16" /> Alterar senha</button></div>
        </form></section>
      <div class="stack" style="gap:16px">
        <section class="card"><h2 class="card-title">Notificações</h2>
          <div v-for="t in toggles" :key="t[0]" class="setting"><span class="grow"><b>{{ t[1] }}</b><br><span class="muted small">{{ t[2] }}</span></span>
            <Switch :model-value="state.user.settings[t[0]]" :label="t[1]" @update:model-value="setting(t[0], $event)" /></div></section>
        <section class="card"><h2 class="card-title">Apresentação / demonstração</h2>
          <p class="muted small" style="margin:6px 0 14px">Restaura pet, lembretes, prontuário, créditos e agendamentos ao estado inicial. Ideal para recomeçar entre apresentações.</p>
          <button class="btn btn-danger" @click="reset.open = true"><Icon name="refresh" :size="16" /> Restaurar dados de demonstração</button></section>
      </div>
    </div>
    <Modal v-if="pw.open" title="Alterar senha" @close="pw.open = false">
      <form @submit.prevent="changePw" novalidate style="margin-top:14px">
        <div class="field"><label class="label" for="pw-c">Senha atual</label><input id="pw-c" type="password" class="input" v-model="pw.current" autocomplete="current-password"></div>
        <div class="field"><label class="label" for="pw-n">Nova senha</label><input id="pw-n" type="password" class="input" v-model="pw.next" autocomplete="new-password" placeholder="mínimo 4 caracteres"></div>
        <div v-if="pw.error" class="msg error" role="alert">{{ pw.error }}</div>
        <div class="actions"><button type="button" class="btn btn-line" @click="pw.open = false">Cancelar</button><button class="btn btn-primary" :disabled="pw.busy"><Spinner v-if="pw.busy" />Alterar</button></div>
      </form>
    </Modal>
    <Modal v-if="reset.open" title="Restaurar dados?" @close="reset.open = false">
      <p class="body">Todos os dados desta conta voltam ao estado inicial. Contas de demonstração recuperam o pet Rex; outras contas voltam ao cadastro do primeiro pet.</p>
      <div class="actions"><button class="btn btn-line" @click="reset.open = false">Cancelar</button><button class="btn btn-danger" :disabled="reset.busy" @click="doReset">Restaurar</button></div>
    </Modal>
  </div>`,
};

export const Suporte = {
  components: all,
  setup() {
    const contact = ref(false);
    const faqs = [
      ['Como funcionam os créditos solidários?', 'Você ganha créditos ao ajudar outros tutores (passeios, transporte, cuidados) e usa para abater o valor de serviços em clínicas parceiras.'],
      ['A triagem substitui a consulta veterinária?', 'Não. Ela é apenas uma orientação inicial. Diante de sinais de alerta, procure atendimento imediatamente.'],
      ['Como gero o QR Code do meu pet?', 'Acesse Meu pet › QR Code do pet. Você pode compartilhar ou baixar a imagem para usar na coleira ou na carteirinha.'],
      ['Posso cadastrar mais de um pet?', 'Sim. Em Meu pet, toque em “Adicionar outro pet” e alterne entre eles pelos botões de nome.'],
      ['Meus dados estão seguros?', 'Na versão alfa os dados ficam no servidor de demonstração. Não cadastre informações reais sensíveis. A versão final terá autenticação reforçada e conformidade com a LGPD.'],
    ];
    return { contact, faqs, SURVEY_URL };
  },
  template: `
  <div class="page narrow">
    <PageHeader title="Suporte e ajuda" back-to="/perfil" />
    <details v-for="(q, i) in faqs" :key="i" class="faq"><summary>{{ q[0] }}<Icon name="right" :size="18" /></summary><p>{{ q[1] }}</p></details>
    <div class="stack" style="margin-top:20px">
      <button class="btn btn-primary block" @click="contact = true"><Icon name="phone" :size="18" /> Falar com o suporte</button>
      <a v-if="SURVEY_URL" class="btn btn-lavender block" :href="SURVEY_URL" target="_blank" rel="noopener noreferrer"><Icon name="message" :size="18" /> Responder pesquisa de mercado</a>
    </div>
    <Modal v-if="contact" title="Falar com o suporte" @close="contact = false">
      <p class="body">O canal de atendimento será habilitado na versão beta. Por enquanto, envie sugestões pela pesquisa de mercado ou procure a equipe do projeto.</p>
      <div class="actions"><button class="btn btn-primary" @click="contact = false">Entendi</button></div>
    </Modal>
  </div>`,
};
