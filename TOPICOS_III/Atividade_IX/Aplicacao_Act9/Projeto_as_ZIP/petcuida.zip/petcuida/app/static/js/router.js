import { reactive, computed, shallowRef } from 'vue';

// Roteador por hash (#/caminho?x=1): funciona em qualquer hospedagem e com o botão "voltar".
const routes = [];
export const route = reactive({ path: '/', params: {}, query: {}, def: null });
export const current = shallowRef(null);

export function define(table) {
  table.forEach((r) => {
    const keys = [];
    const rx = new RegExp('^' + r.path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    routes.push({ ...r, rx, keys });
  });
}

function parse() {
  const raw = location.hash.replace(/^#/, '') || '/';
  const [path, qs = ''] = raw.split('?');
  const query = Object.fromEntries(new URLSearchParams(qs));
  for (const r of routes) {
    const m = path.match(r.rx);
    if (m) {
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      return { path, params, query, def: r };
    }
  }
  return { path, params: {}, query, def: routes.find((r) => r.path === '/*') || null };
}

let guard = () => null;
export function setGuard(fn) { guard = fn; }

export function sync() {
  let next = parse();
  const redirect = guard(next);
  if (redirect && redirect !== next.path) {
    history.replaceState(null, '', '#' + redirect);
    next = parse();
  }
  Object.assign(route, next);
  current.value = next.def;
  window.scrollTo(0, 0);
}

export function go(path, { replace = false } = {}) {
  if (replace) { history.replaceState(null, '', '#' + path); sync(); }
  else if (location.hash === '#' + path) sync();
  else location.hash = path; // dispara hashchange → sync
}
export function back(fallback = '/home') {
  if (history.length > 1 && window.__pcNavigated) history.back(); else go(fallback, { replace: true });
}

window.addEventListener('hashchange', () => { window.__pcNavigated = true; sync(); });
export const section = computed(() => (route.def && route.def.tab) || '');
