import { ref, onMounted } from 'vue';
import { all } from '../components/ui.js';
import { api } from '../api.js';
import { state } from '../store.js';
import { SURVEY_URL } from './auth.js';

// Créditos do projeto (iguais ao CreditosProjeto do app Flutter; nomes completos ainda são TODO da equipe).
const PROJETO = {
  universidade: 'Pontifícia Universidade Católica de Minas Gerais (PUC Minas)',
  etapa: 'Etapa VI — versão alfa Web (Flask + Vue) · build 3i rev 2',
  curso: 'Engenharia/Ciências da Computação',
  disciplina: 'Tópicos III - Empreendedorismo e Inovação',
  grupo: 'Grupo 4',
  devs: ['Giovanna', 'Gabriel', 'Kathleen', 'Julia'],
  profs: ['João Carlos', 'Paulo'],
};
const TERMOS = 'O PetCuida é um protótipo acadêmico desenvolvido para fins de estudo, sem fins comerciais e sem garantias de disponibilidade ou continuidade. As informações de triagem apresentadas são orientativas e não substituem, em nenhuma hipótese, a avaliação de um médico-veterinário. Ao usar este protótipo, você concorda que os dados inseridos (nomes, fotos e demais informações) são fictícios ou de demonstração e que o sistema pode ser modificado, reiniciado ou descontinuado a qualquer momento sem aviso prévio, por se tratar de um trabalho em desenvolvimento.';
const PRIVACIDADE = 'Nesta versão alfa web, os dados (perfil do tutor, dados do pet, fotos, saldo de créditos e histórico) ficam armazenados no banco do servidor de demonstração e não são compartilhados com terceiros. As senhas são guardadas apenas como hash. Use somente dados fictícios. Fotos são reduzidas no seu navegador antes do envio e usadas exclusivamente para exibição no sistema. Em versões futuras, com autenticação e backend em nuvem, esta política será atualizada para detalhar coleta, armazenamento e direitos do titular dos dados, conforme a LGPD.';

export const Sobre = {
  components: all,
  setup() {
    const doc = ref(null), health = ref(null);
    onMounted(async () => { try { health.value = await api.get('/health'); } catch { health.value = { ok: false }; } });
    return { P: PROJETO, TERMOS, PRIVACIDADE, doc, health, state, SURVEY_URL };
  },
  template: `
  <div class="page narrow">
    <PageHeader title="Sobre o projeto" back-to="/perfil" />
    <section class="card" style="text-align:center">
      <img class="about-seal" src="/static/img/brasao-pucminas.png" alt="Brasão da PUC Minas">
      <h2 class="display" style="font-size:19px">{{ P.universidade }}</h2>
      <p class="muted small" style="margin-top:6px">{{ P.etapa }}</p>
    </section>
    <div class="section-head"><h2>Dados acadêmicos</h2></div>
    <section class="card flat"><div class="info-row"><span>Curso</span><span>{{ P.curso }}</span></div>
      <div class="info-row"><span>Disciplina</span><span>{{ P.disciplina }}</span></div><div class="info-row"><span>Turma / grupo</span><span>{{ P.grupo }}</span></div></section>
    <div class="grid-2" style="margin-top:16px">
      <section class="card flat"><div class="row"><Icon name="settings" :size="18" style="color:var(--navy)" /><b>Equipe de desenvolvimento</b></div><div class="names"><Tag v-for="n in P.devs" :key="n">{{ n }}</Tag></div></section>
      <section class="card flat"><div class="row"><Icon name="user" :size="18" style="color:var(--navy)" /><b>Professores orientadores</b></div><div class="names"><Tag v-for="n in P.profs" :key="n" tone="lavender">{{ n }}</Tag></div></section>
    </div>
    <div class="section-head"><h2>Documentos</h2></div>
    <div class="stack">
      <ListCard clickable chevron icon="file" tone="yellow" title="Termos de uso" @click="doc = 'termos'" />
      <ListCard clickable chevron icon="shield" tone="lavender" title="Política de privacidade" @click="doc = 'privacidade'" />
      <a v-if="SURVEY_URL" class="list-card" :href="SURVEY_URL" target="_blank" rel="noopener noreferrer" style="text-decoration:none;color:inherit">
        <span class="lead bg-pink fg-pink"><Icon name="message" :size="22" /></span><span class="grow"><span class="title" style="display:block">Pesquisa de mercado</span><span class="sub" style="display:block">Conte o que você espera do PetCuida (3 a 5 min)</span></span><Icon name="right" :size="18" style="color:var(--muted)" /></a>
    </div>
    <div class="section-head"><h2>Status do sistema</h2></div>
    <section class="card flat"><div class="info-row"><span>Versão</span><span>{{ health && health.version || '—' }}</span></div>
      <div class="info-row"><span>Armazenamento ativo</span><span><Tag :tone="health && health.ok ? 'good' : 'danger'">{{ health && health.backend || 'indisponível' }}</Tag></span></div></section>
    <p class="muted xs" style="text-align:center;margin-top:22px">PetCuida — © 2026<br>Projeto acadêmico sem fins comerciais</p>
    <Modal v-if="doc" :title="doc === 'termos' ? 'Termos de uso' : 'Política de privacidade'" @close="doc = null">
      <p class="body legal">{{ doc === 'termos' ? TERMOS : PRIVACIDADE }}</p>
      <div class="actions"><button class="btn btn-primary" @click="doc = null">Fechar</button></div>
    </Modal>
  </div>`,
};
