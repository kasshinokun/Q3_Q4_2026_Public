import { ref, reactive, computed } from 'vue';
import { all } from './ui.js';
import { TIPOS, ageLabel, todayISO, resizeImage } from '../utils.js';
import { toast } from '../store.js';

// Formulário de pet compartilhado por onboarding, "adicionar pet" e "editar pet".
export const PetForm = {
  components: all,
  props: { initial: Object, submitLabel: { type: String, default: 'Salvar' }, busy: Boolean },
  emits: ['submit'],
  setup(p, { emit }) {
    const f = reactive({ nome: '', tipo: 'cao', raca: '', nascimento: '', foto: null, ...(p.initial || {}) });
    const errors = reactive({});
    const gallery = ref(null), camera = ref(null);
    const today = todayISO();
    const idade = computed(() => (f.nascimento && f.nascimento <= today ? ageLabel(f.nascimento) : ''));
    const pickPhoto = async (e) => {
      const file = e.target.files && e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try { f.foto = await resizeImage(file); } catch (err) { toast(err.message, 'error'); }
    };
    const submit = () => {
      errors.nome = f.nome.trim() ? '' : 'Informe o nome do pet.';
      errors.nascimento = !f.nascimento ? 'Informe a data de nascimento.' : f.nascimento > today ? 'A data não pode ser no futuro.' : '';
      if (errors.nome || errors.nascimento) return;
      emit('submit', { nome: f.nome.trim(), tipo: f.tipo, raca: f.raca.trim(), nascimento: f.nascimento, foto: f.foto });
    };
    return { f, errors, TIPOS, gallery, camera, idade, today, pickPhoto, submit };
  },
  template: `
  <form @submit.prevent="submit" novalidate>
    <div class="row" style="justify-content:center;margin-bottom:22px;flex-direction:column;gap:12px">
      <span class="photo-edit"><PetAvatar :pet="f" :size="112" tone="pink" /><span class="cam"><Icon name="camera" :size="16" /></span></span>
      <div class="row" style="gap:8px">
        <button type="button" class="btn btn-soft sm" @click="gallery.click()"><Icon name="image" :size="16" /> Galeria</button>
        <button type="button" class="btn btn-soft sm" @click="camera.click()"><Icon name="camera" :size="16" /> Câmera</button>
        <button v-if="f.foto" type="button" class="btn btn-ghost sm" @click="f.foto = null">Remover</button>
      </div>
      <input ref="gallery" type="file" accept="image/*" hidden @change="pickPhoto">
      <input ref="camera" type="file" accept="image/*" capture="environment" hidden @change="pickPhoto">
    </div>
    <div class="field"><label class="label" for="pf-nome">Nome do pet</label>
      <input id="pf-nome" class="input" :class="{invalid: errors.nome}" v-model="f.nome" maxlength="60" placeholder="Ex.: Rex" autocomplete="off">
      <div v-if="errors.nome" class="field-error">{{ errors.nome }}</div></div>
    <div class="field"><span class="label" id="pf-tipo">Espécie</span>
      <div class="chips" role="radiogroup" aria-labelledby="pf-tipo">
        <button v-for="(t, k) in TIPOS" :key="k" type="button" class="chip" role="radio" :aria-checked="f.tipo === k" @click="f.tipo = k">{{ t.emoji }} {{ t.label }}</button>
      </div></div>
    <div class="field"><label class="label" for="pf-raca">Raça <span class="muted" style="text-transform:none;letter-spacing:0;font-weight:600">(opcional)</span></label>
      <input id="pf-raca" class="input" v-model="f.raca" maxlength="60" placeholder="Ex.: SRD, Poodle, Siamês"></div>
    <div class="field"><label class="label" for="pf-nasc">Data de nascimento</label>
      <div class="date-pill"><input id="pf-nasc" type="date" class="input" :class="{invalid: errors.nascimento}" v-model="f.nascimento" :max="today" style="max-width:220px">
        <span v-if="idade" class="tag lavender"><Icon name="cake" :size="14" />&nbsp;{{ idade }}</span></div>
      <div v-if="errors.nascimento" class="field-error">{{ errors.nascimento }}</div></div>
    <button class="btn btn-primary block" type="submit" :disabled="busy"><Spinner v-if="busy" />{{ submitLabel }}</button>
  </form>`,
};
