"""Fábrica de backends. A aplicação só conhece ``build_store`` e ``DocumentStore``."""
from __future__ import annotations

import os

from .base import BackendNotConfiguredError, DocumentStore

BACKENDS = ("sqlite", "firestore", "supabase")


def build_store(backend: str, *, db_path: str) -> DocumentStore:
    backend = (backend or "sqlite").strip().lower()
    if backend == "sqlite":
        from .sqlite_adapter import SQLiteDocumentStore
        return SQLiteDocumentStore(db_path)
    if backend in ("firestore", "firebase"):
        from .firestore_adapter import FirestoreDocumentStore
        return FirestoreDocumentStore(project_id=os.getenv("FIREBASE_PROJECT_ID"))
    if backend == "supabase":
        from .supabase_adapter import SupabaseDocumentStore
        key = os.getenv("SUPABASE_SERVICE_KEY") or os.getenv("SUPABASE_ANON_KEY")
        return SupabaseDocumentStore(os.getenv("SUPABASE_URL"), key)
    raise BackendNotConfiguredError(
        f"Backend desconhecido: {backend!r}. Use um de: {', '.join(BACKENDS)}."
    )


__all__ = ["build_store", "DocumentStore", "BackendNotConfiguredError", "BACKENDS"]
