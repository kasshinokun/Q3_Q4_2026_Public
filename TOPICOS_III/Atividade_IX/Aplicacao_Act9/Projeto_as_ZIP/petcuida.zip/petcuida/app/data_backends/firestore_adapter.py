"""Adaptador Firebase / Cloud Firestore (inativo até ser selecionado).

Ativação (``PETCUIDA_BACKEND=firestore``):

1. ``pip install -r requirements-firebase.txt``
2. Credenciais *fora do repositório*, de uma das formas:
   - ``GOOGLE_APPLICATION_CREDENTIALS=/caminho/service-account.json``; ou
   - ``FIREBASE_CREDENTIALS_JSON='{"type":"service_account",...}'`` (secret manager/CI).
3. ``FIREBASE_PROJECT_ID`` (opcional se já estiver no JSON de credenciais).
4. Publicar ``docs/firestore.rules`` — o acesso do app é sempre via servidor
   (Admin SDK), então as regras bloqueiam leitura/escrita direta de clientes.

Mapeamento: ``collection`` -> coleção do Firestore, ``id`` -> ID do documento.
É o mesmo desenho de ``firebase_firestore_data_source.dart`` no app Flutter, então
as duas versões podem compartilhar o mesmo projeto Firebase.
"""
from __future__ import annotations

import json
import os
from typing import Any

from .base import BackendNotConfiguredError, Document, DocumentStore, with_id


class FirestoreDocumentStore(DocumentStore):
    name = "firestore"

    def __init__(self, client: Any = None, project_id: str | None = None):
        # ``client`` permite injetar um Firestore já pronto (e um dublê nos testes).
        self._db = client if client is not None else self._build_client(project_id)

    @staticmethod
    def _build_client(project_id: str | None):
        try:
            import firebase_admin
            from firebase_admin import credentials, firestore
        except ImportError as exc:  # pragma: no cover - depende de pacote opcional
            raise BackendNotConfiguredError(
                "Firestore selecionado, mas 'firebase-admin' não está instalado. "
                "Execute: pip install -r requirements-firebase.txt"
            ) from exc

        if not firebase_admin._apps:  # type: ignore[attr-defined]
            raw = os.getenv("FIREBASE_CREDENTIALS_JSON")
            try:
                cred = credentials.Certificate(json.loads(raw)) if raw else credentials.ApplicationDefault()
            except Exception as exc:  # pragma: no cover - depende de credenciais reais
                raise BackendNotConfiguredError(
                    "Credenciais do Firebase ausentes ou inválidas. Defina "
                    "GOOGLE_APPLICATION_CREDENTIALS ou FIREBASE_CREDENTIALS_JSON."
                ) from exc
            options = {"projectId": project_id} if project_id else None
            firebase_admin.initialize_app(cred, options)
        return firestore.client()

    # ----- contrato -----------------------------------------------------------
    def get(self, collection: str, doc_id: str) -> Document | None:
        snap = self._db.collection(collection).document(doc_id).get()
        return with_id(snap.id, snap.to_dict() or {}) if snap.exists else None

    def set(self, collection: str, doc_id: str, data: Document) -> Document:
        doc = with_id(doc_id, data)
        # Sem merge: o repositório sempre grava o documento completo (evita campos órfãos).
        self._db.collection(collection).document(doc_id).set(doc)
        return doc

    def delete(self, collection: str, doc_id: str) -> None:
        self._db.collection(collection).document(doc_id).delete()

    def find(self, collection: str, **equals) -> list[Document]:
        query: Any = self._db.collection(collection)
        for field, value in equals.items():
            query = query.where(field, "==", value)
        return [with_id(s.id, s.to_dict() or {}) for s in query.stream()]

    def healthcheck(self) -> bool:
        # Leitura barata de um documento inexistente valida rede + credenciais.
        self._db.collection("_health").document("ping").get()
        return True
