"""Contrato de persistência do PetCuida.

Espelha o ``RemoteDataSource`` do app Flutter (``lib/core/data/remote_data_source.dart``):
a aplicação enxerga apenas *coleções* de *documentos* (dicionários JSON com um ``id``).
Qualquer backend que implemente ``DocumentStore`` pode ser plugado sem mudar rotas,
regras de negócio ou frontend:

    sqlite (padrão)  ->  firestore  ->  supabase

Coleções utilizadas: users, pets, servicos, pedidos, candidaturas, atividades,
agendamentos, lembretes, registros.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Iterable

Document = dict[str, Any]


class BackendNotConfiguredError(RuntimeError):
    """Backend remoto escolhido, mas SDK/credenciais ausentes."""


class DocumentStore(ABC):
    """Operações mínimas que todo backend precisa oferecer."""

    #: nome curto exibido na tela "Sobre" / ``/api/health``
    name = "abstract"

    @abstractmethod
    def get(self, collection: str, doc_id: str) -> Document | None: ...

    @abstractmethod
    def set(self, collection: str, doc_id: str, data: Document) -> Document:
        """Cria ou substitui o documento (upsert). Retorna o documento salvo."""

    @abstractmethod
    def delete(self, collection: str, doc_id: str) -> None: ...

    @abstractmethod
    def find(self, collection: str, **equals: Any) -> list[Document]:
        """Lista documentos cujos campos são iguais aos filtros (AND).

        Sem filtros, retorna a coleção inteira. A ordenação é responsabilidade
        de quem chama (o repositório ordena em Python para ser idêntica em todos
        os backends).
        """

    # ----- utilitários com implementação padrão -------------------------------
    def delete_where(self, collection: str, **equals: Any) -> int:
        docs = self.find(collection, **equals)
        for doc in docs:
            self.delete(collection, doc["id"])
        return len(docs)

    def healthcheck(self) -> bool:
        """Verifica se o backend responde. Implementações remotas devem sobrescrever."""
        return True

    def close(self) -> None:  # pragma: no cover - opcional
        return None


def with_id(doc_id: str, data: Document) -> Document:
    """Garante que o documento carrega o próprio ``id`` (como no Flutter)."""
    return {**data, "id": doc_id}


def matches(doc: Document, filters: dict[str, Any]) -> bool:
    return all(doc.get(key) == value for key, value in filters.items())


def only(items: Iterable[Document]) -> list[Document]:
    return [dict(item) for item in items]
