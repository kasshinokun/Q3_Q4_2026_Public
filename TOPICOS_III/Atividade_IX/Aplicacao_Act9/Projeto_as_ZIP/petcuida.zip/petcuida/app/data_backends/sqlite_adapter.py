"""Backend padrão: SQLite local (zero configuração, ideal para demonstração).

Cada documento vira uma linha ``documents(collection, id, data)`` com JSON em
``data``. Filtros usam ``json_extract`` (SQLite >= 3.38 embutido no Python 3.10+).
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading

from .base import Document, DocumentStore, with_id

_SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    collection TEXT NOT NULL,
    id         TEXT NOT NULL,
    data       TEXT NOT NULL,
    PRIMARY KEY (collection, id)
);
CREATE INDEX IF NOT EXISTS idx_documents_user ON documents (collection, json_extract(data, '$.user_id'));
"""


class SQLiteDocumentStore(DocumentStore):
    name = "sqlite"

    def __init__(self, path: str):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        # Uma conexão por instância; o lock evita corrida entre threads do servidor de dev.
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def get(self, collection: str, doc_id: str) -> Document | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT data FROM documents WHERE collection=? AND id=?", (collection, doc_id)
            ).fetchone()
        return json.loads(row["data"]) if row else None

    def set(self, collection: str, doc_id: str, data: Document) -> Document:
        doc = with_id(doc_id, data)
        with self._lock:
            self._conn.execute(
                "INSERT INTO documents(collection, id, data) VALUES (?,?,?) "
                "ON CONFLICT(collection, id) DO UPDATE SET data=excluded.data",
                (collection, doc_id, json.dumps(doc, ensure_ascii=False)),
            )
            self._conn.commit()
        return doc

    def delete(self, collection: str, doc_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM documents WHERE collection=? AND id=?", (collection, doc_id))
            self._conn.commit()

    def find(self, collection: str, **equals) -> list[Document]:
        sql = "SELECT data FROM documents WHERE collection=?"
        params: list = [collection]
        for field, value in equals.items():
            if not field.replace("_", "").isalnum():  # nomes de campo são internos, mas validamos
                raise ValueError(f"Campo inválido: {field!r}")
            sql += f" AND json_extract(data, '$.{field}') = ?"
            params.append(int(value) if isinstance(value, bool) else value)
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [json.loads(r["data"]) for r in rows]

    def healthcheck(self) -> bool:
        with self._lock:
            self._conn.execute("SELECT 1").fetchone()
        return True

    def close(self) -> None:
        with self._lock:
            self._conn.close()
