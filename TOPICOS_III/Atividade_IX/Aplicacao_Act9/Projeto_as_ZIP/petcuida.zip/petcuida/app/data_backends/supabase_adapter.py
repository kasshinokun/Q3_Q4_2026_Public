"""Adaptador Supabase (Postgres via PostgREST) — inativo até ser selecionado.

Ativação (``PETCUIDA_BACKEND=supabase``):

1. Rodar ``supabase/schema.sql`` no SQL Editor do projeto.
2. ``pip install -r requirements-supabase.txt`` (apenas ``requests``).
3. Definir (fora do repositório): ``SUPABASE_URL`` e ``SUPABASE_SERVICE_KEY``
   (chave *service_role*, **somente no servidor**). Para testes locais é aceito
   ``SUPABASE_ANON_KEY`` — nesse caso é preciso liberar a RLS das tabelas.

Cada coleção é uma tabela ``pc_<coleção>`` com colunas ``id text PK``,
``user_id text`` e ``data jsonb``. Usar JSONB mantém o contrato idêntico ao
Firestore e ao SQLite, sem tradução de esquema.

Fala direto com a API REST do Supabase (``/rest/v1``) para evitar dependência
pesada; é equivalente ao ``supabase_data_source.dart`` do app Flutter.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote

from .base import BackendNotConfiguredError, Document, DocumentStore, with_id

TABLE_PREFIX = "pc_"
_TIMEOUT = 10


class SupabaseDocumentStore(DocumentStore):
    name = "supabase"

    def __init__(self, url: str | None, key: str | None, session: Any = None):
        if not url or not key:
            raise BackendNotConfiguredError(
                "Supabase selecionado, mas SUPABASE_URL e SUPABASE_SERVICE_KEY "
                "(ou SUPABASE_ANON_KEY) não foram definidos."
            )
        self._base = url.rstrip("/") + "/rest/v1"
        if session is None:
            try:
                import requests
            except ImportError as exc:  # pragma: no cover - depende de pacote opcional
                raise BackendNotConfiguredError(
                    "Supabase selecionado, mas 'requests' não está instalado. "
                    "Execute: pip install -r requirements-supabase.txt"
                ) from exc
            session = requests.Session()
        self._http = session
        self._headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }

    # ----- helpers ------------------------------------------------------------
    @staticmethod
    def _table(collection: str) -> str:
        return TABLE_PREFIX + collection

    def _call(self, method: str, collection: str, *, params: dict | None = None,
              json_body: Any = None, prefer: str | None = None):
        headers = dict(self._headers)
        if prefer:
            headers["Prefer"] = prefer
        resp = self._http.request(
            method, f"{self._base}/{self._table(collection)}",
            params=params, json=json_body, headers=headers, timeout=_TIMEOUT,
        )
        if resp.status_code >= 400:
            raise RuntimeError(f"Supabase {method} {collection}: HTTP {resp.status_code} — {resp.text[:200]}")
        return resp

    @staticmethod
    def _unwrap(row: dict) -> Document:
        return with_id(row["id"], row.get("data") or {})

    # ----- contrato -----------------------------------------------------------
    def get(self, collection: str, doc_id: str) -> Document | None:
        rows = self._call("GET", collection, params={"select": "id,data", "id": f"eq.{doc_id}", "limit": "1"}).json()
        return self._unwrap(rows[0]) if rows else None

    def set(self, collection: str, doc_id: str, data: Document) -> Document:
        doc = with_id(doc_id, data)
        row = {"id": doc_id, "user_id": str(doc.get("user_id") or ""), "data": doc}
        self._call("POST", collection, json_body=row,
                   prefer="resolution=merge-duplicates,return=minimal", params={"on_conflict": "id"})
        return doc

    def delete(self, collection: str, doc_id: str) -> None:
        self._call("DELETE", collection, params={"id": f"eq.{doc_id}"})

    def find(self, collection: str, **equals) -> list[Document]:
        params: dict[str, str] = {"select": "id,data"}
        for field, value in equals.items():
            if field == "user_id":
                params["user_id"] = f"eq.{value}"
            else:  # filtro em JSONB: data->>campo=eq.valor
                params[f"data->>{field}"] = f"eq.{quote(str(value).lower() if isinstance(value, bool) else str(value))}"
        return [self._unwrap(r) for r in self._call("GET", collection, params=params).json()]

    def healthcheck(self) -> bool:
        self._call("GET", "users", params={"select": "id", "limit": "1"})
        return True
