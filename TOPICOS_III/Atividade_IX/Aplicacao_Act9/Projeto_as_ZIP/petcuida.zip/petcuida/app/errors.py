class ApiError(Exception):
    """Erro de regra de negócio/validação convertido em JSON pelas rotas."""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status
