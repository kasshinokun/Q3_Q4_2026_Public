"""API JSON do PetCuida (prefixo ``/api``)."""
from __future__ import annotations

from functools import wraps

from flask import Blueprint, current_app, jsonify, request, session

from . import triage
from .errors import ApiError
from .repository import Repository

api = Blueprint("api", __name__)


def repo() -> Repository:
    return current_app.extensions["petcuida_repo"]


def body() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def ok(**data):
    return jsonify({"ok": True, **data})


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        uid = session.get("uid")
        if not uid or not repo().get_user(uid):
            session.clear()
            raise ApiError("Faça login para continuar.", 401)
        return view(uid, *args, **kwargs)
    return wrapper


@api.errorhandler(ApiError)
def handle_api_error(err: ApiError):
    return jsonify({"ok": False, "error": err.message}), err.status


def _start_session(user: dict):
    session.clear()
    session["uid"] = user["id"]
    session.permanent = True
    return ok(**repo().snapshot(user["id"]))


# ------------------------------------------------------------------- saúde
@api.get("/health")
def health():
    store = current_app.extensions["petcuida_store"]
    try:
        healthy = store.healthcheck()
    except Exception as exc:  # backend remoto fora do ar não derruba a demo
        return jsonify({"ok": False, "backend": store.name, "error": str(exc)[:200]}), 503
    return ok(backend=store.name, healthy=healthy, version=current_app.config["APP_VERSION"])


# -------------------------------------------------------------------- auth
@api.post("/auth/login")
def login():
    data = body()
    return _start_session(repo().authenticate(data.get("username", ""), data.get("password", "")))


@api.post("/auth/register")
def register():
    data = body()
    user = repo().register(data.get("username", ""), data.get("password", ""), data.get("confirm", ""))
    return ok(username=user["username"]), 201


@api.post("/auth/google-demo")
def google_demo():
    """Simulação do login social (igual ao app Flutter). Substituir por OAuth real em produção."""
    return _start_session(repo().google_demo_login())


@api.post("/auth/logout")
def logout():
    session.clear()
    return ok()


# ---------------------------------------------------------------- tutor/perfil
@api.get("/session")
def session_state():
    """Checagem de sessão silenciosa (200 mesmo sem login) usada na abertura do app."""
    uid = session.get("uid")
    if uid and repo().get_user(uid):
        return ok(**repo().snapshot(uid))
    session.clear()
    return ok(user=None)


@api.get("/me")
@login_required
def me(uid):
    return ok(**repo().snapshot(uid))


@api.patch("/me")
@login_required
def update_me(uid):
    repo().update_profile(uid, body())
    return ok(**repo().snapshot(uid))


@api.post("/me/password")
@login_required
def change_password(uid):
    data = body()
    repo().change_password(uid, data.get("current", ""), data.get("new", ""))
    return ok()


@api.post("/me/onboarding")
@login_required
def onboarding(uid):
    pet = repo().complete_onboarding(uid, body())
    return ok(pet=pet, **repo().snapshot(uid)), 201


# --------------------------------------------------------------------- pets
@api.post("/pets")
@login_required
def add_pet(uid):
    pet = repo().add_pet(uid, body())
    return ok(pet=pet), 201


@api.put("/pets/<pet_id>")
@login_required
def update_pet(uid, pet_id):
    return ok(pet=repo().update_pet(uid, pet_id, body()))


@api.delete("/pets/<pet_id>")
@login_required
def delete_pet(uid, pet_id):
    repo().delete_pet(uid, pet_id)
    return ok()


@api.post("/lembretes")
@login_required
def add_reminder(uid):
    return ok(lembrete=repo().add_reminder(uid, body())), 201


@api.delete("/lembretes/<rid>")
@login_required
def delete_reminder(uid, rid):
    repo().delete_reminder(uid, rid)
    return ok()


@api.post("/registros")
@login_required
def add_record(uid):
    return ok(registro=repo().add_record(uid, body())), 201


@api.delete("/registros/<rid>")
@login_required
def delete_record(uid, rid):
    repo().delete_record(uid, rid)
    return ok()


# ---------------------------------------------------------- rede solidária
@api.post("/agendamentos")
@login_required
def book(uid):
    return ok(agendamento=repo().book(uid, body())), 201


@api.delete("/agendamentos/<bid>")
@login_required
def cancel_booking(uid, bid):
    return ok(agendamento=repo().cancel_booking(uid, bid))


@api.post("/pedidos")
@login_required
def add_request(uid):
    return ok(pedido=repo().add_request(uid, body())), 201


@api.post("/pedidos/<pedido_id>/candidatura")
@login_required
def apply(uid, pedido_id):
    return ok(candidatura=repo().apply_to_request(uid, pedido_id)), 201


# ----------------------------------------------------------------- triagem
@api.post("/triage/evaluate")
@login_required
def triage_evaluate(uid):
    data = body()
    return ok(result=triage.evaluate(data.get("urgent", "incerto"), data.get("onset", "incerto")))


@api.post("/triage/chat")
@login_required
def triage_chat(uid):
    message = str(body().get("message", "")).strip()[:600]
    if not message:
        raise ApiError("Descreva o que você observou.")
    return ok(**triage.chat_reply(message))


# --------------------------------------------------------------------- demo
@api.post("/demo/reset")
@login_required
def demo_reset(uid):
    repo().reset_user(uid)
    return ok(**repo().snapshot(uid))
