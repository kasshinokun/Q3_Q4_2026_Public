"""Dados de demonstração (equivalentes ao ``_seed`` do ``AppDataService`` Flutter)."""
from __future__ import annotations

from datetime import date, timedelta

DEMO_USERNAME = "petcuida"
DEMO_PASSWORD = "meu pet"
WELCOME_CREDITS = 3.5

SERVICOS = [
    {"id": "s1", "nome": "Consulta veterinária de rotina", "prestador": "Clínica PetCuida", "local": "Padre Eustáquio",
     "preco": 60, "descricao": "Avaliação clínica geral com veterinário credenciado.", "icone": "stethoscope"},
    {"id": "s2", "nome": "Vacinação V10", "prestador": "Clínica PetCuida", "local": "Padre Eustáquio",
     "preco": 45, "descricao": "Aplicação de vacina múltipla e atualização do prontuário.", "icone": "syringe"},
    {"id": "s3", "nome": "Castração", "prestador": "Clínica PetCuida", "local": "Padre Eustáquio",
     "preco": 120, "descricao": "Pagamento misto com créditos + dinheiro.", "icone": "heart"},
    {"id": "s4", "nome": "Banho e tosa", "prestador": "Ana Pet Estética", "local": "Floresta",
     "preco": 35, "descricao": "Higienização completa e corte de unhas.", "icone": "scissors"},
]

PEDIDOS = [
    {"id": "p1", "titulo": "Levar cão ao veterinário amanhã", "solicitante": "Marcos T.", "local": "Padre Eustáquio",
     "recompensa": 2, "descricao": "Ajuda para transportar o cão até a Clínica PetCuida."},
    {"id": "p2", "titulo": "Cuidar do gato por 2 dias", "solicitante": "Renata A.", "local": "Floresta",
     "recompensa": 4, "descricao": "Alimentar e dar atenção ao gato durante uma viagem."},
    {"id": "p3", "titulo": "Passear com 2 cães à tarde", "solicitante": "Carla S.", "local": "Prado",
     "recompensa": 1, "descricao": "Passeio diário de 30 minutos."},
]


def demo_pet_birthday(today: date | None = None) -> str:
    today = today or date.today()
    return date(today.year - 3, 4, 12).isoformat()


def demo_reminders(today: date | None = None) -> list[dict]:
    today = today or date.today()
    return [
        {"titulo": "V10 - Reforço", "data": (today + timedelta(days=3)).isoformat(), "emoji": "💉", "cor": "pink"},
        {"titulo": "Banho e tosa", "data": (today + timedelta(days=30)).isoformat(), "emoji": "✂️", "cor": "yellow"},
    ]


def demo_records() -> list[dict]:
    return [
        {"titulo": "Vacina antirrábica", "detalhes": "aplicada 12/03 · próxima 12/04", "status": "Concluído",
         "tom": "good", "emoji": "💉", "cor": "pink"},
        {"titulo": "Consulta de rotina", "detalhes": "vet · Clínica PetCuida · 04/05", "status": "Concluído",
         "tom": "good", "emoji": "🩺", "cor": "yellow"},
        {"titulo": "Exame de sangue", "detalhes": "anexo · 05/06", "status": "Anexo",
         "tom": "neutral", "emoji": "📎", "cor": "lavender"},
    ]
