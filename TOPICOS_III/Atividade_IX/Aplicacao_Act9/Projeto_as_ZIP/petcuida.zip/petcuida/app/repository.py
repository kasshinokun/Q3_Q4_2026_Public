"""Regras de negócio do PetCuida sobre qualquer ``DocumentStore``.

Todo o acesso a dados passa por aqui; as rotas nunca falam com o backend direto.
"""
from __future__ import annotations

import re
import time
import uuid
from datetime import date, datetime, timezone

from werkzeug.security import check_password_hash, generate_password_hash

from . import seed
from .data_backends.base import DocumentStore
from .errors import ApiError

TIPOS = ("cao", "gato", "passaro", "outro")
DEFAULT_SETTINGS = {"push": True, "vacinas": True, "emails": False}
MAX_PHOTO_CHARS = 400_000  # ~300 KB em base64: suficiente para miniaturas redimensionadas
_USERNAME_RE = re.compile(r"^[\w.\-]{3,32}$", re.UNICODE)


def _id() -> str:
    return uuid.uuid4().hex[:12]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clean(value, limit: int = 120) -> str:
    return (value or "").strip()[:limit] if isinstance(value, str) else ""


def _iso_date(value, field: str = "data") -> str:
    try:
        return date.fromisoformat(str(value)).isoformat()
    except ValueError as exc:
        raise ApiError(f"Informe uma {field} válida.") from exc


def _br(iso: str) -> str:
    return date.fromisoformat(iso).strftime("%d/%m/%Y")


def _photo(value) -> str | None:
    if not value:
        return None
    if not isinstance(value, str) or not value.startswith("data:image/") or len(value) > MAX_PHOTO_CHARS:
        raise ApiError("Foto inválida ou muito grande. Escolha uma imagem menor.")
    return value


class Repository:
    def __init__(self, store: DocumentStore):
        self.store = store

    # ------------------------------------------------------------------ catálogo
    def ensure_catalog(self) -> None:
        for s in seed.SERVICOS:
            if not self.store.get("servicos", s["id"]):
                self.store.set("servicos", s["id"], s)
        for p in seed.PEDIDOS:
            if not self.store.get("pedidos", p["id"]):
                self.store.set("pedidos", p["id"], {**p, "autor_id": None})

    def ensure_demo_user(self) -> None:
        if not self.user_by_username(seed.DEMO_USERNAME):
            self._create_user(seed.DEMO_USERNAME, seed.DEMO_PASSWORD, nome="Tutor(a) PetCuida",
                              email="contato@petcuida.exemplo", bairro="Padre Eustáquio, Belo Horizonte")
            user = self.user_by_username(seed.DEMO_USERNAME)
            self._seed_demo_data(user["id"])

    def _seed_demo_data(self, uid: str) -> None:
        pet = self._insert_pet(uid, {"nome": "Rex", "tipo": "cao", "raca": "SRD",
                                     "nascimento": seed.demo_pet_birthday(), "foto": None})
        for r in seed.demo_reminders():
            self.store.set("lembretes", _id(), {"user_id": uid, "pet_id": pet["id"], **r})
        for r in seed.demo_records():
            self.store.set("registros", _id(), {"user_id": uid, "pet_id": pet["id"], **r})
        self._activity(uid, "Consulta veterinária de rotina", "concluido", "02/08/2026")
        v10 = seed.demo_reminders()[0]["data"]
        self._activity(uid, "Vacinação V10", "agendado", _br(v10)[:5])
        user = self.store.get("users", uid)
        user.update(onboarded=True, saldo=seed.WELCOME_CREDITS)
        self.store.set("users", uid, user)

    # ------------------------------------------------------------------ usuários
    def user_by_username(self, username: str) -> dict | None:
        found = self.store.find("users", username=_clean(username, 32).lower())
        return found[0] if found else None

    def _create_user(self, username: str, password: str, *, nome: str | None = None,
                     email: str = "", bairro: str = "") -> dict:
        uid = _id()
        uname = username.strip().lower()
        user = {
            "id": uid, "username": uname, "password_hash": generate_password_hash(password),
            "nome": nome or uname, "email": email, "bairro": bairro, "saldo": seed.WELCOME_CREDITS,
            "foto": None, "onboarded": False, "settings": dict(DEFAULT_SETTINGS), "created_at": _now(),
        }
        return self.store.set("users", uid, user)

    def register(self, username: str, password: str, confirm: str) -> dict:
        if not _clean(username) or not password or not confirm:
            raise ApiError("Preencha todos os campos.")
        if not _USERNAME_RE.match(username.strip()):
            raise ApiError("Use de 3 a 32 caracteres: letras, números, ponto, hífen ou sublinhado.")
        if password != confirm:
            raise ApiError("As senhas não conferem.")
        if len(password) < 4:
            raise ApiError("A senha deve ter pelo menos 4 caracteres.")
        if self.user_by_username(username):
            raise ApiError("Este usuário já está em uso.", 409)
        return self._create_user(username, password)

    def authenticate(self, username: str, password: str) -> dict:
        if not _clean(username) or not password:
            raise ApiError("Informe usuário e senha.")
        user = self.user_by_username(username)
        if not user or not check_password_hash(user["password_hash"], password):
            raise ApiError("Usuário ou senha incorretos.", 401)
        return user

    def google_demo_login(self) -> dict:
        """Simula o login social do Flutter (sem OAuth real)."""
        user = self.user_by_username("tutor.google")
        if not user:
            user = self._create_user("tutor.google", uuid.uuid4().hex, nome="Tutor Google",
                                     email="tutor.google@exemplo.com")
        return user

    def get_user(self, uid: str) -> dict | None:
        return self.store.get("users", uid)

    def update_profile(self, uid: str, data: dict) -> dict:
        user = self._require_user(uid)
        for field, limit in (("nome", 80), ("bairro", 80), ("email", 120)):
            if field in data:
                value = _clean(data[field], limit)
                if field == "nome" and not value:
                    raise ApiError("Informe seu nome.")
                if field == "email" and value and "@" not in value:
                    raise ApiError("Informe um e-mail válido.")
                user[field] = value
        if "foto" in data:
            user["foto"] = _photo(data["foto"])
        if isinstance(data.get("settings"), dict):
            for key in DEFAULT_SETTINGS:
                if key in data["settings"]:
                    user["settings"][key] = bool(data["settings"][key])
        return self.store.set("users", uid, user)

    def change_password(self, uid: str, current: str, new: str) -> None:
        user = self._require_user(uid)
        if not check_password_hash(user["password_hash"], current or ""):
            raise ApiError("A senha atual está incorreta.", 403)
        if len(new or "") < 4:
            raise ApiError("A nova senha deve ter pelo menos 4 caracteres.")
        user["password_hash"] = generate_password_hash(new)
        self.store.set("users", uid, user)

    def _require_user(self, uid: str) -> dict:
        user = self.store.get("users", uid)
        if not user:
            raise ApiError("Sessão expirada. Entre novamente.", 401)
        return user

    # ---------------------------------------------------------------------- pets
    def _insert_pet(self, uid: str, data: dict) -> dict:
        nome = _clean(data.get("nome"), 60)
        if not nome:
            raise ApiError("Informe o nome do pet.")
        tipo = data.get("tipo") if data.get("tipo") in TIPOS else "outro"
        nascimento = _iso_date(data.get("nascimento"), "data de nascimento")
        if date.fromisoformat(nascimento) > date.today():
            raise ApiError("A data de nascimento não pode ser no futuro.")
        pet = {"user_id": uid, "nome": nome, "tipo": tipo, "raca": _clean(data.get("raca"), 60),
               "nascimento": nascimento, "foto": _photo(data.get("foto")), "created_at": _now()}
        return self.store.set("pets", _id(), pet)

    def add_pet(self, uid: str, data: dict) -> dict:
        self._require_user(uid)
        return self._insert_pet(uid, data)

    def complete_onboarding(self, uid: str, data: dict) -> dict:
        pet = self._insert_pet(uid, data)
        user = self._require_user(uid)
        user["onboarded"] = True
        self.store.set("users", uid, user)
        return pet

    def update_pet(self, uid: str, pet_id: str, data: dict) -> dict:
        pet = self._owned("pets", pet_id, uid)
        merged = {**pet, **{k: data[k] for k in ("nome", "tipo", "raca", "nascimento", "foto") if k in data}}
        checked = self._validate_pet_fields(merged)
        return self.store.set("pets", pet_id, {**pet, **checked})

    def _validate_pet_fields(self, d: dict) -> dict:
        nome = _clean(d.get("nome"), 60)
        if not nome:
            raise ApiError("Informe o nome do pet.")
        nasc = _iso_date(d.get("nascimento"), "data de nascimento")
        if date.fromisoformat(nasc) > date.today():
            raise ApiError("A data de nascimento não pode ser no futuro.")
        foto = d.get("foto")
        foto = foto if foto is None or foto == "" else _photo(foto)
        return {"nome": nome, "tipo": d.get("tipo") if d.get("tipo") in TIPOS else "outro",
                "raca": _clean(d.get("raca"), 60), "nascimento": nasc, "foto": foto or None}

    def delete_pet(self, uid: str, pet_id: str) -> None:
        self._owned("pets", pet_id, uid)
        if len(self.store.find("pets", user_id=uid)) <= 1:
            raise ApiError("Mantenha ao menos um pet cadastrado.", 409)
        for coll in ("lembretes", "registros"):
            for doc in self.store.find(coll, user_id=uid, pet_id=pet_id):
                self.store.delete(coll, doc["id"])
        self.store.delete("pets", pet_id)

    # ----------------------------------------------------------- lembretes/registros
    def add_reminder(self, uid: str, data: dict) -> dict:
        pet = self._pet_for(uid, data.get("pet_id"))
        titulo = _clean(data.get("titulo"), 80)
        if not titulo:
            raise ApiError("Informe um título para o lembrete.")
        doc = {"user_id": uid, "pet_id": pet["id"], "titulo": titulo, "data": _iso_date(data.get("data")),
               "emoji": "📅", "cor": "navy"}
        return self.store.set("lembretes", _id(), doc)

    def delete_reminder(self, uid: str, rid: str) -> None:
        self._owned("lembretes", rid, uid)
        self.store.delete("lembretes", rid)

    def add_record(self, uid: str, data: dict) -> dict:
        pet = self._pet_for(uid, data.get("pet_id"))
        titulo, detalhes = _clean(data.get("titulo"), 80), _clean(data.get("detalhes"), 160)
        if not titulo or not detalhes:
            raise ApiError("Preencha título e detalhes do registro.")
        doc = {"user_id": uid, "pet_id": pet["id"], "titulo": titulo, "detalhes": detalhes, "status": "Novo",
               "tom": "good", "emoji": "📝", "cor": "navy", "created_at": _now()}
        return self.store.set("registros", _id(), doc)

    def delete_record(self, uid: str, rid: str) -> None:
        self._owned("registros", rid, uid)
        self.store.delete("registros", rid)

    def _pet_for(self, uid: str, pet_id: str | None) -> dict:
        if pet_id:
            return self._owned("pets", pet_id, uid)
        pets = self.store.find("pets", user_id=uid)
        if not pets:
            raise ApiError("Cadastre um pet primeiro.", 409)
        return sorted(pets, key=lambda p: p["created_at"])[0]

    def _owned(self, collection: str, doc_id: str, uid: str) -> dict:
        doc = self.store.get(collection, doc_id)
        if not doc or doc.get("user_id") != uid:
            raise ApiError("Item não encontrado.", 404)
        return doc

    # ------------------------------------------------------------- rede solidária
    def book(self, uid: str, data: dict) -> dict:
        user = self._require_user(uid)
        servico = self.store.get("servicos", str(data.get("servico_id", "")))
        if not servico:
            raise ApiError("Serviço inválido.", 404)
        dia = _iso_date(data.get("dia"), "data")
        if date.fromisoformat(dia) < date.today():
            raise ApiError("Escolha uma data a partir de hoje.")
        horario = _clean(data.get("horario"), 5)
        if not re.match(r"^\d{2}:\d{2}$", horario):
            raise ApiError("Escolha um horário.")
        pet = self._pet_for(uid, data.get("pet_id"))
        if any(a["servico_id"] == servico["id"] and a["status"] == "agendado"
               for a in self.store.find("agendamentos", user_id=uid)):
            raise ApiError("Você já tem este serviço agendado.", 409)
        creditos = 0.0
        if data.get("usar_creditos"):
            creditos = min(float(user["saldo"]), 1.0, float(servico["preco"]))
        agendamento = {
            "user_id": uid, "servico_id": servico["id"], "pet_id": pet["id"], "dia": dia, "horario": horario,
            "creditos": creditos, "dinheiro": round(servico["preco"] - creditos, 2), "status": "agendado",
            "created_at": _now(),
        }
        saved = self.store.set("agendamentos", _id(), agendamento)
        if creditos:
            user["saldo"] = round(float(user["saldo"]) - creditos, 2)
            self.store.set("users", uid, user)
        self._activity(uid, servico["nome"], "agendado", _br(dia)[:5], -creditos if creditos else None)
        return saved

    def cancel_booking(self, uid: str, booking_id: str) -> dict:
        ag = self._owned("agendamentos", booking_id, uid)
        if ag["status"] != "agendado":
            raise ApiError("Este agendamento não pode ser cancelado.", 409)
        ag["status"] = "cancelado"
        self.store.set("agendamentos", booking_id, ag)
        servico = self.store.get("servicos", ag["servico_id"]) or {"nome": "Serviço"}
        if ag["creditos"]:
            user = self._require_user(uid)
            user["saldo"] = round(float(user["saldo"]) + ag["creditos"], 2)
            self.store.set("users", uid, user)
        self._activity(uid, f"{servico['nome']} (cancelado)", "concluido", date.today().strftime("%d/%m"),
                       ag["creditos"] or None)
        return ag

    def add_request(self, uid: str, data: dict) -> dict:
        user = self._require_user(uid)
        titulo, descricao = _clean(data.get("titulo"), 90), _clean(data.get("descricao"), 300)
        if not titulo or not descricao:
            raise ApiError("Preencha título e descrição do pedido.")
        try:
            recompensa = int(data.get("recompensa", 1))
        except (TypeError, ValueError) as exc:
            raise ApiError("Recompensa inválida.") from exc
        if not 1 <= recompensa <= 10:
            raise ApiError("A recompensa deve ficar entre 1 e 10 créditos.")
        doc = {"titulo": titulo, "descricao": descricao, "solicitante": user["nome"],
               "local": _clean(data.get("local"), 60) or (user.get("bairro") or "").split(",")[0] or "Belo Horizonte",
               "recompensa": recompensa, "autor_id": uid}
        return self.store.set("pedidos", _id(), doc)

    def apply_to_request(self, uid: str, pedido_id: str) -> dict:
        pedido = self.store.get("pedidos", pedido_id)
        if not pedido:
            raise ApiError("Pedido não encontrado.", 404)
        if pedido.get("autor_id") == uid:
            raise ApiError("Você não pode se candidatar ao seu próprio pedido.", 409)
        if self.store.find("candidaturas", user_id=uid, pedido_id=pedido_id):
            raise ApiError("Candidatura já enviada.", 409)
        cand = self.store.set("candidaturas", _id(), {"user_id": uid, "pedido_id": pedido_id, "created_at": _now()})
        self._activity(uid, pedido["titulo"], "andamento", "Hoje")
        return cand

    def _activity(self, uid: str, nome: str, status: str, data: str, variacao: float | None = None) -> None:
        self.store.set("atividades", _id(), {"user_id": uid, "nome": nome, "status": status, "data": data,
                                             "variacao": variacao, "seq": time.time_ns()})

    # ---------------------------------------------------------------- bootstrap
    def snapshot(self, uid: str) -> dict:
        user = self._require_user(uid)
        servicos = sorted(self.store.find("servicos"), key=lambda s: s["id"])
        ags = sorted(self.store.find("agendamentos", user_id=uid), key=lambda a: (a["dia"], a["horario"]))
        booked = {a["servico_id"] for a in ags if a["status"] == "agendado"}
        applied = {c["pedido_id"] for c in self.store.find("candidaturas", user_id=uid)}
        servico_by_id = {s["id"]: s for s in servicos}
        agendamentos = [{**a, "servico": servico_by_id.get(a["servico_id"])} for a in ags]
        pedidos = sorted(self.store.find("pedidos"), key=lambda p: (p.get("autor_id") is None, p["id"]))
        # pedidos criados pelo usuário aparecem primeiro
        pedidos.sort(key=lambda p: p.get("autor_id") != uid)
        return {
            "user": self.public_user(user),
            "pets": sorted(self.store.find("pets", user_id=uid), key=lambda p: p["created_at"]),
            "servicos": [{**s, "agendado": s["id"] in booked} for s in servicos],
            "pedidos": [{**p, "candidatado": p["id"] in applied, "meu": p.get("autor_id") == uid} for p in pedidos],
            "lembretes": sorted(self.store.find("lembretes", user_id=uid), key=lambda r: r["data"]),
            "registros": sorted(self.store.find("registros", user_id=uid), key=lambda r: r["id"]),
            "atividades": sorted(self.store.find("atividades", user_id=uid), key=lambda a: a["seq"], reverse=True),
            "agendamentos": agendamentos,
        }

    @staticmethod
    def public_user(user: dict) -> dict:
        return {k: user.get(k) for k in ("id", "username", "nome", "email", "bairro", "saldo", "foto",
                                          "onboarded", "settings")}

    # -------------------------------------------------------------------- demo
    def reset_user(self, uid: str) -> None:
        """Restaura os dados do tutor ao estado inicial (útil entre apresentações)."""
        user = self._require_user(uid)
        for coll in ("pets", "lembretes", "registros", "atividades", "agendamentos", "candidaturas"):
            self.store.delete_where(coll, user_id=uid)
        for p in self.store.find("pedidos", autor_id=uid):
            self.store.delete("pedidos", p["id"])
        user.update(saldo=seed.WELCOME_CREDITS, foto=None, onboarded=False, settings=dict(DEFAULT_SETTINGS))
        if user["username"] == seed.DEMO_USERNAME:
            user.update(nome="Tutor(a) PetCuida", email="contato@petcuida.exemplo",
                        bairro="Padre Eustáquio, Belo Horizonte")
        self.store.set("users", uid, user)
        if user["username"] == seed.DEMO_USERNAME:
            self._seed_demo_data(uid)
