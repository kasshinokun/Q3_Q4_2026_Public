"""Triagem orientativa (regras simples e transparentes — NÃO é diagnóstico).

Replica o fluxo do app Flutter (2 perguntas + chat) e acrescenta detecção de
sinais de alerta por palavras-chave no chat, sempre recomendando avaliação
veterinária em caso de dúvida.
"""
from __future__ import annotations

import unicodedata

DISCLAIMER = (
    "Esta experiência é orientativa e não substitui uma avaliação veterinária."
)
EMERGENCY_NOTE = (
    "Em caso de falta de ar, convulsão, sangramento intenso ou perda de consciência, "
    "procure atendimento clínico imediato."
)

_RED_FLAGS = (
    "falta de ar", "dificuldade para respirar", "dificuldade respiratoria", "convuls",
    "sangramento", "sangrando", "desmai", "inconsciente", "perda de consciencia",
    "envenen", "atropel", "engasg", "nao para de vomitar", "gengiva palida", "abdomen inchado",
)


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFD", text.lower())
    return "".join(c for c in text if unicodedata.category(c) != "Mn")


def has_red_flag(text: str) -> bool:
    t = _norm(text)
    return any(flag in t for flag in _RED_FLAGS)


def evaluate(urgent: str, onset: str) -> dict:
    """``urgent``: sim|nao|incerto; ``onset``: horas|dias|incerto."""
    if urgent == "sim":
        return {
            "level": "urgent",
            "title": "Procure atendimento agora",
            "text": "Sinais de alerta devem ser avaliados imediatamente por um médico-veterinário. "
                    "Encontre uma clínica parceira na Rede Solidária.",
            "disclaimer": DISCLAIMER,
        }
    if onset == "horas" or urgent == "incerto":
        return {
            "level": "attention",
            "title": "Observe de perto e agende uma avaliação",
            "text": "Como os sinais são recentes ou você não tem certeza, vale registrar tudo e agendar uma "
                    "consulta. Se houver piora, procure atendimento imediatamente.",
            "disclaimer": DISCLAIMER,
        }
    return {
        "level": "monitor",
        "title": "Acompanhe e agende uma avaliação",
        "text": "Registre os sinais no prontuário e procure um parceiro se eles persistirem ou piorarem. "
                "A prevenção é sempre o melhor caminho.",
        "disclaimer": DISCLAIMER,
    }


def chat_reply(message: str) -> dict:
    if has_red_flag(message):
        return {
            "urgent": True,
            "reply": "O que você descreveu pode ser um sinal de alerta. Procure uma clínica agora — "
                     "não espere os sintomas passarem. " + EMERGENCY_NOTE,
        }
    return {
        "urgent": False,
        "reply": "Obrigado por descrever. Anote quando os sinais começaram, a intensidade e qualquer mudança "
                 "de comportamento. Se houver piora, procure uma clínica parceira na Rede Solidária.",
    }
