# PetCuida · Web alfa (Flask + Vue 3)

Versão web de apresentação do PetCuida, fiel à identidade visual do app Flutter (`legacy_flutter/`): navy `#4F6997`, creme, rosa, amarelo e lavanda, marca "paw" amarela.
Funciona **offline** (Vue e QR Code estão em `app/static/vendor/`), em desktop e celular.

## Executar

```bash
python3 -m venv .venv && . .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py                                         # http://127.0.0.1:5000
```

- Login de demonstração: **`petcuida` / `meu pet`** (ou o botão *Entrar agora*).
- Roteiro de apresentação: [`docs/APRESENTACAO.md`](docs/APRESENTACAO.md).
- Entre apresentações: *Perfil › Configurações › Restaurar dados de demonstração*.
- Link da pesquisa (Google Forms) no login: [`docs/LINK_PESQUISA_LOGIN.md`](docs/LINK_PESQUISA_LOGIN.md).
- Docker: `docker build -t petcuida . && docker run -p 8000:8000 -e SECRET_KEY=... petcuida`.

## Testes

```bash
pip install -r requirements-dev.txt
python -m pytest -q          # 49 testes; a suíte da API roda em SQLite, Firestore (dublê) e Supabase (dublê)
```

Teste visual/funcional opcional em navegador real: `tests/e2e_flow.py` e `tests/e2e_screens.py` (Playwright).

## Estrutura

```
app/
  __init__.py          fábrica da aplicação, config, cabeçalhos de segurança
  routes.py            API JSON (/api/*) com sessão e autorização por recurso
  repository.py        regras de negócio (créditos, agendamento, pedidos, validações)
  triage.py, seed.py   triagem orientativa e dados de demonstração
  data_backends/       contrato DocumentStore + sqlite / firestore / supabase
  static/css/app.css   design system (tokens do Flutter)
  static/js/           Vue 3 sem build: router, store, components/, views/
supabase/schema.sql    tabelas pc_* + RLS      docs/firestore.rules   regras do Firestore
legacy_flutter/        projeto Flutter de referência (intacto)
```

## Backends de dados (SQLite · Firestore · Supabase)

Escolha por `PETCUIDA_BACKEND` (`.env.example`). Rotas e regras de negócio não mudam: tudo passa por `DocumentStore`
(`get/set/delete/find`), o mesmo desenho do `RemoteDataSource` do Flutter — os dois podem compartilhar o mesmo projeto Firebase/Supabase.

| Backend | Ativar |
|---|---|
| `sqlite` (padrão) | nada a configurar; arquivo em `app/storage/petcuida.db` |
| `firestore` | `pip install -r requirements-firebase.txt`; `GOOGLE_APPLICATION_CREDENTIALS` ou `FIREBASE_CREDENTIALS_JSON`; `FIREBASE_PROJECT_ID`; publicar `docs/firestore.rules` |
| `supabase` | rodar `supabase/schema.sql`; `pip install -r requirements-supabase.txt`; `SUPABASE_URL` + `SUPABASE_SERVICE_KEY` (chave *service_role*, só no servidor) |

A tela *Sobre* mostra o backend ativo (`/api/health`). **Limite honesto:** os adaptadores remotos foram validados com dublês
(contrato e fluxo completo da API), **não contra projetos Firebase/Supabase reais** — teste em um projeto de homologação antes de qualquer piloto.

## Segurança (protótipo alfa)

Senhas com hash, sessão HttpOnly/SameSite, autorização por usuário em todos os recursos, validação no servidor, fotos limitadas.
Ainda **não** há: proteção CSRF por token, limite de tentativas de login, e-mail de recuperação, OAuth real (o "Google" é simulado), HTTPS.
Para publicar: defina `SECRET_KEY` forte, `PETCUIDA_ENV=production`, `SESSION_COOKIE_SECURE=1`, use HTTPS e dados fictícios.

## Pendências conhecidas

- Nomes completos da equipe/professores e nome exato de curso/disciplina continuam como no Flutter (marcados `TODO` lá).
- Mapa é ilustrativo (sem Google Maps/OSM). Pagamento é no local (sem gateway).
- O pacote *Atividade IX / D4B* traz um painel de **Organização/PJ** que ainda não foi portado para esta versão.
