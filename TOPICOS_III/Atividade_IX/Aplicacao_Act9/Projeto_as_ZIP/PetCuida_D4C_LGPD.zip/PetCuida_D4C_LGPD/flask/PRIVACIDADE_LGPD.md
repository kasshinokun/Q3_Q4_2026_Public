# PetCuida — privacidade, auditoria e dados temporários

## Escopo

Esta implementação aplica privacidade por padrão ao protótipo Flask/SQLite. Ela não é um parecer jurídico e não define, sozinha, a base legal, o controlador, o encarregado (DPO), o prazo de retenção ou o aviso de privacidade do projeto. Esses pontos devem ser validados pelo responsável pelo tratamento.

## Decisões técnicas

- Cada visitante recebe `session_id` aleatório e sessão permanente com TTL padrão de 45 minutos.
- Registros criados por cadastro, pet, agendamento, demanda, profissional e oferta recebem `temporary_session_id`.
- Logout chama `POST /api/auth/logout`, remove dados funcionais e arquivos em `PETCUIDA_TEMP_UPLOAD_DIR/<session_id>`.
- Sessões expiradas são limpas oportunisticamente em requisições API e podem ser limpas por `POST /api/auth/cleanup` ou tarefa do PythonAnywhere.
- `access_logs` permanece para auditoria, mas contém apenas `session_id`, timestamp, evento, rota, método, status e hashes de IP/User-Agent/usuário. Senhas, corpo de requisição, fotos e conteúdo de formulário nunca são gravados.
- Dados seed possuem `temporary_session_id IS NULL` e não são removidos pela limpeza.
- Fotos temporárias aceitam apenas JPG, PNG e WebP e ficam fora da árvore pública de arquivos.

## Relação com a LGPD

A estrutura foi orientada pelos princípios de finalidade, adequação, necessidade, livre acesso, transparência, segurança, prevenção e responsabilização/prestação de contas (art. 6º), e pela necessidade de medidas técnicas e administrativas de segurança. A retenção dos logs deve ser documentada por finalidade e prazo; “permanente” não deve ser interpretado como retenção ilimitada sem justificativa.

## Configuração recomendada

```bash
export SECRET_KEY='valor-longo-e-aleatorio'
export PETCUIDA_PRIVACY_HASH_SALT='outro-valor-longo-e-aleatorio'
export PETCUIDA_SESSION_TTL_MINUTES=45
export PETCUIDA_TEMP_UPLOAD_DIR=/tmp/petcuida
```

Em produção, substituir o segredo padrão, usar HTTPS, restringir o acesso ao SQLite/logs, fazer backup protegido, definir política de retenção dos logs e não coletar dados além do necessário.

## Limpeza periódica no PythonAnywhere

```bash
cd /home/petcuida/flask
.venv/bin/python -c "from app import create_app; c=create_app(); c.test_client().post('/api/auth/cleanup')"
```

A tarefa deve usar a mesma variável `PETCUIDA_DB_PATH` do site.

## Direitos do titular

O protótipo ainda precisa de uma camada de atendimento para confirmação de identidade, acesso, correção, eliminação e demais solicitações do titular. Não se deve entregar o SQLite diretamente ao usuário.
