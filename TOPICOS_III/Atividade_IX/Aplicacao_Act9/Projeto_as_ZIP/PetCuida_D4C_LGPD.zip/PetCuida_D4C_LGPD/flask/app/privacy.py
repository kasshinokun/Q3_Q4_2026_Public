"""Privacidade por padrão para a demonstração PetCuida.

Os dados funcionais criados durante uma sessão recebem temporary_session_id e
podem ser eliminados sem tocar nos dados seed. access_logs é separado e contém
somente metadados necessários à auditoria, sem senha, conteúdo de formulário,
foto ou IP/User-Agent em claro.

Isto é uma implementação técnica de referência, não substitui a definição da
base legal, política de retenção, aviso de privacidade e revisão jurídica do
controlador.
"""
from __future__ import annotations

import hashlib
import json
import secrets
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from flask import current_app, request, session

from .db import db


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_session_id() -> str:
    return secrets.token_urlsafe(32)


def privacy_hash(value: str | None) -> str | None:
    if not value:
        return None
    salt = str(current_app.config.get("PRIVACY_HASH_SALT") or current_app.config["SECRET_KEY"])
    return hashlib.sha256(f"{salt}:{value}".encode("utf-8", "replace")).hexdigest()


def session_id() -> str:
    sid = session.get("session_id")
    if not sid:
        sid = new_session_id()
        session["session_id"] = sid
        session.permanent = True
    return sid


def principal() -> dict[str, Any]:
    return {
        "user_id": session.get("user_id"),
        "username_hash": privacy_hash(session.get("username")),
        "account_type": session.get("account_type"),
    }


def ensure_session(path: str, sid: str | None = None) -> str:
    sid = sid or session_id()
    current = now_iso()
    expiry = (datetime.now(timezone.utc) + timedelta(minutes=int(current_app.config["SESSION_TTL_MINUTES"]))).isoformat()
    p = principal()
    with db(path) as conn:
        conn.execute(
            """INSERT INTO session_registry(session_id,user_id,username_hash,account_type,started_at,last_seen,expires_at)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(session_id) DO UPDATE SET
                 user_id=COALESCE(excluded.user_id,session_registry.user_id),
                 username_hash=COALESCE(excluded.username_hash,session_registry.username_hash),
                 account_type=COALESCE(excluded.account_type,session_registry.account_type),
                 last_seen=excluded.last_seen, expires_at=excluded.expires_at""",
            (sid, p["user_id"], p["username_hash"], p["account_type"], current, current, expiry),
        )
    return sid


def bind_user(path: str, user: dict[str, Any]) -> None:
    session["user_id"] = user.get("id")
    session["username"] = user.get("username")
    session["account_type"] = user.get("account_type")
    ensure_session(path)


def log_event(path: str, event_type: str, *, status_code: int | None = None,
              metadata: dict[str, Any] | None = None, sid: str | None = None) -> None:
    """Registra somente dados de auditoria minimizados; nunca registra senha/body/foto."""
    sid = sid or session_id()
    p = principal()
    metadata = metadata or {}
    safe_metadata = {str(k): str(v)[:160] for k, v in metadata.items() if k not in {"password", "body", "photo", "file"}}
    with db(path) as conn:
        conn.execute(
            """INSERT INTO access_logs
            (session_id,user_id,username_hash,account_type,event_type,route,method,status_code,ip_hash,user_agent_hash,metadata_json,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (sid, p["user_id"], p["username_hash"], p["account_type"], event_type,
             request.path if request else None, request.method if request else None, status_code,
             privacy_hash(request.remote_addr if request else None),
             privacy_hash(request.headers.get("User-Agent") if request else None),
             json.dumps(safe_metadata, ensure_ascii=False, separators=(",", ":")), now_iso()),
        )


def _remove_session_files(sid: str) -> int:
    base = Path(current_app.config["TEMP_UPLOAD_DIR"]) / sid
    if not base.exists():
        return 0
    count = sum(1 for p in base.rglob("*") if p.is_file())
    shutil.rmtree(base, ignore_errors=True)
    return count


def purge_session_data(path: str, sid: str, *, reason: str = "session_end") -> dict[str, int]:
    """Apaga somente dados funcionais marcados com sid; access_logs é preservado."""
    removed = {"demand_requests": 0, "appointments": 0, "service_offers": 0,
               "professionals": 0, "pets": 0, "users": 0, "organizations": 0, "files": _remove_session_files(sid)}
    with db(path) as conn:
        # Child rows first because foreign_keys is enabled.
        for table in ("demand_requests", "appointments", "service_offers", "professionals", "pets", "users", "organizations"):
            cur = conn.execute(f"DELETE FROM {table} WHERE temporary_session_id=?", (sid,))
            removed[table] = cur.rowcount
        conn.execute("UPDATE session_registry SET ended_at=?, expires_at=?, purged_at=? WHERE session_id=?", (now_iso(), now_iso(), now_iso(), sid))
        conn.execute("INSERT INTO access_logs(session_id,event_type,route,method,status_code,metadata_json,created_at) VALUES (?,?,?,?,?,?,?)",
                     (sid, "temporary_data_purged", "/api/auth/logout", "POST", 200,
                      json.dumps({"reason": reason, "removed": removed}, separators=(",", ":")), now_iso()))
    return removed


def purge_expired_sessions(path: str) -> int:
    now = now_iso()
    with db(path) as conn:
        rows = conn.execute("SELECT session_id FROM session_registry WHERE purged_at IS NULL AND (ended_at IS NOT NULL OR expires_at < ?)", (now,)).fetchall()
    count = 0
    for row in rows:
        purge_session_data(path, row["session_id"], reason="expired")
        count += 1
    return count


def save_temp_photo(sid: str, file_storage, kind: str) -> dict[str, str]:
    from werkzeug.utils import secure_filename
    allowed = {"profile": {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"},
               "pet": {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}}
    if kind not in allowed:
        raise ValueError("Tipo de foto inválido.")
    content_type = (file_storage.mimetype or "").lower()
    if content_type not in allowed[kind]:
        raise ValueError("Formato de foto não permitido. Use JPG, PNG ou WebP.")
    filename = secure_filename(file_storage.filename or "foto")[:80] or "foto"
    folder = Path(current_app.config["TEMP_UPLOAD_DIR"]) / sid / kind
    folder.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(16)
    destination = folder / f"{token}{allowed[kind][content_type]}"
    file_storage.save(destination)
    return {"token": token, "kind": kind, "filename": filename, "path": str(destination)}
