"""Rotas HTTP da API demonstrativa do PetCuida, com auditoria minimizada."""
import re
from flask import Blueprint, current_app, jsonify, request, session
from .repository import build_repository, normalize_professional_row, parse_professionals_file
from .privacy import (bind_user, ensure_session, log_event, new_session_id, purge_session_data,
                      privacy_hash, session_id, save_temp_photo)

api = Blueprint("api", __name__)
def repo(): return build_repository(current_app.config)
def ok(data): return jsonify({"ok": True, **data})
def body_json():
    value = request.get_json(silent=True)
    return value if isinstance(value, dict) else {}
def sid(): return session_id()
def user_id_from(body=None): return parse_identifier((body or {}).get("user_id") or request.args.get("user_id"), "Usuário", default=1)
def organization_id_from(body=None): return parse_identifier((body or {}).get("organization_id") or request.args.get("organization_id"), "Organização")
def parse_identifier(value, field, default=None):
    if value in (None, ""): return default
    if isinstance(value, bool): raise ValueError(f"{field} inválido.")
    text = str(value).strip()
    if text.isdigit() and int(text) > 0: return int(text)
    if re.fullmatch(r"[A-Za-z0-9_-]{1,128}", text): return text
    raise ValueError(f"{field} inválido.")
def bad_request(error): return jsonify({"ok": False, "error": str(error)}), 400

def rotate_login_session(user):
    old = session.get("session_id")
    if old:
        # The pre-auth session has no functional data; retain its audit trail.
        current_app.logger.debug("Rotação de sessão de autenticação: %s", privacy_hash(old))
    session.clear()
    session["session_id"] = new_session_id()
    session.permanent = True
    bind_user(current_app.config["DB_PATH"], user)

@api.post("/auth/login")
def login():
    body = body_json(); user = repo().authenticate(body.get("username", ""), body.get("password", ""))
    if not user:
        log_event(current_app.config["DB_PATH"], "login_failed", status_code=401)
        return jsonify({"ok": False, "error": "Usuário ou senha incorretos."}), 401
    rotate_login_session(user)
    log_event(current_app.config["DB_PATH"], "login_succeeded", status_code=200)
    return ok({"user": user})

@api.post("/auth/register")
def register():
    try:
        user = repo().register(body_json(), temporary_session_id=sid())
        bind_user(current_app.config["DB_PATH"], user)
        log_event(current_app.config["DB_PATH"], "account_created", status_code=200, metadata={"account_type": user.get("account_type")})
        return ok({"user": user})
    except (KeyError, ValueError, TypeError) as error:
        log_event(current_app.config["DB_PATH"], "account_creation_failed", status_code=400)
        return bad_request(error)

@api.post("/auth/logout")
def logout():
    current = sid(); log_event(current_app.config["DB_PATH"], "logout", status_code=200)
    removed = purge_session_data(current_app.config["DB_PATH"], current, reason="explicit_logout")
    session.clear()
    return ok({"session_id": current, "purged": removed})

@api.post("/auth/cleanup")
def cleanup():
    # Useful for cron/manual maintenance; does not expose rows or personal data.
    from .privacy import purge_expired_sessions
    count = purge_expired_sessions(current_app.config["DB_PATH"])
    log_event(current_app.config["DB_PATH"], "expired_sessions_cleanup", status_code=200, metadata={"sessions": count})
    return ok({"expired_sessions": count})

@api.post("/uploads/photo")
def upload_photo():
    try:
        if "file" not in request.files: raise ValueError("Envie uma foto.")
        result = save_temp_photo(sid(), request.files["file"], request.form.get("kind", "pet"))
        log_event(current_app.config["DB_PATH"], "temporary_photo_created", status_code=200, metadata={"kind": result["kind"]})
        return ok({"photo": {"token": result["token"], "kind": result["kind"]}})
    except (KeyError, ValueError, TypeError) as error:
        log_event(current_app.config["DB_PATH"], "temporary_photo_rejected", status_code=400)
        return bad_request(error)

@api.get("/pets")
def pets():
    try: return ok({"pets": repo().list_pets(user_id_from())})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.post("/pets")
def add_pet():
    body = body_json()
    try:
        result = repo().add_pet(user_id_from(body), body, temporary_session_id=sid())
        log_event(current_app.config["DB_PATH"], "pet_created", status_code=200)
        return ok({"id": result})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.get("/services")
def services(): return ok({"services": repo().services()})
@api.get("/appointments")
def appointments():
    try: return ok({"appointments": repo().appointments(user_id_from())})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.post("/appointments")
def book():
    body = body_json()
    try:
        result = repo().book(user_id_from(body), body, temporary_session_id=sid())
        log_event(current_app.config["DB_PATH"], "appointment_created", status_code=200)
        return ok({"id": result})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)

@api.get("/organization/overview")
def organization_overview():
    try:
        org_id = organization_id_from(); repository = repo()
        return ok({"organization": repository.organization(org_id), "professionals": repository.professionals(org_id), "offers": repository.service_offers(org_id), "demands": repository.demands(org_id)})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.post("/organization/professionals")
def add_professional():
    body = body_json()
    try: return ok({"id": repo().add_professional(organization_id_from(body), body, temporary_session_id=sid())})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.post("/organization/professionals/import")
def import_professionals():
    try:
        org_id = organization_id_from(request.form.to_dict())
        if not org_id or "file" not in request.files: raise ValueError("Envie a organização e um arquivo JSON, XLS ou XLSX.")
        rows = parse_professionals_file(request.files["file"]); normalized = [normalize_professional_row(row) for row in rows]; normalized = [row for row in normalized if row]
        if not normalized: raise ValueError("O arquivo não contém profissionais válidos.")
        created = repo().add_professionals_bulk(org_id, normalized, temporary_session_id=sid())
        log_event(current_app.config["DB_PATH"], "professionals_imported", status_code=200, metadata={"count": len(created)})
        return ok({"created": len(created)})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.post("/organization/offers")
def add_offer():
    body = body_json()
    try: return ok({"id": repo().add_offer(organization_id_from(body), body, temporary_session_id=sid())})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.post("/organization/demands/<int:demand_id>/accept")
def accept_demand(demand_id):
    body = body_json()
    try: return ok({"id": repo().accept_demand(organization_id_from(body), demand_id, body.get("professional_id"))})
    except (KeyError, ValueError, TypeError) as error: return bad_request(error)
@api.get("/triage")
def triage(): return ok({"disclaimer": "Triagem orientativa; não substitui avaliação veterinária.", "questions": ["O pet está com dificuldade para respirar?", "Há sangramento intenso ou perda de consciência?", "O sintoma começou de forma súbita?"]})
@api.get("/status")
def status(): return ok({"app": "PetCuida", "version": "1.5.2-alpha", "revision": "d4", "backend": current_app.config["BACKEND"], "demo": current_app.config["BACKEND"] == "sqlite"})
