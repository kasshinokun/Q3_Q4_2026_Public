import json
from io import BytesIO
from pathlib import Path
from app import create_app
from app.db import connect

def make_client(tmp_path):
    app = create_app({"TESTING": True, "DB_PATH": str(tmp_path / "privacy.db"), "TEMP_UPLOAD_DIR": str(tmp_path / "uploads"), "SESSION_TTL_MINUTES": 45})
    return app, app.test_client()

def test_login_creates_session_and_keeps_minimized_audit(tmp_path):
    app, client = make_client(tmp_path)
    response = client.post('/api/auth/login', json={'username':'petcuida','password':'meu pet'})
    assert response.status_code == 200
    with connect(app.config['DB_PATH']) as c:
        rows = c.execute("SELECT event_type,session_id,username_hash,metadata_json FROM access_logs WHERE event_type='login_succeeded'").fetchall()
        assert rows and rows[-1]['session_id'] and rows[-1]['username_hash']
        assert 'password' not in rows[-1]['metadata_json']

def test_logout_purges_only_session_data_and_preserves_seed_and_logs(tmp_path):
    app, client = make_client(tmp_path)
    registered = client.post('/api/auth/register', json={'username':'teste.temp','password':'1234','display_name':'Teste'})
    assert registered.status_code == 200
    assert client.post('/api/pets', json={'user_id': registered.json['user']['id'], 'name':'Temporário','species':'Cão'}).status_code == 200
    client.post('/api/uploads/photo', data={'kind':'pet','file':(BytesIO(b'fake-image'), 'pet.png')}, content_type='multipart/form-data')
    out = client.post('/api/auth/logout')
    assert out.status_code == 200
    with connect(app.config['DB_PATH']) as c:
        assert c.execute("SELECT 1 FROM users WHERE username='teste.temp'").fetchone() is None
        assert c.execute("SELECT 1 FROM pets WHERE name='Temporário'").fetchone() is None
        assert c.execute("SELECT 1 FROM users WHERE username='petcuida'").fetchone() is not None
        assert c.execute("SELECT 1 FROM pets WHERE name='Rex'").fetchone() is not None
        assert c.execute("SELECT COUNT(*) FROM access_logs WHERE event_type='logout'").fetchone()[0] >= 1
        assert c.execute("SELECT COUNT(*) FROM access_logs WHERE event_type='temporary_data_purged'").fetchone()[0] >= 1
    assert not list(Path(app.config['TEMP_UPLOAD_DIR']).glob('*'))

def test_photo_validation_does_not_store_disallowed_file(tmp_path):
    app, client = make_client(tmp_path)
    response = client.post('/api/uploads/photo', data={'kind':'pet','file':(BytesIO(b'not-photo'), 'pet.txt')}, content_type='multipart/form-data')
    assert response.status_code == 400
    assert not list(Path(app.config['TEMP_UPLOAD_DIR']).rglob('*'))
