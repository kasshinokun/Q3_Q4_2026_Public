# PetCuida — D4C UI/UX + PF/PJ

D4C é o merge do D4B com os padrões de UI/UX testados em `petcuida.zip`. A implementação mantém as duas interfaces: tutor/PF e organização/PJ.

## Destaques

- Splash e identidade visual mais próximas do app mobile;
- Login responsivo com hero, benefícios e CTA de demonstração;
- Pesquisa Google Forms em card de destaque;
- Login PF e painel PJ preservados;
- Flutter completo preservado, incluindo `features/organization/`;
- 11 testes Flask aprovados na base D4C antes das alterações visuais.

## Logins de demonstração

- PF/Tutor: `petcuida` / `meu pet`
- PJ/Organização: `clinica.petcuida` / `pet pj`

## Execução web

```bash
cd flask
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
python run.py
```

Pesquisa: https://forms.gle/oPd1dTVgDdNcZHgn9

## Privacidade e LGPD

A variante D4C_LGPD acrescenta sessões temporárias, limpeza seletiva de dados de teste, armazenamento temporário de fotos e auditoria minimizada. Consulte `flask/PRIVACIDADE_LGPD.md`; a implementação técnica não substitui validação jurídica, aviso de privacidade e definição de retenção.
