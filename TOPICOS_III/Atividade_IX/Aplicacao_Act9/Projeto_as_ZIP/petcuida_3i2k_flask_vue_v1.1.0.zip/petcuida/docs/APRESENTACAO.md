# Roteiro de apresentação da versão alfa (≈ 8 min)

**Antes:** `python run.py` → http://127.0.0.1:5000 · Em *Perfil › Configurações* use **Restaurar dados de demonstração** para começar do zero.
Sem internet? Tudo funciona offline (Vue, QR Code e fontes são locais). Projete em tela cheia (F11); a interface é responsiva — mostre também em janela estreita (celular).

| # | Tela | O que mostrar | Fala sugerida |
|---|------|---------------|---------------|
| 1 | Splash + Login | Marca, proposta de valor, botão **Entrar agora** da demo, cartão da pesquisa | "Cuide antes. Cuide junto." Convide a plateia a responder a pesquisa. |
| 2 | Início | Saudação, créditos, pet em destaque, próximo cuidado (V10 em 3 dias) | Painel único para o tutor. |
| 3 | Meu pet › Editar | Trocar foto (galeria/câmera), ver idade calculada | Cadastro simples, foto reduzida no navegador. |
| 4 | Vacinas | **Novo lembrete** → aparece na lista com tag "Novo" | Prevenção com lembretes. |
| 5 | Prontuário + QR | Novo registro; **QR Code** baixar/compartilhar | Identificação rápida em clínica parceira. |
| 6 | Triagem | "Sim, sinais de alerta" → resultado urgente; depois **conversa** com "convulsão" | Orientação responsável, nunca diagnóstico. |
| 7 | Rede › Serviços | Agendar **Banho e tosa** → dia/horário → **usar créditos** (−1 cr.) | Pagamento híbrido: créditos + dinheiro. |
| 8 | Perfil › Agendamentos / Saldo | Ver o agendamento e o extrato; **Cancelar** devolve o crédito | Transparência no saldo. |
| 9 | Mural de ajuda | Candidatar-se; **Pedir ajuda** (publica no mural) | Economia solidária: ajudar gera créditos. |
| 10 | Sobre | Equipe, termos, **status do armazenamento** (sqlite/firestore/supabase) | Arquitetura pronta para nuvem. |

Contas: **petcuida / meu pet** (demo). "Continuar com Google" é simulado (sem OAuth real) e está indicado como tal.
