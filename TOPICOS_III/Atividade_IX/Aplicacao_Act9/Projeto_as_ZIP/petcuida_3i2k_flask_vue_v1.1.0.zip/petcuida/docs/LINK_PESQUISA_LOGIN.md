# Como adicionar o link da pesquisa (Google Forms) na tela de login

Link atual: **https://forms.gle/N3C947f2NfmwQeoRA** — "Pesquisa de Mercado – PetCuida".

## Neste projeto (já implementado)

O link aparece como cartão lavanda no fim do formulário de login (e também em *Sobre* e *Suporte*).
Para trocar o formulário **sem editar código**, defina a variável de ambiente e reinicie:

```bash
# .env
PETCUIDA_SURVEY_URL=https://forms.gle/SEU_NOVO_LINK
# vazio = oculta o cartão em todas as telas
PETCUIDA_SURVEY_URL=
```

Como funciona: `app/__init__.py` lê `PETCUIDA_SURVEY_URL` (padrão = link acima), aceita **somente `https://`**
e injeta em `<meta name="petcuida-survey">` (`templates/index.html`). O Vue lê essa meta em
`static/js/views/auth.js` (`SURVEY_URL`) e renderiza `<a class="survey-link" target="_blank" rel="noopener noreferrer">`.
O estilo está em `static/css/app.css` (`.survey-link`).

## No pacote D4B (Atividade IX — `flask/app/static/js/components/Login.js`)

Dentro do `template` de `Login.js`, logo após o bloco `<div class="demo-note">…</div>`, acrescente:

```html
<a class="survey-link" href="https://forms.gle/N3C947f2NfmwQeoRA" target="_blank" rel="noopener noreferrer">
  <strong>Ajude a construir o PetCuida</strong>
  <small>Responda nossa pesquisa de mercado · 3 a 5 min · participação voluntária</small>
</a>
```

E em `static/css/app.css`:

```css
.survey-link{display:block;margin-top:12px;padding:12px 14px;border-radius:14px;text-decoration:none;
  background:#EFE3EC;color:#6B4A73}
.survey-link strong{display:block;font-size:13.5px}
.survey-link small{display:block;font-size:12px;opacity:.85}
```

`target="_blank"` + `rel="noopener noreferrer"` abre o formulário em nova aba sem expor `window.opener`
e sem tirar o usuário do app durante a apresentação.
